import type { BaseEntity } from '@/types';

/* ── Product Types ────────────────────────────────────────────
   Database-aligned types for product management.
*/

export type ProductStatus = 'draft' | 'published';
export type ProductCategory = 'Outerwear' | 'Tailoring' | 'Evening' | 'Knitwear' | 'Footwear' | 'Accessories' | 'Leather Goods' | 'Loungewear';
export type ProductCollection = 'spring-summer-2026' | 'fall-winter-2025' | 'resort-2026' | 'limited-edition' | 'bestsellers';

export const PRODUCT_CATEGORIES: ProductCategory[] = [
  'Outerwear', 'Tailoring', 'Evening', 'Knitwear',
  'Footwear', 'Accessories', 'Leather Goods', 'Loungewear',
];

export const PRODUCT_COLLECTIONS: { value: ProductCollection; label: string }[] = [
  { value: 'spring-summer-2026', label: 'Spring Summer 2026' },
  { value: 'fall-winter-2025', label: 'Fall Winter 2025' },
  { value: 'resort-2026', label: 'Resort 2026' },
  { value: 'limited-edition', label: 'Limited Edition' },
  { value: 'bestsellers', label: 'Bestsellers' },
];

export const PRODUCT_MATERIALS = [
  'Cashmere', 'Linen', 'Silk', 'Wool', 'Cotton',
  'Leather', 'Suede', 'Linen-Cotton', 'Technical Silk',
];

export interface ProductImage {
  id: string;
  url: string;
  alt: string;
  sort_order: number;
}

export interface ProductSEO {
  meta_title: string;
  meta_description: string;
  slug: string;
}

export interface Product extends BaseEntity {
  name: string;
  description: string;
  category: ProductCategory;
  collections: ProductCollection[];
  price: number;
  compare_at_price?: number;
  sku: string;
  stock: number;
  low_stock_threshold: number;
  material: string;
  care_instructions: string[];
  fit: string;
  status: ProductStatus;
  is_featured: boolean;
  is_bestseller: boolean;
  images: ProductImage[];
  seo: ProductSEO;
  variants: { size: string; color: string; stock: number }[];
}

export interface ProductFormData {
  name: string;
  description: string;
  category: ProductCategory;
  collections: ProductCollection[];
  price: number;
  compare_at_price?: number;
  sku: string;
  stock: number;
  low_stock_threshold: number;
  material: string;
  care_instructions: string[];
  fit: string;
  status: ProductStatus;
  is_featured: boolean;
  is_bestseller: boolean;
  seo: ProductSEO;
  variants: { size: string; color: string; stock: number }[];
  newImages: File[];
  existingImages: ProductImage[];
  removedImageIds: string[];
}

export const EMPTY_PRODUCT_FORM: ProductFormData = {
  name: '',
  description: '',
  category: 'Outerwear',
  collections: [],
  price: 0,
  compare_at_price: undefined,
  sku: '',
  stock: 0,
  low_stock_threshold: 5,
  material: '',
  care_instructions: [''],
  fit: '',
  status: 'draft',
  is_featured: false,
  is_bestseller: false,
  seo: { meta_title: '', meta_description: '', slug: '' },
  variants: [],
  newImages: [],
  existingImages: [],
  removedImageIds: [],
};
