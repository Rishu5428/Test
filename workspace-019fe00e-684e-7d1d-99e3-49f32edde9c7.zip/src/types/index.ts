/* ── Shared Types ────────────────────────────────────────────── */

/* ── Theme ─────────────────────────────────────────────────── */
export type ThemeMode = 'light' | 'dark' | 'system';
export type ResolvedTheme = 'light' | 'dark';

/* ── Button ────────────────────────────────────────────────── */
export type ButtonVariant = 'primary' | 'secondary' | 'outline' | 'ghost';
export type ButtonSize = 'sm' | 'md' | 'lg';

/* ── Typography ────────────────────────────────────────────── */
export type HeadingLevel = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';
export type BodyVariant = 'body-lg' | 'body-md' | 'body-sm' | 'caption' | 'overline';
export type FontWeight = 'light' | 'regular' | 'medium' | 'semibold' | 'bold';

/* ── Layout ────────────────────────────────────────────────── */
export type SpacingKey = '4xs' | '3xs' | '2xs' | 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | '4xl';

/* ── Database (Supabase) ───────────────────────────────────── */
export interface BaseEntity {
  id: string;
  created_at: string;
  updated_at: string;
}

/* ── Auth ──────────────────────────────────────────────────── */
export type AuthRole = 'owner' | 'manager' | 'staff';

export const ROLE_HIERARCHY: Record<AuthRole, number> = {
  owner: 3,
  manager: 2,
  staff: 1,
};

export interface AuthProfile {
  id: string;
  email: string;
  role: AuthRole;
  full_name: string;
  avatar_url?: string;
}

/* ── Common Props ──────────────────────────────────────────── */
export interface ChildrenProp {
  children: React.ReactNode;
}

export interface ClassNameProp {
  className?: string;
}
