import type { BaseEntity } from '@/types';

/* ── Order Types ────────────────────────────────────────────── */

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled'
  | 'refunded';

export type PaymentStatus = 'paid' | 'pending' | 'refunded' | 'failed';
export type ShippingMethod = 'standard' | 'express' | 'white-glove';

export const ORDER_STATUSES: { value: OrderStatus; label: string; color: string }[] = [
  { value: 'pending',    label: 'Pending',    color: 'bg-amber-100 text-amber-700' },
  { value: 'confirmed',  label: 'Confirmed',  color: 'bg-blue-100 text-blue-700' },
  { value: 'processing', label: 'Processing', color: 'bg-purple-100 text-purple-700' },
  { value: 'shipped',    label: 'Shipped',    color: 'bg-cyan-100 text-cyan-700' },
  { value: 'delivered',  label: 'Delivered',  color: 'bg-green-100 text-green-700' },
  { value: 'cancelled',  label: 'Cancelled',  color: 'bg-red-100 text-red-600' },
  { value: 'refunded',   label: 'Refunded',   color: 'bg-charcoal/5 text-charcoal/50' },
];

export const PAYMENT_STATUSES: { value: PaymentStatus; label: string; color: string }[] = [
  { value: 'paid',     label: 'Paid',     color: 'bg-green-100 text-green-700' },
  { value: 'pending',  label: 'Pending',  color: 'bg-amber-100 text-amber-700' },
  { value: 'refunded', label: 'Refunded', color: 'bg-charcoal/5 text-charcoal/50' },
  { value: 'failed',   label: 'Failed',   color: 'bg-red-100 text-red-600' },
];

export const SHIPPING_METHODS: { value: ShippingMethod; label: string }[] = [
  { value: 'standard',   label: 'Standard (5–7 days)' },
  { value: 'express',    label: 'Express (2–3 days)' },
  { value: 'white-glove', label: 'White Glove (Scheduled)' },
];

export interface OrderAddress {
  full_name: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  postal_code: string;
  country: string;
  phone: string;
}

export interface OrderLineItem {
  id: string;
  product_id: string;
  product_name: string;
  variant: string;
  sku: string;
  price: number;
  qty: number;
  thumbnail_url?: string;
}

export interface OrderShipment {
  id: string;
  tracking_number: string;
  carrier: string;
  method: ShippingMethod;
  status: string;
  estimated_delivery: string;
  shipped_at?: string;
  delivered_at?: string;
}

export interface OrderInvoice {
  id: string;
  number: string;
  issued_at: string;
  due_at: string;
  subtotal: number;
  tax: number;
  shipping_cost: number;
  discount: number;
  total: number;
  status: PaymentStatus;
  paid_at?: string;
}

export interface OrderActivity {
  id: string;
  action: string;
  performed_by: string;
  timestamp: string;
  note?: string;
}

export interface Order extends BaseEntity {
  number: string;
  customer_id: string;
  customer_name: string;
  customer_email: string;
  customer_avatar?: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  shipping_address: OrderAddress;
  billing_address: OrderAddress;
  line_items: OrderLineItem[];
  shipment?: OrderShipment;
  invoice: OrderInvoice;
  activity: OrderActivity[];
  subtotal: number;
  tax: number;
  shipping_cost: number;
  discount: number;
  total: number;
  notes?: string;
  tags: string[];
}

/* ── Order List Params ─────────────────────────────────────── */
export interface OrderListParams {
  search?: string;
  status?: string;
  paymentStatus?: string;
  sort?: string;
  page?: number;
  limit?: number;
  dateFrom?: string;
  dateTo?: string;
}

export interface OrderListResult {
  orders: Order[];
  total: number;
}
