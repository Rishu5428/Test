/* ── Media Types ────────────────────────────────────────────── */

export interface MediaItem {
  id: string;
  /** Public URL for rendering / copying */
  url: string;
  /** File name (auto-generated from original) */
  name: string;
  /** Original upload name */
  originalName: string;
  /** MIME type */
  type: string;
  /** File size in bytes */
  size: number;
  /** Folder path within the bucket (e.g. "products/spring") */
  folder: string;
  /** ISO timestamp */
  createdAt: string;
  /** Width × Height if available */
  dimensions?: { width: number; height: number };
}

export interface MediaFolder {
  name: string;
  path: string;
  count: number;
}

export interface MediaListParams {
  search?: string;
  folder?: string;
  sort?: 'newest' | 'oldest' | 'name-asc' | 'name-desc' | 'size-asc' | 'size-desc';
  page?: number;
  limit?: number;
}

export interface MediaListResult {
  items: MediaItem[];
  total: number;
  folders: MediaFolder[];
}

export const COMMON_FOLDERS = [
  'products',
  'editorial',
  'campaigns',
  'lookbooks',
  'banners',
  'brand',
] as const;

export const IMAGE_EXTENSIONS = ['jpg','jpeg','png','webp','gif','svg','avif','bmp','ico','tiff','tif'];
export const VIDEO_EXTENSIONS = ['mp4','webm','mov','avi','mkv'];
