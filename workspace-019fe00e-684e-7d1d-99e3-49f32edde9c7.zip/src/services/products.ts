import { supabase } from '@/lib/supabase';
import type { Product, ProductFormData } from '@/types/products';

/* ── Product Service ──────────────────────────────────────────
   All Supabase product operations centralized here.
   Uploads go to 'product-images' bucket.
*/

const BUCKET = 'product-images';
const TABLE = 'products';

/* ── List ──────────────────────────────────────────────────── */
export interface ProductListParams {
  search?: string;
  status?: string;
  category?: string;
  sort?: string;
  page?: number;
  limit?: number;
}

export interface ProductListResult {
  products: Product[];
  total: number;
}

export async function fetchProducts(params: ProductListParams = {}): Promise<ProductListResult> {
  const {
    search = '',
    status = '',
    category = '',
    sort = 'newest',
    page = 1,
    limit = 20,
  } = params;

  let query = supabase
    .from(TABLE)
    .select('*', { count: 'exact' });

  if (search) query = query.ilike('name', `%${search}%`);
  if (status) query = query.eq('status', status);
  if (category) query = query.eq('category', category);

  switch (sort) {
    case 'name-asc': query = query.order('name', { ascending: true }); break;
    case 'name-desc': query = query.order('name', { ascending: false }); break;
    case 'price-asc': query = query.order('price', { ascending: true }); break;
    case 'price-desc': query = query.order('price', { ascending: false }); break;
    case 'stock-low': query = query.order('stock', { ascending: true }); break;
    default: query = query.order('created_at', { ascending: false });
  }

  const from = (page - 1) * limit;
  query = query.range(from, from + limit - 1);

  const { data, error, count } = await query;
  if (error) throw error;
  return { products: (data as Product[]) ?? [], total: count ?? 0 };
}

/* ── Get Single ────────────────────────────────────────────── */
export async function fetchProduct(id: string): Promise<Product | null> {
  const { data, error } = await supabase
    .from(TABLE)
    .select('*')
    .eq('id', id)
    .single();

  if (error) return null;
  return data as Product;
}

/* ── Create ────────────────────────────────────────────────── */
export async function createProduct(
  form: ProductFormData,
): Promise<{ product: Product | null; error: string | null }> {
  /* Upload new images */
  const imageUrls = await uploadImages(form.newImages);

  const existing = form.existingImages.map((img) => ({
    id: img.id,
    url: img.url,
    alt: img.alt,
    sort_order: img.sort_order,
  }));

  const allImages = [
    ...existing,
    ...imageUrls.map((url, i) => ({
      id: crypto.randomUUID(),
      url,
      alt: form.name,
      sort_order: existing.length + i,
    })),
  ];

  const payload = {
    name: form.name,
    description: form.description,
    category: form.category,
    collections: form.collections,
    price: form.price,
    compare_at_price: form.compare_at_price ?? null,
    sku: form.sku,
    stock: form.stock,
    low_stock_threshold: form.low_stock_threshold,
    material: form.material,
    care_instructions: form.care_instructions.filter(Boolean),
    fit: form.fit,
    status: form.status,
    is_featured: form.is_featured,
    is_bestseller: form.is_bestseller,
    seo: form.seo,
    images: allImages,
    variants: form.variants,
  };

  const { data, error } = await supabase.from(TABLE).insert(payload).select().single();
  if (error) return { product: null, error: error.message };
  return { product: data as Product, error: null };
}

/* ── Update ────────────────────────────────────────────────── */
export async function updateProduct(
  id: string,
  form: ProductFormData,
): Promise<{ product: Product | null; error: string | null }> {
  /* Remove deleted images from bucket */
  if (form.removedImageIds.length > 0) {
    const urlsToRemove = form.existingImages
      .filter((img) => form.removedImageIds.includes(img.id))
      .map((img) => img.url);

    await Promise.all(urlsToRemove.map((url) => deleteImage(url)));
  }

  /* Upload new images */
  const newUrls = await uploadImages(form.newImages);

  const kept = form.existingImages.filter(
    (img) => !form.removedImageIds.includes(img.id),
  );

  const allImages = [
    ...kept.map((img, i) => ({ ...img, sort_order: i })),
    ...newUrls.map((url, i) => ({
      id: crypto.randomUUID(),
      url,
      alt: form.name,
      sort_order: kept.length + i,
    })),
  ];

  const payload = {
    name: form.name,
    description: form.description,
    category: form.category,
    collections: form.collections,
    price: form.price,
    compare_at_price: form.compare_at_price ?? null,
    sku: form.sku,
    stock: form.stock,
    low_stock_threshold: form.low_stock_threshold,
    material: form.material,
    care_instructions: form.care_instructions.filter(Boolean),
    fit: form.fit,
    status: form.status,
    is_featured: form.is_featured,
    is_bestseller: form.is_bestseller,
    seo: form.seo,
    images: allImages,
    variants: form.variants,
    updated_at: new Date().toISOString(),
  };

  const { data, error } = await supabase
    .from(TABLE)
    .update(payload)
    .eq('id', id)
    .select()
    .single();

  if (error) return { product: null, error: error.message };
  return { product: data as Product, error: null };
}

/* ── Delete ────────────────────────────────────────────────── */
export async function deleteProduct(id: string): Promise<{ error: string | null }> {
  /* Fetch to remove images */
  const product = await fetchProduct(id);
  if (product?.images) {
    await Promise.all(product.images.map((img) => deleteImage(img.url)));
  }

  const { error } = await supabase.from(TABLE).delete().eq('id', id);
  return { error: error?.message ?? null };
}

/* ── Bulk Delete ───────────────────────────────────────────── */
export async function bulkDeleteProducts(ids: string[]): Promise<{ error: string | null }> {
  /* Fetch all to clean images */
  const { data } = await supabase.from(TABLE).select('images').in('id', ids);
  if (data) {
    const allImages = (data as { images: { url: string }[] }[]).flatMap((p) => p.images);
    await Promise.all(allImages.map((img) => deleteImage(img.url)));
  }

  const { error } = await supabase.from(TABLE).delete().in('id', ids);
  return { error: error?.message ?? null };
}

/* ── Bulk Status Change ────────────────────────────────────── */
export async function bulkUpdateStatus(
  ids: string[],
  status: string,
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from(TABLE)
    .update({ status, updated_at: new Date().toISOString() })
    .in('id', ids);
  return { error: error?.message ?? null };
}

/* ── Image Helpers ─────────────────────────────────────────── */
export async function uploadImages(files: File[]): Promise<string[]> {
  if (files.length === 0) return [];

  const results = await Promise.all(
    files.map(async (file) => {
      const ext = file.name.split('.').pop();
      const path = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;

      const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
        cacheControl: '3600',
        upsert: true,
      });

      if (error) {
        console.error('Upload failed:', error.message);
        return '';
      }

      const { data: urlData } = supabase.storage.from(BUCKET).getPublicUrl(path);
      return urlData.publicUrl;
    }),
  );

  return results.filter(Boolean);
}

export async function deleteImage(url: string): Promise<void> {
  try {
    const urlObj = new URL(url);
    const path = urlObj.pathname.split(`/${BUCKET}/`).pop();
    if (path) {
      await supabase.storage.from(BUCKET).remove([path]);
    }
  } catch {
    /* Silently fail — the db record will still be removed */
  }
}
