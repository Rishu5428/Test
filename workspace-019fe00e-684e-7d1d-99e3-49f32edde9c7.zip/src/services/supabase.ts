import { supabase } from '@/lib/supabase';

/**
 * Service layer for Supabase operations.
 * All database calls route through here — never call supabase directly from components.
 *
 * Example usage:
 *   import { fetchProducts } from '@/services/supabase';
 *   const products = await fetchProducts();
 */

/* ── Products ───────────────────────────────────────────────── */
export async function fetchProducts() {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data;
}

/* ── Placeholder for future service functions ─────────────────
   export async function fetchProductBySlug(slug: string) { ... }
   export async function fetchCategories() { ... }
   export async function submitContactForm(payload: ContactPayload) { ... }
*/
