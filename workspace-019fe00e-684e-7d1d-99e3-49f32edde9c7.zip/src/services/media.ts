import { supabase } from '@/lib/supabase';
import type { MediaItem, MediaFolder, MediaListParams, MediaListResult } from '@/types/media';
import { IMAGE_EXTENSIONS, VIDEO_EXTENSIONS } from '@/types/media';

/* ── Media Service ────────────────────────────────────────────
   Dedicated storage layer for the media library bucket.
   Handles list, search, upload, delete, folder management.
*/

const BUCKET = 'media-library';

/* ── List Files ────────────────────────────────────────────── */
export async function fetchMediaList(params: MediaListParams = {}): Promise<MediaListResult> {
  const { search = '', folder = '', sort = 'newest', page = 1, limit = 60 } = params;

  /* Fetch files under the given folder prefix */
  const prefix = folder ? `${folder}/` : '';
  const { data: fileList, error } = await supabase.storage
    .from(BUCKET)
    .list(prefix, { sortBy: { column: 'created_at', order: 'desc' }, limit: 1000 });

  if (error) throw error;
  if (!fileList) return { items: [], total: 0, folders: [] };

  /* Separate folders from files */
  const rawFolders = fileList.filter((f) => !f.id);
  const rawFiles = fileList.filter((f) => !!f.id);

  let files: MediaItem[] = rawFiles.map((f) => {
    const path = prefix + f.name;
    const { data: urlData } = supabase.storage.from(BUCKET).getPublicUrl(path);
    const ext = f.name.split('.').pop()?.toLowerCase() ?? '';
    const originalName = f.metadata?.originalName as string ?? f.name;

    return {
      id: path,
      url: urlData.publicUrl,
      name: f.name,
      originalName,
      type: IMAGE_EXTENSIONS.includes(ext) ? 'image' : VIDEO_EXTENSIONS.includes(ext) ? 'video' : 'other',
      size: f.metadata?.size ?? 0,
      folder: prefix.replace(/\/$/, ''),
      createdAt: f.created_at ?? new Date().toISOString(),
    };
  });

  /* Search filter */
  if (search) {
    const q = search.toLowerCase();
    files = files.filter((f) => f.name.toLowerCase().includes(q) || f.originalName.toLowerCase().includes(q));
  }

  /* Sort */
  switch (sort) {
    case 'oldest':    files.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()); break;
    case 'name-asc':  files.sort((a, b) => a.name.localeCompare(b.name)); break;
    case 'name-desc': files.sort((a, b) => b.name.localeCompare(a.name)); break;
    case 'size-asc':  files.sort((a, b) => a.size - b.size); break;
    case 'size-desc': files.sort((a, b) => b.size - a.size); break;
    /* newset = default (already sorted from Supabase) */
  }

  const total = files.length;
  const start = (page - 1) * limit;
  files = files.slice(start, start + limit);

  /* Build folder list */
  const folderMap = new Map<string, number>();
  for (const r of rawFolders) {
    folderMap.set(prefix + r.name, 0);
  }
  /* Count files per folder from raw list (approximate) */

  const folders: MediaFolder[] = rawFolders.map((f) => ({
    name: f.name,
    path: prefix + f.name,
    count: 0,
  }));

  return { items: files, total, folders };
}

/* ── Upload ────────────────────────────────────────────────── */
export async function uploadMediaFiles(
  files: File[],
  folder: string,
  onProgress?: (pct: number, current: number, total: number) => void,
): Promise<MediaItem[]> {
  if (files.length === 0) return [];

  const results: MediaItem[] = [];
  const prefix = folder ? `${folder}/` : '';

  for (let i = 0; i < files.length; i++) {
    const file = files[i];
    const ext = file.name.split('.').pop()?.toLowerCase() ?? 'jpg';
    const timestamp = Date.now();
    const slug = Math.random().toString(36).slice(2, 8);
    const path = `${prefix}${timestamp}-${slug}.${ext}`;

    const { error } = await supabase.storage.from(BUCKET).upload(path, file, {
      cacheControl: '3600',
      upsert: false,
    });

    if (!error) {
      const { data: urlData } = supabase.storage.from(BUCKET).getPublicUrl(path);
      results.push({
        id: path,
        url: urlData.publicUrl,
        name: `${timestamp}-${slug}.${ext}`,
        originalName: file.name,
        type: IMAGE_EXTENSIONS.includes(ext) ? 'image' : VIDEO_EXTENSIONS.includes(ext) ? 'video' : 'other',
        size: file.size,
        folder: folder,
        createdAt: new Date().toISOString(),
      });
    }

    onProgress?.(Math.round(((i + 1) / files.length) * 100), i + 1, files.length);
  }

  return results;
}

/* ── Delete ────────────────────────────────────────────────── */
export async function deleteMediaFiles(paths: string[]): Promise<{ count: number; errors: number }> {
  if (paths.length === 0) return { count: 0, errors: 0 };

  const { error } = await supabase.storage.from(BUCKET).remove(paths);

  if (error) {
    /* Try one-by-one */
    let removed = 0; let failed = 0;
    for (const p of paths) {
      const { error: e } = await supabase.storage.from(BUCKET).remove([p]);
      e ? failed++ : removed++;
    }
    return { count: removed, errors: failed };
  }

  return { count: paths.length, errors: 0 };
}

/* ── Create Folder ─────────────────────────────────────────── */
export async function createMediaFolder(name: string, parentPath = ''): Promise<{ error: string | null }> {
  const prefix = parentPath ? `${parentPath}/` : '';
  const placeholderPath = `${prefix}${name}/.gitkeep`;

  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(placeholderPath, new Blob(['']), { upsert: false });

  return { error: error?.message ?? null };
}

/* ── Delete Folder ─────────────────────────────────────────── */
export async function deleteMediaFolder(folderPath: string): Promise<{ error: string | null }> {
  /* List all files in folder */
  const { data: list } = await supabase.storage.from(BUCKET).list(folderPath, { limit: 1000 });

  if (list && list.length > 0) {
    const paths = list.map((f) => `${folderPath}/${f.name}`);
    await supabase.storage.from(BUCKET).remove(paths);
  }

  /* Remove the .gitkeep if exists */
  const { error } = await supabase.storage.from(BUCKET).remove([`${folderPath}/.gitkeep`]);
  return { error: error?.message ?? null };
}

/* ── Copy URL (for reuse in product forms etc.) ────────────── */
export function getMediaUrl(path: string): string {
  const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
  return data.publicUrl;
}

/* ── Pull image dimensions from metadata ───────────────────── */
export async function getImageDimensions(path: string): Promise<{ width: number; height: number } | null> {
  try {
    const url = getMediaUrl(path);
    return await new Promise((resolve) => {
      const img = new Image();
      img.onload = () => resolve({ width: img.naturalWidth, height: img.naturalHeight });
      img.onerror = () => resolve(null);
      img.src = url;
    });
  } catch {
    return null;
  }
}
