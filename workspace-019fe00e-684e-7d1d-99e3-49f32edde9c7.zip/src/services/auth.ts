import { supabase } from '@/lib/supabase';
import type { AuthRole, AuthProfile } from '@/types';
import { ROLE_HIERARCHY } from '@/types';
import type { Session, User, AuthError } from '@supabase/supabase-js';

/* ── Auth Service ─────────────────────────────────────────────
   All Supabase auth operations flow through here.
   Pages and contexts never call supabase.auth directly.
*/

/* ── Session ───────────────────────────────────────────────── */
export async function getSession(): Promise<Session | null> {
  const { data } = await supabase.auth.getSession();
  return data.session ?? null;
}

/* ── Sign In ───────────────────────────────────────────────── */
export interface SignInParams {
  email: string;
  password: string;
  rememberMe?: boolean;
}

export async function signIn({ email, password, rememberMe = false }: SignInParams) {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  });

  if (error) return { session: null, user: null, error };

  /* If remember-me is off, configure Supabase to use session-only storage */
  if (!rememberMe && typeof window !== 'undefined') {
    /* Supabase's default is localStorage (persistent).
       For session-only, we rely on the session expiring when browser closes
       since we can't easily swap storage providers mid-session.
       We set a short expiry hint via a custom flag. */
    localStorage.setItem('edition-remember-me', 'false');
  } else {
    localStorage.setItem('edition-remember-me', 'true');
  }

  return { session: data.session, user: data.user, error: null };
}

/* ── Sign Up ───────────────────────────────────────────────── */
export interface SignUpParams {
  email: string;
  password: string;
  fullName: string;
}

export async function signUp({ email, password, fullName }: SignUpParams) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName },
    },
  });

  return { user: data.user, error };
}

/* ── Sign Out ──────────────────────────────────────────────── */
export async function signOut(): Promise<{ error: AuthError | null }> {
  localStorage.removeItem('edition-remember-me');
  const { error } = await supabase.auth.signOut();
  return { error };
}

/* ── Password Reset ────────────────────────────────────────── */
export async function resetPassword(email: string) {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/auth/reset-password`,
  });
  return { error };
}

export async function updatePassword(newPassword: string) {
  const { error } = await supabase.auth.updateUser({ password: newPassword });
  return { error };
}

/* ── Profile / Role ────────────────────────────────────────── */
export async function fetchProfile(userId: string): Promise<AuthProfile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('id, email, role, full_name, avatar_url')
    .eq('id', userId)
    .single();

  if (error || !data) return null;
  return data as AuthProfile;
}

export function mapUserToProfile(user: User, role: AuthRole = 'staff'): AuthProfile {
  return {
    id: user.id,
    email: user.email ?? '',
    role,
    full_name: (user.user_metadata?.full_name as string) ?? user.email?.split('@')[0] ?? 'User',
    avatar_url: undefined,
  };
}

/* ── Role Check ────────────────────────────────────────────── */
export function getRoleFromProfile(profile: AuthProfile | null): AuthRole {
  return profile?.role ?? 'staff';
}

export function hasMinimumRole(userRole: AuthRole, requiredRole: AuthRole): boolean {
  return (ROLE_HIERARCHY[userRole] ?? 0) >= (ROLE_HIERARCHY[requiredRole] ?? 0);
}

/* ── Session Listener ──────────────────────────────────────── */
export function onAuthStateChange(
  callback: (session: Session | null) => void,
) {
  const { data } = supabase.auth.onAuthStateChange((_event, session) => {
    callback(session);
  });
  return data.subscription;
}

/* ── Remember Me ───────────────────────────────────────────── */
export function wasRememberMeRequested(): boolean {
  try {
    return localStorage.getItem('edition-remember-me') !== 'false';
  } catch {
    return true;
  }
}
