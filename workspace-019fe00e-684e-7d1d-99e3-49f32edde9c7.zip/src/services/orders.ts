import { supabase } from '@/lib/supabase';
import type { Order, OrderListParams, OrderListResult, OrderStatus } from '@/types/orders';

/* ── Orders Service ───────────────────────────────────────────
   All Supabase order operations centralized here.
*/

const TABLE = 'orders';

/* ── List ──────────────────────────────────────────────────── */
export async function fetchOrders(params: OrderListParams = {}): Promise<OrderListResult> {
  const {
    search = '',
    status = '',
    paymentStatus = '',
    sort = 'newest',
    page = 1,
    limit = 20,
    dateFrom,
    dateTo,
  } = params;

  let query = supabase
    .from(TABLE)
    .select('*', { count: 'exact' });

  if (search) query = query.or(`number.ilike.%${search}%,customer_name.ilike.%${search}%,customer_email.ilike.%${search}%`);
  if (status) query = query.eq('status', status);
  if (paymentStatus) query = query.eq('payment_status', paymentStatus);
  if (dateFrom) query = query.gte('created_at', dateFrom);
  if (dateTo) query = query.lte('created_at', dateTo);

  switch (sort) {
    case 'oldest':  query = query.order('created_at', { ascending: true }); break;
    case 'total-asc':  query = query.order('total', { ascending: true }); break;
    case 'total-desc': query = query.order('total', { ascending: false }); break;
    case 'number-asc': query = query.order('number', { ascending: true }); break;
    case 'number-desc': query = query.order('number', { ascending: false }); break;
    default: query = query.order('created_at', { ascending: false });
  }

  const from = (page - 1) * limit;
  query = query.range(from, from + limit - 1);

  const { data, error, count } = await query;
  if (error) throw error;
  return { orders: (data as Order[]) ?? [], total: count ?? 0 };
}

/* ── Get Single ────────────────────────────────────────────── */
export async function fetchOrder(id: string): Promise<Order | null> {
  const { data, error } = await supabase
    .from(TABLE)
    .select('*')
    .eq('id', id)
    .single();

  if (error) return null;
  return data as Order;
}

/* ── Update Status ─────────────────────────────────────────── */
export async function updateOrderStatus(
  id: string,
  status: OrderStatus,
  note?: string,
): Promise<{ error: string | null }> {
  const update: Record<string, unknown> = {
    status,
    updated_at: new Date().toISOString(),
  };

  if (note) {
    /* Append activity log */
    const { data: current } = await supabase.from(TABLE).select('activity').eq('id', id).single();
    const existingActivity = (current as { activity?: { id: string; action: string; performed_by: string; timestamp: string; note?: string }[] })?.activity ?? [];
    const newEntry = {
      id: crypto.randomUUID(),
      action: `Status changed to ${status}`,
      performed_by: 'admin',
      timestamp: new Date().toISOString(),
      note,
    };
    update.activity = [...existingActivity, newEntry];
  }

  const { error } = await supabase.from(TABLE).update(update).eq('id', id);
  return { error: error?.message ?? null };
}

/* ── Add Note ──────────────────────────────────────────────── */
export async function addOrderNote(
  id: string,
  note: string,
  performed_by = 'admin',
): Promise<{ error: string | null }> {
  const { data: current } = await supabase.from(TABLE).select('activity').eq('id', id).single();
  const existing = (current as { activity?: { id: string; action: string; performed_by: string; timestamp: string; note?: string }[] })?.activity ?? [];

  const newEntry = {
    id: crypto.randomUUID(),
    action: 'Note added',
    performed_by,
    timestamp: new Date().toISOString(),
    note,
  };

  const { error } = await supabase
    .from(TABLE)
    .update({ activity: [...existing, newEntry], updated_at: new Date().toISOString() })
    .eq('id', id);

  return { error: error?.message ?? null };
}

/* ── Generate Invoice ──────────────────────────────────────── */
export async function generateInvoice(id: string): Promise<{ error: string | null }> {
  const order = await fetchOrder(id);
  if (!order) return { error: 'Order not found' };

  const invoice = {
    ...order.invoice,
    id: crypto.randomUUID(),
    issued_at: new Date().toISOString(),
    status: 'paid' as const,
    paid_at: new Date().toISOString(),
  };

  const { error } = await supabase
    .from(TABLE)
    .update({ invoice, updated_at: new Date().toISOString() })
    .eq('id', id);

  return { error: error?.message ?? null };
}

/* ── Bulk Status Update ────────────────────────────────────── */
export async function bulkUpdateOrderStatus(
  ids: string[],
  status: OrderStatus,
): Promise<{ error: string | null }> {
  const { error } = await supabase
    .from(TABLE)
    .update({ status, updated_at: new Date().toISOString() })
    .in('id', ids);
  return { error: error?.message ?? null };
}
