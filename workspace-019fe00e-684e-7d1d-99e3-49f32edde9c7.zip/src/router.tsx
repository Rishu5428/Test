import { createBrowserRouter } from 'react-router-dom';
import { RootLayout } from '@/layouts/RootLayout';
import { AuthLayout } from '@/layouts/AuthLayout';
import { DashboardLayout } from '@/layouts/DashboardLayout';
import { ProtectedRoute } from '@/components/auth/ProtectedRoute';
import HomePage from '@/pages/HomePage';

function lazyPage(importer: () => Promise<{ default: React.ComponentType }>) {
  return async () => { const mod = await importer(); return { Component: mod.default }; };
}

export const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'collections', lazy: lazyPage(() => import('@/pages/CollectionsPage')) },
      { path: 'products/:id', lazy: lazyPage(() => import('@/pages/ProductDetailPage')) },
      { path: 'wishlist', lazy: lazyPage(() => import('@/pages/WishlistPage')) },
      { path: 'checkout', lazy: lazyPage(() => import('@/pages/CheckoutPage')) },
      { path: '*', lazy: lazyPage(() => import('@/pages/NotFoundPage')) },
    ],
  },
  {
    path: '/auth',
    element: <AuthLayout />,
    children: [
      { path: 'login', lazy: lazyPage(() => import('@/pages/LoginPage')) },
      { path: 'register', lazy: lazyPage(() => import('@/pages/RegisterPage')) },
      { path: 'reset-password', lazy: lazyPage(() => import('@/pages/ResetPasswordPage')) },
    ],
  },
  {
    path: '/dashboard',
    element: (<ProtectedRoute minRole="staff"><DashboardLayout /></ProtectedRoute>),
    children: [
      { index: true, lazy: lazyPage(() => import('@/pages/DashboardPage')) },
      { path: 'products', lazy: lazyPage(() => import('@/pages/dashboard/ProductsListPage')) },
      { path: 'products/:id', lazy: lazyPage(() => import('@/pages/dashboard/ProductFormPage')) },
      { path: 'orders', lazy: lazyPage(() => import('@/pages/dashboard/OrdersListPage')) },
      { path: 'orders/:id', lazy: lazyPage(() => import('@/pages/dashboard/OrderDetailPage')) },
      { path: 'analytics', lazy: lazyPage(() => import('@/pages/dashboard/AnalyticsPage')) },
      { path: 'media', lazy: lazyPage(() => import('@/pages/dashboard/MediaLibraryPage')) },
    ],
  },
]);
