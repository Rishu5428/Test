import { useEffect, useRef } from 'react';

/* ── useInfiniteScroll ────────────────────────────────────────
   Triggers `onLoadMore` when the sentinel element intersects the
   viewport. Returns a ref to attach to the sentinel.
*/

interface UseInfiniteScrollOptions {
  onLoadMore: () => void;
  enabled?: boolean;
  rootMargin?: string;
}

export function useInfiniteScroll({
  onLoadMore,
  enabled = true,
  rootMargin = '200px',
}: UseInfiniteScrollOptions) {
  const sentinelRef = useRef<HTMLDivElement | null>(null);
  const callbackRef = useRef(onLoadMore);
  callbackRef.current = onLoadMore;

  useEffect(() => {
    const el = sentinelRef.current;
    if (!el || !enabled) return;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting) {
          callbackRef.current();
        }
      },
      { rootMargin },
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [enabled, rootMargin]);

  return { sentinelRef };
}
