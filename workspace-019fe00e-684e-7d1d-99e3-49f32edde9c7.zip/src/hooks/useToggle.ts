import { useState, useCallback } from 'react';

/** Generic toggle hook for drawers, modals, and panels. */
export function useToggle(initial = false) {
  const [open, setOpen] = useState(initial);
  const on = useCallback(() => setOpen(true), []);
  const off = useCallback(() => setOpen(false), []);
  const toggle = useCallback(() => setOpen((v) => !v), []);
  return { open, on, off, toggle };
}
