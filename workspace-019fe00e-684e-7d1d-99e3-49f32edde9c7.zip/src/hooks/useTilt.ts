import { useRef, useCallback, type RefObject } from 'react';

/* ── useTilt ──────────────────────────────────────────────────
   Returns a ref to attach + handlers for mouse move / leave.
   Applies perspective transform directly to the element for
   a subtle 3D tilt — editorial-grade, capped at ±6°.
*/

interface TiltHandlers {
  ref: RefObject<HTMLDivElement | null>;
  onMouseMove: (e: React.MouseEvent<HTMLDivElement>) => void;
  onMouseLeave: () => void;
}

export function useTilt(maxDeg = 6): TiltHandlers {
  const ref = useRef<HTMLDivElement | null>(null);

  const onMouseMove = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      const el = ref.current;
      if (!el) return;

      const rect = el.getBoundingClientRect();
      const x = e.clientX - rect.left;
      const y = e.clientY - rect.top;
      const cx = rect.width / 2;
      const cy = rect.height / 2;

      const rotateY = ((x - cx) / cx) * maxDeg;
      const rotateX = -((y - cy) / cy) * maxDeg;

      el.style.transition = 'transform 0.1s ease-out';
      el.style.transform = `perspective(1000px) rotateX(${rotateX.toFixed(1)}deg) rotateY(${rotateY.toFixed(1)}deg)`;
    },
    [maxDeg],
  );

  const onMouseLeave = useCallback(() => {
    const el = ref.current;
    if (!el) return;
    el.style.transition = 'transform 0.5s cubic-bezier(0.19, 1, 0.22, 1)';
    el.style.transform = 'perspective(1000px) rotateX(0deg) rotateY(0deg)';
  }, []);

  return { ref, onMouseMove, onMouseLeave };
}

export type { TiltHandlers };
