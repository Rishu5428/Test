import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import type { ProductData } from '@/components/ui/ProductCard';

/* ── WishlistContext ──────────────────────────────────────────
   Global wishlist — localStorage-persisted, add/remove/toggle.
   Same pattern as CartContext for consistency.
*/

interface WishlistContextValue {
  items: ProductData[];
  addItem: (product: ProductData) => void;
  removeItem: (id: string) => void;
  toggleItem: (product: ProductData) => void;
  isWishlisted: (id: string) => boolean;
  itemCount: number;
}

const WishlistContext = createContext<WishlistContextValue | null>(null);

export function useWishlist() {
  const ctx = useContext(WishlistContext);
  if (!ctx) throw new Error('useWishlist must be used within WishlistProvider');
  return ctx;
}

export function WishlistProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<ProductData[]>(() => {
    try {
      const raw = localStorage.getItem('edition-wishlist');
      return raw ? (JSON.parse(raw) as ProductData[]) : [];
    } catch {
      return [];
    }
  });

  /* Persist */
  useEffect(() => {
    localStorage.setItem('edition-wishlist', JSON.stringify(items));
  }, [items]);

  const addItem = useCallback((product: ProductData) => {
    setItems((prev) => {
      if (prev.find((i) => i.id === product.id)) return prev;
      return [...prev, product];
    });
  }, []);

  const removeItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const toggleItem = useCallback((product: ProductData) => {
    setItems((prev) => {
      const exists = prev.find((i) => i.id === product.id);
      if (exists) return prev.filter((i) => i.id !== product.id);
      return [...prev, product];
    });
  }, []);

  const isWishlisted = useCallback(
    (id: string) => items.some((i) => i.id === id),
    [items],
  );

  const itemCount = useMemo(() => items.length, [items]);

  const value = useMemo<WishlistContextValue>(
    () => ({ items, addItem, removeItem, toggleItem, isWishlisted, itemCount }),
    [items, addItem, removeItem, toggleItem, isWishlisted, itemCount],
  );

  return (
    <WishlistContext.Provider value={value}>{children}</WishlistContext.Provider>
  );
}
