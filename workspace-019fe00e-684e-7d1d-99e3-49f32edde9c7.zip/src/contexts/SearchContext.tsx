import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

/* ── SearchContext ────────────────────────────────────────────
   Global search state + keyboard shortcut (⌘K / Ctrl+K).
   Exposes open/close so the Navbar button can trigger it.
*/

interface SearchContextValue {
  open: boolean;
  onOpen: () => void;
  onClose: () => void;
  toggle: () => void;
}

const SearchContext = createContext<SearchContextValue | null>(null);

export function useSearch() {
  const ctx = useContext(SearchContext);
  if (!ctx) throw new Error('useSearch must be used within SearchProvider');
  return ctx;
}

export function SearchProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const onOpen = useCallback(() => setOpen(true), []);
  const onClose = useCallback(() => setOpen(false), []);
  const toggle = useCallback(() => setOpen((v) => !v), []);

  /* ── Keyboard shortcut ──────────────────────────────────── */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setOpen((v) => !v);
      }
      if (e.key === 'Escape' && open) {
        setOpen(false);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open]);

  /* Lock body scroll — preservative: only unlocks if we locked it */
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      /* Only restore if nothing else has changed it in the meantime */
      if (document.body.style.overflow === 'hidden') {
        document.body.style.overflow = prev;
      }
    };
  }, [open]);

  const value = useMemo<SearchContextValue>(
    () => ({ open, onOpen, onClose, toggle }),
    [open, onOpen, onClose, toggle],
  );

  return (
    <SearchContext.Provider value={value}>{children}</SearchContext.Provider>
  );
}
