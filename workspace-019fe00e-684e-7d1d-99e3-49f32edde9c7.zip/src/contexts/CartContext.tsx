import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

/* ── Types ─────────────────────────────────────────────────── */
export interface CartItem {
  id: string;
  name: string;
  price: string;
  qty: number;
  variant: string;
  imageIdx: number;
}

interface CartContextValue {
  open: boolean;
  items: CartItem[];
  onOpen: () => void;
  onClose: () => void;
  toggle: () => void;
  addItem: (item: CartItem) => void;
  removeItem: (id: string) => void;
  updateQty: (id: string, qty: number) => void;
  itemCount: number;
  subtotal: number;
}

const CartContext = createContext<CartContextValue | null>(null);

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [items, setItems] = useState<CartItem[]>(() => {
    try {
      const raw = localStorage.getItem('edition-cart');
      return raw ? (JSON.parse(raw) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  const onOpen = useCallback(() => setOpen(true), []);
  const onClose = useCallback(() => setOpen(false), []);
  const toggle = useCallback(() => setOpen((v) => !v), []);

  /* Persist */
  useEffect(() => {
    localStorage.setItem('edition-cart', JSON.stringify(items));
  }, [items]);

  const addItem = useCallback((item: CartItem) => {
    setItems((prev) => {
      const exists = prev.find((i) => i.id === item.id && i.variant === item.variant);
      if (exists) {
        return prev.map((i) =>
          i.id === item.id && i.variant === item.variant
            ? { ...i, qty: i.qty + item.qty }
            : i,
        );
      }
      return [...prev, item];
    });
  }, []);

  const removeItem = useCallback((id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }, []);

  const updateQty = useCallback((id: string, qty: number) => {
    if (qty <= 0) {
      setItems((prev) => prev.filter((i) => i.id !== id));
    } else {
      setItems((prev) => prev.map((i) => (i.id === id ? { ...i, qty } : i)));
    }
  }, []);

  const itemCount = useMemo(
    () => items.reduce((sum, i) => sum + i.qty, 0),
    [items],
  );

  const subtotal = useMemo(
    () =>
      items.reduce((sum, i) => {
        const p = parseInt(i.price.replace(/[₹,\s]/g, ''), 10);
        return sum + (isNaN(p) ? 0 : p) * i.qty;
      }, 0),
    [items],
  );

  /* Body scroll lock */
  useEffect(() => {
    if (!open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      if (document.body.style.overflow === 'hidden') {
        document.body.style.overflow = prev;
      }
    };
  }, [open]);

  const value = useMemo<CartContextValue>(
    () => ({
      open, items, onOpen, onClose, toggle,
      addItem, removeItem, updateQty, itemCount, subtotal,
    }),
    [open, items, onOpen, onClose, toggle, addItem, removeItem, updateQty, itemCount, subtotal],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
