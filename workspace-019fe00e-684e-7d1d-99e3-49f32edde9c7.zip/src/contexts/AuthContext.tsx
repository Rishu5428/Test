import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import type { Session, User } from '@supabase/supabase-js';
import type { AuthRole, AuthProfile } from '@/types';
import { ROLE_HIERARCHY } from '@/types';
import {
  getSession,
  signIn as authSignIn,
  signUp as authSignUp,
  signOut as authSignOut,
  fetchProfile,
  mapUserToProfile,
  onAuthStateChange,
  type SignInParams,
  type SignUpParams,
} from '@/services/auth';

/* ── AuthContext ────────────────────────────────────────────── */

interface AuthContextValue {
  /* State */
  session: Session | null;
  user: User | null;
  profile: AuthProfile | null;
  role: AuthRole;
  loading: boolean;

  /* Actions */
  signIn: (params: SignInParams) => Promise<{ error: string | null }>;
  signUp: (params: SignUpParams) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;

  /* Checks */
  isAuthenticated: boolean;
  hasRole: (minRole: AuthRole) => boolean;
  isOwner: boolean;
  isManager: boolean;
  isStaff: boolean;
}

const AuthContext = createContext<AuthContextValue | null>(null);

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}

/* ── Provider ──────────────────────────────────────────────── */
export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<AuthProfile | null>(null);
  const [loading, setLoading] = useState(true);

  /* ── Restore session on mount ─────────────────────────── */
  useEffect(() => {
    let cancelled = false;

    const restore = async () => {
      const sess = await getSession();
      if (cancelled) return;

      if (sess?.user) {
        setSession(sess);
        setUser(sess.user);

        /* Try fetching the profile from DB */
        const dbProfile = await fetchProfile(sess.user.id);
        if (dbProfile) {
          setProfile(dbProfile);
        } else {
          /* Fallback — map user metadata to a staff profile */
          setProfile(mapUserToProfile(sess.user, 'staff'));
        }
      }

      setLoading(false);
    };

    restore();

    return () => { cancelled = true; };
  }, []);

  /* ── Subscribe to auth changes ────────────────────────── */
  useEffect(() => {
    const sub = onAuthStateChange(async (newSession) => {
      if (newSession?.user) {
        setSession(newSession);
        setUser(newSession.user);

        const dbProfile = await fetchProfile(newSession.user.id);
        setProfile(dbProfile ?? mapUserToProfile(newSession.user, 'staff'));
      } else {
        setSession(null);
        setUser(null);
        setProfile(null);
      }
    });

    return () => sub.unsubscribe();
  }, []);

  /* ── Actions ──────────────────────────────────────────── */
  const signIn = useCallback(async (params: SignInParams) => {
    const { session: newSession, user: newUser, error } = await authSignIn(params);

    if (error) {
      const msg = error.message === 'Invalid login credentials'
        ? 'Invalid email or password.'
        : error.message;
      return { error: msg };
    }

    if (newSession && newUser) {
      setSession(newSession);
      setUser(newUser);

      const dbProfile = await fetchProfile(newUser.id);
      setProfile(dbProfile ?? mapUserToProfile(newUser, 'staff'));
    }

    return { error: null };
  }, []);

  const signUpHandler = useCallback(async (params: SignUpParams) => {
    const { error } = await authSignUp(params);
    if (error) {
      return { error: error.message };
    }
    return { error: null };
  }, []);

  const signOutHandler = useCallback(async () => {
    await authSignOut();
    setSession(null);
    setUser(null);
    setProfile(null);
  }, []);

  /* ── Derived ──────────────────────────────────────────── */
  const role: AuthRole = profile?.role ?? 'staff';
  const isAuthenticated = !!user;

  const hasRole = useCallback(
    (minRole: AuthRole) => (ROLE_HIERARCHY[role] ?? 0) >= (ROLE_HIERARCHY[minRole] ?? 0),
    [role],
  );

  const value = useMemo<AuthContextValue>(
    () => ({
      session, user, profile, role, loading,
      signIn, signUp: signUpHandler, signOut: signOutHandler,
      isAuthenticated,
      hasRole,
      isOwner: hasRole('owner'),
      isManager: hasRole('manager'),
      isStaff: hasRole('staff'),
    }),
    [session, user, profile, role, loading, signIn, signUpHandler, signOutHandler, isAuthenticated, hasRole],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
