import { Hero } from '@/components/sections/Hero';
import { FeaturedCollections } from '@/components/sections/FeaturedCollections';
import { BestSellers } from '@/components/sections/BestSellers';
import { FeaturedProduct } from '@/components/sections/FeaturedProduct';
import { Craftsmanship } from '@/components/sections/Craftsmanship';
import { WhyChooseUs } from '@/components/sections/WhyChooseUs';
import { Testimonials } from '@/components/sections/Testimonials';
import { InstagramGallery } from '@/components/sections/InstagramGallery';
import { NewsletterCTA } from '@/components/sections/NewsletterCTA';

export default function HomePage() {
  return (
    <>
      <Hero />
      <FeaturedCollections />
      <BestSellers />
      <FeaturedProduct />
      <Craftsmanship />
      <WhyChooseUs />
      <Testimonials />
      <InstagramGallery />
      <NewsletterCTA />
    </>
  );
}
