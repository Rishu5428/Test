import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';

export default function NotFoundPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-md">
      <div className="w-24 h-24 rounded-full bg-charcoal/3 flex items-center justify-center mb-2xl">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" className="text-charcoal/20">
          <circle cx="12" cy="12" r="10"/><path d="M16 16s-1.5-2-4-2-4 2-4 2M9 9h.01M15 9h.01"/>
        </svg>
      </div>
      <Heading as="h2" className="mb-sm">Page not found</Heading>
      <Text variant="body-lg" className="text-charcoal/50 max-w-sm mb-xl">
        The page you&rsquo;re looking for doesn&rsquo;t exist or has been moved.
      </Text>
      <div className="flex items-center gap-3">
        <ButtonLink to="/collections" variant="outline" size="lg">Browse Collections</ButtonLink>
        <ButtonLink to="/" variant="primary" size="lg">Go Home</ButtonLink>
      </div>
    </div>
  );
}
