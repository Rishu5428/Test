import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';

export default function CheckoutPage() {
  return (
    <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-md">
      <div className="w-24 h-24 rounded-full bg-charcoal/3 flex items-center justify-center mb-2xl">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" className="text-charcoal/20">
          <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0"/>
        </svg>
      </div>
      <Heading as="h2" className="mb-sm">Checkout Coming Soon</Heading>
      <Text variant="body-lg" className="text-charcoal/50 max-w-sm mb-xl">
        Our secure checkout experience is being crafted with the same care as our garments. We&rsquo;ll be ready shortly.
      </Text>
      <div className="flex items-center gap-3">
        <ButtonLink to="/collections" variant="outline" size="lg">Continue Shopping</ButtonLink>
        <ButtonLink to="/" variant="primary" size="lg">Go Home</ButtonLink>
      </div>
    </div>
  );
}
