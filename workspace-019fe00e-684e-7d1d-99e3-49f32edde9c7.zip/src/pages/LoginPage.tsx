import { useState, useCallback, type FormEvent, useEffect } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';

/* ── Icons ─────────────────────────────────────────────────── */
function MailIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <rect x="2" y="4" width="20" height="16" rx="2" /><path d="M22 4L12 13 2 4" />
    </svg>
  );
}
function LockIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <rect x="3" y="11" width="18" height="11" rx="2" /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  );
}
function EyeIcon({ on }: { on: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      {on ? (
        <>
          <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
          <circle cx="12" cy="12" r="3" />
        </>
      ) : (
        <>
          <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
          <line x1="1" y1="1" x2="23" y2="23" />
        </>
      )}
    </svg>
  );
}

/* ── LoginPage ──────────────────────────────────────────────── */
export default function LoginPage() {
  const { signIn, isAuthenticated, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [rememberMe, setRememberMe] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  /* Redirect if already logged in */
  useEffect(() => {
    if (isAuthenticated && !authLoading) {
      const redirect = searchParams.get('redirect') ?? '/dashboard';
      navigate(redirect, { replace: true });
    }
  }, [isAuthenticated, authLoading, navigate, searchParams]);

  const handleSubmit = useCallback(
    async (e: FormEvent) => {
      e.preventDefault();
      setError('');
      setSubmitting(true);

      const result = await signIn({ email, password, rememberMe });
      setSubmitting(false);

      if (result.error) {
        setError(result.error);
      }
      /* Redirect happens via useEffect above */
    },
    [email, password, rememberMe, signIn],
  );

  if (authLoading) {
    return (
      <div className="flex justify-center py-2xl">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full"
        />
      </div>
    );
  }

  return (
    <div>
      <div className="text-center mb-xl">
        <Heading as="h3" className="mb-sm">Welcome back</Heading>
        <Text variant="body-sm" className="text-charcoal/50">
          Sign in to access your dashboard
        </Text>
      </div>

      <form onSubmit={handleSubmit} className="space-y-lg">
        {/* ── Email ────────────────────────────────────────── */}
        <div>
          <label htmlFor="login-email" className="block text-xs font-medium text-charcoal/70 mb-1.5">
            Email
          </label>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal/25">
              <MailIcon />
            </span>
            <input
              id="login-email"
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(''); }}
              required
              autoComplete="email"
              placeholder="you@example.com"
              className="w-full pl-10 pr-4 py-3 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors"
            />
          </div>
        </div>

        {/* ── Password ─────────────────────────────────────── */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label htmlFor="login-password" className="text-xs font-medium text-charcoal/70">
              Password
            </label>
            <Link
              to="/auth/reset-password"
              className="text-xs text-charcoal/40 hover:text-gold transition-colors"
            >
              Forgot?
            </Link>
          </div>
          <div className="relative">
            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal/25">
              <LockIcon />
            </span>
            <input
              id="login-password"
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => { setPassword(e.target.value); setError(''); }}
              required
              autoComplete="current-password"
              placeholder="••••••••"
              className="w-full pl-10 pr-12 py-3 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors"
            />
            <button
              type="button"
              onClick={() => setShowPassword((v) => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-charcoal/30 hover:text-charcoal/60 transition-colors"
              aria-label={showPassword ? 'Hide password' : 'Show password'}
            >
              <EyeIcon on={showPassword} />
            </button>
          </div>
        </div>

        {/* ── Remember Me ──────────────────────────────────── */}
        <div className="flex items-center gap-2">
          <button
            id="login-remember"
            type="button"
            onClick={() => setRememberMe((v) => !v)}
            className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${
              rememberMe ? 'bg-gold border-gold' : 'border-charcoal/20'
            }`}
          >
            {rememberMe && (
              <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round">
                <path d="M20 6L9 17l-5-5" />
              </svg>
            )}
          </button>
          <label
            htmlFor="login-remember"
            className="text-xs text-charcoal/50 cursor-pointer select-none"
            onClick={() => setRememberMe((v) => !v)}
          >
            Keep me signed in
          </label>
        </div>

        {/* ── Error ────────────────────────────────────────── */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-3 rounded-md bg-red-50 border border-red-100 text-xs text-red-600"
          >
            {error}
          </motion.div>
        )}

        {/* ── Submit ───────────────────────────────────────── */}
        <Button
          type="submit"
          variant="primary"
          size="lg"
          loading={submitting}
          className="w-full"
        >
          Sign In
        </Button>
      </form>

      {/* ── Footer ─────────────────────────────────────────── */}
      <div className="mt-xl pt-lg border-t border-charcoal/5 text-center">
        <Text variant="body-sm" className="text-charcoal/40">
          Don&rsquo;t have an account?{' '}
          <Link to="/auth/register" className="text-gold hover:underline font-medium">
            Request access
          </Link>
        </Text>
      </div>
    </div>
  );
}
