import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';
import { ProductCard } from '@/components/ui/ProductCard';
import { useWishlist } from '@/contexts/WishlistContext';
import { useCart } from '@/contexts/CartContext';
import { CollectionBanner } from '@/components/sections/CollectionBanner';
import {
  fadeIn,
  staggerContainer,
  transition,
} from '@/utils/animation';

/* ── Icons ─────────────────────────────────────────────────── */
function TrashIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

function CartIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
    </svg>
  );
}

/* ── WishlistPage ───────────────────────────────────────────── */
export default function WishlistPage() {
  const { items, removeItem, itemCount } = useWishlist();
  const { addItem: addToCart } = useCart();

  const isEmpty = items.length === 0;

  return (
    <div className="-mx-md">
      {/* ── Banner ─────────────────────────────────────────── */}
      <CollectionBanner
        overline="Curated"
        title="Your Wishlist"
        subtitle="Pieces you've saved. Each one chosen with intention — ready when you are."
        totalProducts={itemCount > 0 ? itemCount : undefined}
        background="from-charcoal/3 via-ivory to-gold/5"
      />

      <div className="px-md pb-4xl">
        {isEmpty ? (
          /* ── Empty State ─────────────────────────────────── */
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="flex flex-col items-center justify-center py-4xl text-center"
          >
            <motion.div
              variants={fadeIn}
              className="w-24 h-24 rounded-full bg-charcoal/3 flex items-center justify-center mb-xl"
            >
              <svg
                width="36"
                height="36"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="1"
                strokeLinecap="round"
                className="text-charcoal/20"
              >
                <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
              </svg>
            </motion.div>
            <motion.div variants={fadeIn}>
              <Heading as="h3" className="mb-sm">
                Your wishlist is empty
              </Heading>
            </motion.div>
            <motion.div variants={fadeIn}>
              <Text variant="body-lg" className="text-charcoal/50 max-w-md mb-xl">
                Save pieces you love by tapping the heart icon on any product.
                We&rsquo;ll keep them here until you&rsquo;re ready.
              </Text>
            </motion.div>
            <motion.div variants={fadeIn}>
              <ButtonLink to="/collections" variant="primary" size="lg">
                Discover the Collection
              </ButtonLink>
            </motion.div>
          </motion.div>
        ) : (
          /* ── Grid ────────────────────────────────────────── */
          <motion.div
            variants={staggerContainer}
            initial="hidden"
            animate="visible"
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-lg"
          >
            {items.map((product) => (
              <motion.div
                key={product.id}
                variants={fadeIn}
                className="relative group"
              >
                {/* Product Card */}
                <ProductCard
                  product={product}
                  aspectRatio="aspect-[3/4]"
                  showWishlist={false}
                  showAddToCart={false}
                  showQuickView
                  showRating
                  enableTilt
                />

                {/* ── Actions Overlay ─────────────────────────── */}
                <div className="mt-sm flex items-center gap-3">
                  {/* Move to Cart */}
                  <motion.button
                    type="button"
                    onClick={() => {
                      addToCart({
                        id: product.id,
                        name: product.name,
                        price: product.price,
                        qty: 1,
                        variant: 'M / Noir',
                        imageIdx: 0,
                      });
                    }}
                    whileTap={{ scale: 0.96 }}
                    className="flex items-center gap-2 px-4 py-2 text-xs font-medium text-ivory bg-charcoal rounded-md hover:bg-charcoal/90 transition-colors"
                  >
                    <CartIcon />
                    Move to Cart
                  </motion.button>

                  {/* Remove */}
                  <motion.button
                    type="button"
                    onClick={() => removeItem(product.id)}
                    whileTap={{ scale: 0.9 }}
                    className="p-2 text-charcoal/30 hover:text-charcoal/60 transition-colors rounded-full"
                    aria-label={`Remove ${product.name} from wishlist`}
                  >
                    <TrashIcon />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>

      {/* ── Continue Shopping ───────────────────────────────── */}
      {!isEmpty && (
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={transition.reveal}
          className="px-md pb-4xl text-center"
        >
          <div className="border-t border-charcoal/10 pt-2xl">
            <Text variant="body-sm" className="text-charcoal/40 mb-lg">
              Something else in mind?
            </Text>
            <ButtonLink to="/collections" variant="outline" size="lg">
              Continue Shopping
            </ButtonLink>
          </div>
        </motion.div>
      )}
    </div>
  );
}
