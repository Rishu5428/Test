import { useAuth } from '@/contexts/AuthContext';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { motion } from 'framer-motion';
import { fadeIn, staggerContainer } from '@/utils/animation';

/* ── Icons ─────────────────────────────────────────────────── */
function UserIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" /><circle cx="12" cy="7" r="4" />
    </svg>
  );
}
function ShieldIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  );
}

/* ── DashboardPage ────────────────────────────────────────────
   Placeholder — full dashboard UI to be built separately.
   Shows current user info + auth state as a foundation.
*/

export default function DashboardPage() {
  const { profile, role, signOut, isOwner, isManager } = useAuth();

  const roleLabel =
    role === 'owner' ? 'Owner' :
    role === 'manager' ? 'Manager' : 'Staff';

  const roleBadgeClass =
    role === 'owner'
      ? 'bg-gold/10 text-gold border-gold/20'
      : role === 'manager'
        ? 'bg-charcoal/5 text-charcoal/60 border-charcoal/15'
        : 'bg-charcoal/3 text-charcoal/40 border-charcoal/10';

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="visible"
      className="py-3xl max-w-3xl"
    >
      {/* ── Header ─────────────────────────────────────────── */}
      <motion.div variants={fadeIn} className="mb-2xl">
        <div className="flex items-center gap-3 mb-sm">
          <span className="text-gold"><ShieldIcon /></span>
          <Text variant="overline">Dashboard</Text>
        </div>
        <Heading as="h2" className="mb-sm">Welcome, {profile?.full_name ?? 'User'}</Heading>
        <Text variant="body-sm" className="text-charcoal/50">
          This is a protected area. Full dashboard UI coming soon.
        </Text>
      </motion.div>

      {/* ── Profile Card ───────────────────────────────────── */}
      <motion.div
        variants={fadeIn}
        className="p-xl rounded-lg border border-charcoal/10 bg-ivory shadow-subtle mb-xl"
      >
        <div className="flex items-center gap-lg">
          {/* Avatar */}
          <div className="w-14 h-14 rounded-full bg-charcoal/5 flex items-center justify-center flex-shrink-0">
            {profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt={profile.full_name}
                className="w-full h-full rounded-full object-cover"
              />
            ) : (
              <span className="text-charcoal/30"><UserIcon /></span>
            )}
          </div>

          <div className="flex-1 min-w-0">
            <p className="font-heading text-lg font-semibold text-charcoal">
              {profile?.full_name ?? '—'}
            </p>
            <Text variant="body-sm" className="text-charcoal/50">
              {profile?.email ?? '—'}
            </Text>
          </div>

          <span
            className={`px-3 py-1 rounded-full text-[11px] font-medium border ${roleBadgeClass}`}
          >
            {roleLabel}
          </span>
        </div>

        {/* ── Quick Stats ──────────────────────────────────── */}
        <div className="grid grid-cols-2 md:grid-cols-3 gap-lg mt-xl pt-xl border-t border-charcoal/5">
          {[
            { label: 'Role', value: roleLabel },
            { label: 'Access Level', value: isOwner ? 'Full' : isManager ? 'Elevated' : 'Standard' },
            { label: 'Status', value: 'Active' },
          ].map((stat) => (
            <div key={stat.label}>
              <Text variant="caption" as="div" className="mb-0.5">{stat.label}</Text>
              <Text variant="body-sm" weight="medium" className="text-charcoal">{stat.value}</Text>
            </div>
          ))}
        </div>
      </motion.div>

      {/* ── Logout ──────────────────────────────────────────── */}
      <motion.div variants={fadeIn}>
        <Button
          onClick={signOut}
          variant="outline"
          size="md"
          className="text-charcoal/50 hover:text-charcoal"
        >
          Sign Out
        </Button>
      </motion.div>
    </motion.div>
  );
}
