import { useState, useCallback, useMemo } from 'react';
import { motion } from 'framer-motion';
import { useToggle } from '@/hooks/useToggle';
import { useInfiniteScroll } from '@/hooks/useInfiniteScroll';
import { CollectionBanner } from '@/components/sections/CollectionBanner';
import {
  FilterSidebar,
  type FilterState,
} from '@/components/sections/FilterSidebar';
import { ProductCard } from '@/components/ui/ProductCard';
import { Text } from '@/components/ui/Typography';
import { generateProducts } from '@/utils/products';
import {
  fadeIn,
  staggerImmediate,
} from '@/utils/animation';

/* ── Constants ──────────────────────────────────────────────── */
const INITIAL_LOAD = 12;
const LOAD_MORE = 8;
const MAX_PRODUCTS = 64;

/* ── CollectionsPage ────────────────────────────────────────── */
export default function CollectionsPage() {
  const filterDrawer = useToggle(false);
  const [filters, setFilters] = useState<FilterState>({
    category: [],
    material: [],
    priceRange: null,
    sort: 'featured',
  });
  const [visibleCount, setVisibleCount] = useState(INITIAL_LOAD);
  const [loadingMore, setLoadingMore] = useState(false);

  /* Generate all products once (memoized) */
  const allProducts = useMemo(() => generateProducts(0, MAX_PRODUCTS), []);

  /* Apply filters & sort */
  const filteredProducts = useMemo(() => {
    let result = [...allProducts];

    if (filters.category.length > 0) {
      result = result.filter((p) => filters.category.includes(p.category));
    }

    if (filters.priceRange) {
      result = result.filter((p) => {
        const price = parseInt(p.price.replace(/[₹,\s]/g, ''), 10);
        if (filters.priceRange === 'under-50k') return price < 50000;
        if (filters.priceRange === '50k-100k') return price >= 50000 && price < 100000;
        if (filters.priceRange === '100k-200k') return price >= 100000 && price < 200000;
        if (filters.priceRange === 'over-200k') return price >= 200000;
        return true;
      });
    }

    const getPrice = (p: typeof allProducts[number]) =>
      parseInt(p.price.replace(/[₹,\s]/g, ''), 10);

    switch (filters.sort) {
      case 'price-asc':
        result.sort((a, b) => getPrice(a) - getPrice(b));
        break;
      case 'price-desc':
        result.sort((a, b) => getPrice(b) - getPrice(a));
        break;
      case 'rating':
        result.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
        break;
      case 'newest':
        /* Reverse as newest are at the end of our generated list */
        result.reverse();
        break;
      default:
        /* featured — keep original */
        break;
    }

    return result;
  }, [allProducts, filters]);

  /* Visible slice */
  const visibleProducts = useMemo(
    () => filteredProducts.slice(0, visibleCount),
    [filteredProducts, visibleCount],
  );

  const hasMore = visibleCount < filteredProducts.length;

  /* Infinite scroll handler */
  const handleLoadMore = useCallback(() => {
    if (!hasMore || loadingMore) return;
    setLoadingMore(true);
    /* simulate async */
    setTimeout(() => {
      setVisibleCount((prev) => Math.min(prev + LOAD_MORE, filteredProducts.length));
      setLoadingMore(false);
    }, 400);
  }, [hasMore, loadingMore, filteredProducts.length]);

  const { sentinelRef } = useInfiniteScroll({
    onLoadMore: handleLoadMore,
    enabled: hasMore && !loadingMore,
  });

  /* Reset visible count when filters change */
  const handleFilterChange = useCallback(
    (f: FilterState) => {
      setFilters(f);
      setVisibleCount(INITIAL_LOAD);
    },
    [],
  );

  return (
    <div className="-mx-md">
      {/* ── Banner ─────────────────────────────────────────── */}
      <CollectionBanner totalProducts={filteredProducts.length} />

      {/* ── Content Area ───────────────────────────────────── */}
      <div className="px-md pb-3xl">
        {/* Mobile filter toggle */}
        <div className="flex items-center justify-between lg:hidden mb-lg">
          <motion.button
            type="button"
            onClick={filterDrawer.on}
            className="flex items-center gap-2 py-2 px-4 rounded-md border border-charcoal/20 text-sm font-medium text-charcoal hover:border-charcoal/40 transition-colors"
            whileTap={{ scale: 0.97 }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
              <path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z" />
            </svg>
            Filters
            {(filters.category.length > 0 ||
              filters.material.length > 0 ||
              filters.priceRange ||
              filters.sort !== 'featured') && (
              <span className="w-2 h-2 rounded-full bg-gold" />
            )}
          </motion.button>

          <Text variant="body-sm" className="text-charcoal/50">
            {filteredProducts.length} results
          </Text>
        </div>

        {/* Desktop: sidebar + grid layout */}
        <div className="flex gap-xl">
          {/* Filter Sidebar */}
          <FilterSidebar
            filters={filters}
            onChange={handleFilterChange}
            open={filterDrawer.open}
            onClose={filterDrawer.off}
            totalResults={filteredProducts.length}
          />

          {/* Product Grid */}
          <div className="flex-1 min-w-0">
            {filteredProducts.length === 0 ? (
              <motion.div
                variants={fadeIn}
                initial="hidden"
                animate="visible"
                className="flex flex-col items-center justify-center py-4xl text-center"
              >
                <Text variant="body-lg" className="text-charcoal/40 mb-md">
                  No products match your filters.
                </Text>
                <motion.button
                  type="button"
                  onClick={() =>
                    handleFilterChange({
                      category: [],
                      material: [],
                      priceRange: null,
                      sort: 'featured',
                    })
                  }
                  className="text-sm text-gold hover:underline"
                  whileTap={{ scale: 0.97 }}
                >
                  Clear all filters
                </motion.button>
              </motion.div>
            ) : (
              <>
                <motion.div
                  variants={staggerImmediate}
                  initial="hidden"
                  animate="visible"
                  key={`page-${filters.sort}-${filters.priceRange}-${filters.category.join('-')}-${visibleCount}`}
                  className="grid grid-cols-2 md:grid-cols-3 gap-lg"
                >
                  {visibleProducts.map((product) => (
                    <motion.div key={product.id} variants={fadeIn}>
                      <ProductCard product={product} aspectRatio="aspect-[3/4]" />
                    </motion.div>
                  ))}
                </motion.div>

                {/* Loading indicator */}
                {loadingMore && (
                  <div className="flex justify-center py-xl">
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                      className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full"
                    />
                  </div>
                )}

                {/* Sentinel for infinite scroll */}
                <div
                  ref={sentinelRef}
                  className="h-1"
                  aria-hidden
                />
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
