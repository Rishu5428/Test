import { useMemo } from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { ProductCard } from '@/components/ui/ProductCard';
import { Gallery } from '@/components/product/Gallery';
import { StickyBuyPanel } from '@/components/product/StickyBuyPanel';
import { ProductAccordion } from '@/components/product/ProductAccordion';
import { generateProductDetail } from '@/utils/productDetail';
import { generateProducts } from '@/utils/products';
import {
  fadeIn,
  staggerContainer,
  staggerImmediate,
} from '@/utils/animation';

/* ── ProductDetailPage ──────────────────────────────────────── */

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const product = useMemo(() => generateProductDetail(id ?? 'prod-0'), [id]);

  /* Related: next 4 products in the catalogue */
  const related = useMemo(() => {
    const idx = parseInt(id?.replace(/\D/g, '') ?? '0', 10);
    return generateProducts(idx + 1, 4);
  }, [id]);

  /* Recently viewed: a slightly different set */
  const recentlyViewed = useMemo(() => {
    const idx = parseInt(id?.replace(/\D/g, '') ?? '0', 10) + 5;
    return generateProducts(idx, 4);
  }, [id]);

  return (
    <div className="-mx-md">
      {/* ── Breadcrumb ──────────────────────────────────────── */}
      <div className="px-md pt-lg pb-0">
        <motion.div
          variants={fadeIn}
          initial="hidden"
          animate="visible"
          className="flex items-center gap-2 text-xs text-charcoal/40"
        >
          <Link to="/" className="hover:text-gold transition-colors">Home</Link>
          <span>/</span>
          <Link to="/collections" className="hover:text-gold transition-colors">Collections</Link>
          <span>/</span>
          <span className="text-charcoal/60">{product.name}</span>
        </motion.div>
      </div>

      {/* ── Main Product Layout ─────────────────────────────── */}
      <div className="px-md py-2xl grid grid-cols-1 lg:grid-cols-[1fr_420px] gap-3xl">
        {/* Gallery */}
        <div>
          <Gallery images={product.gallery} alt={product.name} />
        </div>

        {/* Sticky Buy Panel */}
        <div>
          <StickyBuyPanel
            name={product.name}
            category={product.category}
            price={product.price}
            rating={product.rating ?? 4.5}
            sku={product.sku}
            variantGroups={product.variants}
          />
        </div>
      </div>

      {/* ── Accordion (Description / Care / Shipping / Returns) ── */}
      <div className="px-md max-w-2xl pb-3xl">
        <ProductAccordion
          description={product.description}
          material={product.materialDetails}
          fit={product.fit}
          care={product.care}
          shipping={product.shipping}
          returns={product.returns}
        />
      </div>

      {/* ── Related Products ─────────────────────────────────── */}
      <section className="px-md pb-3xl">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
        >
          <motion.div variants={fadeIn} className="mb-xl">
            <Text variant="overline" className="mb-sm">You May Also Like</Text>
            <Heading as="h3">Related Products</Heading>
          </motion.div>

          <motion.div
            variants={staggerImmediate}
            className="grid grid-cols-2 md:grid-cols-4 gap-lg"
          >
            {related.map((p) => (
              <motion.div key={p.id} variants={fadeIn}>
                <ProductCard
                  product={p}
                  aspectRatio="aspect-[3/4]"
                  enableTilt={false}
                />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </section>

      {/* ── Recently Viewed ──────────────────────────────────── */}
      <section className="px-md pb-4xl">
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
        >
          <motion.div variants={fadeIn} className="mb-xl">
            <Text variant="overline" className="mb-sm">Continue Exploring</Text>
            <Heading as="h3">Recently Viewed</Heading>
          </motion.div>

          <motion.div
            variants={staggerImmediate}
            className="grid grid-cols-2 md:grid-cols-4 gap-lg"
          >
            {recentlyViewed.map((p) => (
              <motion.div key={p.id} variants={fadeIn}>
                <ProductCard
                  product={p}
                  aspectRatio="aspect-[3/4]"
                  enableTilt={false}
                />
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </section>
    </div>
  );
}
