import { useState, useCallback, useEffect, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { fetchOrders, bulkUpdateOrderStatus } from '@/services/orders';
import type { Order, OrderStatus, OrderListParams } from '@/types/orders';
import { ORDER_STATUSES, PAYMENT_STATUSES } from '@/types/orders';
import { fadeIn } from '@/utils/animation';

/* ── Icons ─────────────────────────────────────────────────── */
function SearchIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>); }
function EyeIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>); }
function ChevronLeftIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>); }
function ChevronRightIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>); }
function ShoppingBagIcon() { return (<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" className="text-charcoal/15"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>); }

function formatINR(n: number): string {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function getStatusStyle(status: OrderStatus): string {
  return ORDER_STATUSES.find((s) => s.value === status)?.color ?? 'bg-charcoal/5 text-charcoal/50';
}

function getPaymentStyle(pStatus: string) {
  return PAYMENT_STATUSES.find((s) => s.value === pStatus)?.color ?? 'bg-charcoal/5 text-charcoal/50';
}

/* ── OrdersListPage ─────────────────────────────────────────── */
export default function OrdersListPage() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [paymentFilter, setPaymentFilter] = useState('');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const limit = 15;

  const params: OrderListParams = useMemo(() => ({
    search, status: statusFilter, paymentStatus: paymentFilter, sort, page, limit,
  }), [search, statusFilter, paymentFilter, sort, page]);

  const load = useCallback(async () => {
    setLoading(true);
    const result = await fetchOrders(params);
    setOrders(result.orders);
    setTotal(result.total);
    setLoading(false);
  }, [params]);

  useEffect(() => { load(); }, [load]);

  const totalPages = Math.ceil(total / limit);

  const toggleSelect = (id: string) => setSelected((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  const toggleAll = () => setSelected(selected.size === orders.length ? new Set() : new Set(orders.map((o) => o.id)));

  const handleBulk = async (status: OrderStatus) => {
    if (!window.confirm(`Update ${selected.size} orders to "${status}"?`)) return;
    await bulkUpdateOrderStatus([...selected], status);
    setSelected(new Set());
    load();
  };

  return (
    <motion.div variants={fadeIn} initial="hidden" animate="visible">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-lg mb-xl">
        <div>
          <Heading as="h4">Orders</Heading>
          <Text variant="body-sm" className="text-charcoal/50 mt-1">
            {total} order{total !== 1 ? 's' : ''} total
          </Text>
        </div>
      </div>

      {/* ── Filters ────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row gap-3 mb-lg">
        <div className="relative flex-1 max-w-sm">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal/25"><SearchIcon /></span>
          <input
            type="text" value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Order #, customer name or email..."
            className="w-full pl-9 pr-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors"
          />
        </div>
        <select value={statusFilter} onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }} className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
          <option value="">All Status</option>
          {ORDER_STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <select value={paymentFilter} onChange={(e) => { setPaymentFilter(e.target.value); setPage(1); }} className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
          <option value="">All Payments</option>
          {PAYMENT_STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
        </select>
        <select value={sort} onChange={(e) => { setSort(e.target.value); setPage(1); }} className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
          <option value="newest">Newest</option>
          <option value="oldest">Oldest</option>
          <option value="total-desc">Total ↓</option>
          <option value="total-asc">Total ↑</option>
        </select>
      </div>

      {/* ── Bulk Actions ───────────────────────────────────── */}
      {selected.size > 0 && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 p-3 mb-lg rounded-md bg-gold/5 border border-gold/20">
          <Text variant="body-sm" className="text-charcoal/70">{selected.size} selected</Text>
          {(['confirmed', 'processing', 'shipped', 'delivered', 'cancelled'] as OrderStatus[]).map((s) => (
            <button key={s} onClick={() => handleBulk(s)} className="text-xs text-charcoal/60 hover:underline font-medium capitalize">{s}</button>
          ))}
        </motion.div>
      )}

      {/* ── Content ─────────────────────────────────────────── */}
      {loading ? (
        <div className="flex justify-center py-4xl">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full" />
        </div>
      ) : orders.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-4xl text-center border border-charcoal/5 rounded-lg">
          <ShoppingBagIcon />
          <Text variant="body-lg" className="text-charcoal/30 mt-lg mb-sm">No orders yet</Text>
          <Text variant="body-sm" className="text-charcoal/25 mb-xl">Orders will appear here once customers start purchasing.</Text>
          <Button onClick={() => navigate('/')} variant="outline" size="sm">View Store</Button>
        </div>
      ) : (
        <div className="border border-charcoal/10 rounded-lg overflow-hidden">
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-charcoal/10 bg-charcoal/2">
                  <th className="text-left p-3 w-10">
                    <button onClick={toggleAll} className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${selected.size === orders.length ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                      {selected.size === orders.length && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>}
                    </button>
                  </th>
                  <th className="text-left p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Order</th>
                  <th className="text-left p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Customer</th>
                  <th className="text-left p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Items</th>
                  <th className="text-right p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Total</th>
                  <th className="text-left p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Status</th>
                  <th className="text-left p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Payment</th>
                  <th className="text-right p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">Date</th>
                  <th className="text-center p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider w-12"></th>
                </tr>
              </thead>
              <tbody>
                {orders.map((o) => (
                  <tr key={o.id} className="border-b border-charcoal/5 hover:bg-charcoal/2 transition-colors">
                    <td className="p-3">
                      <button onClick={() => toggleSelect(o.id)} className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${selected.has(o.id) ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                        {selected.has(o.id) && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>}
                      </button>
                    </td>
                    <td className="p-3">
                      <div>
                        <Link to={`/dashboard/orders/${o.id}`} className="font-medium text-charcoal hover:text-gold transition-colors">#{o.number}</Link>
                        {o.tags?.includes('gift') && <span className="ml-2 px-1.5 py-0.5 rounded text-[9px] bg-gold/10 text-gold">Gift</span>}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-2.5">
                        <div className="w-7 h-7 rounded-full bg-charcoal/5 flex items-center justify-center flex-shrink-0 text-charcoal/30">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                        </div>
                        <div>
                          <p className="text-sm font-medium text-charcoal">{o.customer_name}</p>
                          <Text variant="caption" as="div">{o.customer_email}</Text>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 text-charcoal/60">{o.line_items?.length ?? 0} item{((o.line_items?.length ?? 0) !== 1) ? 's' : ''}</td>
                    <td className="p-3 text-right font-medium text-charcoal tabular-nums">{formatINR(o.total)}</td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${getStatusStyle(o.status)}`}>{o.status}</span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${getPaymentStyle(o.payment_status)}`}>{o.payment_status}</span>
                    </td>
                    <td className="p-3 text-right text-charcoal/50 text-xs whitespace-nowrap">{formatDate(o.created_at)}</td>
                    <td className="p-3 text-center">
                      <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate(`/dashboard/orders/${o.id}`)} className="p-1.5 text-charcoal/30 hover:text-charcoal rounded transition-colors" aria-label="View order"><EyeIcon /></motion.button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-charcoal/5">
            {orders.map((o) => (
              <Link key={o.id} to={`/dashboard/orders/${o.id}`} className="block p-lg hover:bg-charcoal/2 transition-colors">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-sm text-charcoal">#{o.number}</span>
                  <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${getStatusStyle(o.status)}`}>{o.status}</span>
                </div>
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-5 h-5 rounded-full bg-charcoal/5 flex items-center justify-center flex-shrink-0">
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-charcoal/30"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                  </div>
                  <Text variant="body-sm" className="text-charcoal/70">{o.customer_name}</Text>
                </div>
                <div className="flex items-center justify-between">
                  <Text variant="caption" as="span">{o.line_items?.length ?? 0} items &middot; {formatDate(o.created_at)}</Text>
                  <span className="text-sm font-semibold tabular-nums">{formatINR(o.total)}</span>
                </div>
              </Link>
            ))}
          </div>

          {/* ── Pagination ──────────────────────────────────── */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-lg py-3 border-t border-charcoal/10 bg-charcoal/1">
              <Text variant="caption" as="span">Page {page} of {totalPages}</Text>
              <div className="flex items-center gap-1">
                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setPage((v) => Math.max(1, v - 1))} disabled={page <= 1} className="p-1.5 text-charcoal/40 hover:text-charcoal disabled:opacity-20 rounded transition-colors" aria-label="Previous"><ChevronLeftIcon /></motion.button>
                {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                  const start = Math.max(1, Math.min(page - 2, totalPages - 4));
                  const pn = start + i;
                  if (pn > totalPages) return null;
                  return <button key={pn} onClick={() => setPage(pn)} className={`w-8 h-8 text-xs rounded-md transition-colors ${pn === page ? 'bg-charcoal text-ivory' : 'text-charcoal/60 hover:bg-charcoal/5'}`}>{pn}</button>;
                })}
                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setPage((v) => Math.min(totalPages, v + 1))} disabled={page >= totalPages} className="p-1.5 text-charcoal/40 hover:text-charcoal disabled:opacity-20 rounded transition-colors" aria-label="Next"><ChevronRightIcon /></motion.button>
              </div>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
