import { useState, useCallback, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import {
  fetchProducts,
  deleteProduct,
  bulkDeleteProducts,
  bulkUpdateStatus,
  type ProductListParams,
} from '@/services/products';
import type { Product, ProductStatus } from '@/types/products';
import { PRODUCT_CATEGORIES } from '@/types/products';
import { fadeIn } from '@/utils/animation';

/* ── Icons ─────────────────────────────────────────────────── */
function PlusIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>); }
function SearchIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>); }
function EditIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>); }
function TrashIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>); }
function ChevronLeftIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M15 18l-6-6 6-6"/></svg>); }
function ChevronRightIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>); }
function PackageIcon() { return (<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round" className="text-charcoal/15"><path d="M16.5 9.4L7.55 4.24M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></svg>); }

function formatINR(n: number): string {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}

/* ── ProductsListPage ───────────────────────────────────────── */
export default function ProductsListPage() {
  const navigate = useNavigate();
  const [products, setProducts] = useState<Product[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [sort, setSort] = useState('newest');
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const limit = 15;

  const load = useCallback(async () => {
    setLoading(true);
    const params: ProductListParams = { search, status: statusFilter, category: categoryFilter, sort, page, limit };
    const result = await fetchProducts(params);
    setProducts(result.products);
    setTotal(result.total);
    setLoading(false);
  }, [search, statusFilter, categoryFilter, sort, page]);

  useEffect(() => { load(); }, [load]);

  const totalPages = Math.ceil(total / limit);

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleAll = () => {
    if (selected.size === products.length) {
      setSelected(new Set());
    } else {
      setSelected(new Set(products.map((p) => p.id)));
    }
  };

  const handleDelete = async (id: string) => {
    await deleteProduct(id);
    load();
  };

  const handleBulkDelete = async () => {
    if (!window.confirm(`Delete ${selected.size} products?`)) return;
    await bulkDeleteProducts([...selected]);
    setSelected(new Set());
    load();
  };

  const handleBulkStatus = async (status: string) => {
    await bulkUpdateStatus([...selected], status);
    setSelected(new Set());
    load();
  };

  const statusStyles: Record<ProductStatus, string> = {
    published: 'bg-green-100 text-green-700',
    draft: 'bg-charcoal/5 text-charcoal/50',
  };

  const TABLE_HEAD = ['', 'Product', 'Category', 'Price', 'Stock', 'Status', 'Featured', ''];

  return (
    <motion.div variants={fadeIn} initial="hidden" animate="visible">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-lg mb-xl">
        <div>
          <Heading as="h4">Products</Heading>
          <Text variant="body-sm" className="text-charcoal/50 mt-1">
            {total} product{total !== 1 ? 's' : ''} total
          </Text>
        </div>
        <Button onClick={() => navigate('/dashboard/products/new')} variant="primary" size="md">
          <PlusIcon /> Add Product
        </Button>
      </div>

      {/* ── Filters ────────────────────────────────────────── */}
      <div className="flex flex-col sm:flex-row gap-3 mb-lg">
        <div className="relative flex-1 max-w-sm">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal/25"><SearchIcon /></span>
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="Search products..."
            className="w-full pl-9 pr-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors"
          />
        </div>

        <select
          value={statusFilter}
          onChange={(e) => { setStatusFilter(e.target.value); setPage(1); }}
          className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors"
        >
          <option value="">All Status</option>
          <option value="published">Published</option>
          <option value="draft">Draft</option>
        </select>

        <select
          value={categoryFilter}
          onChange={(e) => { setCategoryFilter(e.target.value); setPage(1); }}
          className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors"
        >
          <option value="">All Categories</option>
          {PRODUCT_CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>

        <select
          value={sort}
          onChange={(e) => { setSort(e.target.value); setPage(1); }}
          className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors"
        >
          <option value="newest">Newest</option>
          <option value="name-asc">Name A–Z</option>
          <option value="name-desc">Name Z–A</option>
          <option value="price-asc">Price ↑</option>
          <option value="price-desc">Price ↓</option>
          <option value="stock-low">Low Stock</option>
        </select>
      </div>

      {/* ── Bulk Actions ───────────────────────────────────── */}
      {selected.size > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 p-3 mb-lg rounded-md bg-gold/5 border border-gold/20"
        >
          <Text variant="body-sm" className="text-charcoal/70">{selected.size} selected</Text>
          <button onClick={() => handleBulkStatus('published')} className="text-xs text-green-600 hover:underline font-medium">Publish</button>
          <button onClick={() => handleBulkStatus('draft')} className="text-xs text-charcoal/50 hover:underline font-medium">Unpublish</button>
          <button onClick={handleBulkDelete} className="text-xs text-red-500 hover:underline font-medium ml-auto">Delete</button>
        </motion.div>
      )}

      {/* ── Table ──────────────────────────────────────────── */}
      {loading ? (
        <div className="flex justify-center py-4xl">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full" />
        </div>
      ) : products.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-4xl text-center border border-charcoal/5 rounded-lg">
          <PackageIcon />
          <Text variant="body-lg" className="text-charcoal/30 mt-lg mb-sm">No products yet</Text>
          <Text variant="body-sm" className="text-charcoal/25 mb-xl">Create your first product to get started.</Text>
          <Button onClick={() => navigate('/dashboard/products/new')} variant="outline" size="sm">
            <PlusIcon /> Add Product
          </Button>
        </div>
      ) : (
        <div className="border border-charcoal/10 rounded-lg overflow-hidden">
          {/* Desktop table */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-charcoal/10 bg-charcoal/2">
                  <th className="text-left p-3 w-10">
                    <button onClick={toggleAll} className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${selected.size === products.length ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                      {selected.size === products.length && (
                        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>
                      )}
                    </button>
                  </th>
                  {TABLE_HEAD.filter(Boolean).map((h) => (
                    <th key={h} className="text-left p-3 text-xs font-medium text-charcoal/40 uppercase tracking-wider">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id} className="border-b border-charcoal/5 hover:bg-charcoal/2 transition-colors">
                    <td className="p-3">
                      <button onClick={() => toggleSelect(p.id)} className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${selected.has(p.id) ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                        {selected.has(p.id) && (
                          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>
                        )}
                      </button>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-12 rounded bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center">
                          <div className="w-4 h-6 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                        </div>
                        <div>
                          <Link to={`/dashboard/products/${p.id}`} className="font-medium text-charcoal hover:text-gold transition-colors">{p.name}</Link>
                          <Text variant="caption" as="div" className="text-charcoal/40">{p.sku}</Text>
                        </div>
                      </div>
                    </td>
                    <td className="p-3 text-charcoal/60">{p.category}</td>
                    <td className="p-3 text-charcoal font-medium tabular-nums">{formatINR(p.price)}</td>
                    <td className="p-3">
                      <span className={`tabular-nums text-sm ${p.stock <= p.low_stock_threshold ? 'text-red-500 font-medium' : 'text-charcoal/60'}`}>
                        {p.stock}
                      </span>
                    </td>
                    <td className="p-3">
                      <span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${statusStyles[p.status]}`}>
                        {p.status}
                      </span>
                    </td>
                    <td className="p-3">
                      <div className="flex gap-1">
                        {p.is_featured && <span className="w-2 h-2 rounded-full bg-gold" title="Featured" />}
                        {p.is_bestseller && <span className="w-2 h-2 rounded-full bg-charcoal" title="Bestseller" />}
                      </div>
                    </td>
                    <td className="p-3">
                      <div className="flex items-center gap-1">
                        <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate(`/dashboard/products/${p.id}`)} className="p-1.5 text-charcoal/30 hover:text-charcoal rounded transition-colors" aria-label="Edit"><EditIcon /></motion.button>
                        <motion.button whileTap={{ scale: 0.9 }} onClick={() => { if (window.confirm('Delete this product?')) handleDelete(p.id); }} className="p-1.5 text-charcoal/20 hover:text-red-500 rounded transition-colors" aria-label="Delete"><TrashIcon /></motion.button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile cards */}
          <div className="md:hidden divide-y divide-charcoal/5">
            {products.map((p) => (
              <div key={p.id} className="p-lg">
                <div className="flex items-start gap-3">
                  <button onClick={() => toggleSelect(p.id)} className={`mt-1 w-4 h-4 rounded-xs border flex-shrink-0 flex items-center justify-center ${selected.has(p.id) ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                    {selected.has(p.id) && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>}
                  </button>
                  <div className="w-10 h-12 rounded bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center">
                    <div className="w-4 h-6 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <Link to={`/dashboard/products/${p.id}`} className="font-medium text-sm text-charcoal hover:text-gold transition-colors">{p.name}</Link>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${statusStyles[p.status]} capitalize`}>{p.status}</span>
                      <Text variant="caption" as="span" className="text-charcoal/40">{p.category}</Text>
                    </div>
                    <div className="flex items-center gap-3 mt-1.5">
                      <span className="text-sm font-medium tabular-nums">{formatINR(p.price)}</span>
                      <span className="text-xs text-charcoal/40 tabular-nums">Stock: {p.stock}</span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-1">
                    <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate(`/dashboard/products/${p.id}`)} className="p-1.5 text-charcoal/30 hover:text-charcoal rounded" aria-label="Edit"><EditIcon /></motion.button>
                    <motion.button whileTap={{ scale: 0.9 }} onClick={() => { if (window.confirm('Delete?')) handleDelete(p.id); }} className="p-1.5 text-charcoal/20 hover:text-red-500 rounded" aria-label="Delete"><TrashIcon /></motion.button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* ── Pagination ──────────────────────────────────── */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-lg py-3 border-t border-charcoal/10 bg-charcoal/1">
              <Text variant="caption" as="span">Page {page} of {totalPages}</Text>
              <div className="flex items-center gap-1">
                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setPage((v) => Math.max(1, v - 1))} disabled={page <= 1} className="p-1.5 text-charcoal/40 hover:text-charcoal disabled:opacity-20 rounded transition-colors" aria-label="Previous page"><ChevronLeftIcon /></motion.button>
                {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => {
                  const start = Math.max(1, Math.min(page - 2, totalPages - 4));
                  const p = start + i;
                  if (p > totalPages) return null;
                  return (
                    <button key={p} onClick={() => setPage(p)} className={`w-8 h-8 text-xs rounded-md transition-colors ${p === page ? 'bg-charcoal text-ivory' : 'text-charcoal/60 hover:bg-charcoal/5'}`}>{p}</button>
                  );
                })}
                <motion.button whileTap={{ scale: 0.9 }} onClick={() => setPage((v) => Math.min(totalPages, v + 1))} disabled={page >= totalPages} className="p-1.5 text-charcoal/40 hover:text-charcoal disabled:opacity-20 rounded transition-colors" aria-label="Next page"><ChevronRightIcon /></motion.button>
              </div>
            </div>
          )}
        </div>
      )}
    </motion.div>
  );
}
