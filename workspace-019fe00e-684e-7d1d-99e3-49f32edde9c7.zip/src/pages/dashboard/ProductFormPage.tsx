import { useState, useEffect, useCallback, useRef, type DragEvent, type ChangeEvent } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { fadeIn } from '@/utils/animation';
import { fetchProduct, createProduct, updateProduct } from '@/services/products';
import {
  PRODUCT_CATEGORIES,
  PRODUCT_COLLECTIONS,
  PRODUCT_MATERIALS,
  EMPTY_PRODUCT_FORM,
  type ProductFormData,
  type ProductStatus,
  type ProductCollection,
  type ProductCategory,
  
} from '@/types/products';

/* ── Icons ─────────────────────────────────────────────────── */
function ArrowLeftIcon() { return (<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>); }
function UploadIcon() { return (<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>); }
function PlusIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M12 5v14M5 12h14"/></svg>); }
function XIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>); }

/* ── Field Component ────────────────────────────────────────── */
function Field({ label, error, required, children }: { label: string; error?: string; required?: boolean; children: React.ReactNode }) {
  return (
    <div>
      <label className="block text-xs font-medium text-charcoal/70 mb-1.5">
        {label}{required && <span className="text-gold ml-0.5">*</span>}
      </label>
      {children}
      {error && <p className="text-[11px] text-red-500 mt-1">{error}</p>}
    </div>
  );
}

function FieldRow({ children }: { children: React.ReactNode }) {
  return <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-lg">{children}</div>;
}

/* ── Image Dropzone ────────────────────────────────────────── */
function ImageDropzone({
  existingUrls,
  newFiles,
  onAddFiles,
  onRemoveExisting,
  onRemoveNew,
}: {
  existingUrls: { id: string; url: string }[];
  newFiles: File[];
  onAddFiles: (files: File[]) => void;
  onRemoveExisting: (id: string) => void;
  onRemoveNew: (index: number) => void;
}) {
  const [dragging, setDragging] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const files = Array.from(e.dataTransfer.files).filter((f) => f.type.startsWith('image/'));
    if (files.length) onAddFiles(files);
  };

  const handleFilePick = (e: ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? []);
    if (files.length) onAddFiles(files);
    (e.target as HTMLInputElement).value = '';
  };

  return (
    <Field label="Images" required>
      <div className="flex flex-wrap gap-3">
        {/* Existing */}
        {existingUrls.map((img) => (
          <div key={img.id} className="relative w-20 h-24 rounded-md overflow-hidden border border-charcoal/10 group">
            <div className="w-full h-full bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex items-center justify-center">
              <div className="w-6 h-9 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
            </div>
            <button onClick={() => onRemoveExisting(img.id)} className="absolute top-1 right-1 p-0.5 rounded bg-charcoal/60 text-ivory opacity-0 group-hover:opacity-100 transition-opacity"><XIcon /></button>
          </div>
        ))}

        {/* New previews */}
        {newFiles.map((file, i) => (
          <div key={`new-${i}`} className="relative w-20 h-24 rounded-md overflow-hidden border border-charcoal/10 group">
            <img src={URL.createObjectURL(file)} alt="Preview" className="w-full h-full object-cover" />
            <button onClick={() => onRemoveNew(i)} className="absolute top-1 right-1 p-0.5 rounded bg-charcoal/60 text-ivory opacity-0 group-hover:opacity-100 transition-opacity"><XIcon /></button>
          </div>
        ))}

        {/* Dropzone */}
        <motion.div
          onClick={() => fileRef.current?.click()}
          onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={handleDrop}
          animate={{ borderColor: dragging ? 'var(--color-gold)' : 'rgba(31,31,31,0.15)' }}
          className="w-20 h-24 rounded-md border-2 border-dashed flex flex-col items-center justify-center gap-1 cursor-pointer hover:border-charcoal/40 transition-colors text-charcoal/25"
        >
          <UploadIcon />
          <span className="text-[9px]">Upload</span>
        </motion.div>
        <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={handleFilePick} />
      </div>
    </Field>
  );
}

/* ── ProductFormPage ────────────────────────────────────────── */
export default function ProductFormPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const isEdit = !!id && id !== 'new';

  const [form, setForm] = useState<ProductFormData>(EMPTY_PRODUCT_FORM);
  const [loading, setLoading] = useState(isEdit);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  /* Load existing product */
  useEffect(() => {
    if (!isEdit) return;
    (async () => {
      const product = await fetchProduct(id!);
      if (product) {
        setForm({
          name: product.name,
          description: product.description,
          category: product.category,
          collections: product.collections,
          price: product.price,
          compare_at_price: product.compare_at_price,
          sku: product.sku,
          stock: product.stock,
          low_stock_threshold: product.low_stock_threshold,
          material: product.material,
          care_instructions: product.care_instructions?.length ? product.care_instructions : [''],
          fit: product.fit,
          status: product.status,
          is_featured: product.is_featured,
          is_bestseller: product.is_bestseller,
          seo: product.seo,
          variants: product.variants ?? [],
          newImages: [],
          existingImages: product.images ?? [],
          removedImageIds: [],
        });
      }
      setLoading(false);
    })();
  }, [id, isEdit]);

  const update = useCallback((patch: Partial<ProductFormData>) => {
    setForm((prev) => ({ ...prev, ...patch }));
  }, []);

  /* Care instruction helpers */
  const addCare = () => update({ care_instructions: [...form.care_instructions, ''] });
  const setCare = (i: number, v: string) => {
    const arr = [...form.care_instructions];
    arr[i] = v;
    if (v === '' && i === form.care_instructions.length - 1 && arr.length > 1) {
      arr.pop();
    }
    update({ care_instructions: arr });
  };

  /* Variant helpers */
  const addVariant = () => update({ variants: [...form.variants, { size: 'M', color: 'Noir', stock: 0 }] });
  const setVariant = (i: number, field: string, value: string | number) => {
    const arr = [...form.variants];
    arr[i] = { ...arr[i], [field]: value };
    update({ variants: arr });
  };
  const removeVariant = (i: number) => update({ variants: form.variants.filter((_, j) => j !== i) });

  /* Collection toggle */
  const toggleCollection = (col: ProductCollection) => {
    const next = form.collections.includes(col)
      ? form.collections.filter((c) => c !== col)
      : [...form.collections, col];
    update({ collections: next });
  };

  const handleSubmit = async (status: ProductStatus) => {
    setError('');
    setSuccess('');
    setSaving(true);

    const data: ProductFormData = { ...form, status };

    const result = isEdit
      ? await updateProduct(id!, data)
      : await createProduct(data);

    setSaving(false);

    if (result.error) {
      setError(result.error);
    } else {
      setSuccess(isEdit ? 'Product updated.' : 'Product created.');
      if (!isEdit && result.product) {
        navigate(`/dashboard/products/${result.product.id}`, { replace: true });
      }
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center py-4xl">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full" />
      </div>
    );
  }

  return (
    <motion.div variants={fadeIn} initial="hidden" animate="visible" className="max-w-4xl pb-4xl">
      {/* ── Header ─────────────────────────────────────────── */}
      <div className="flex items-center gap-4 mb-xl">
        <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate('/dashboard/products')} className="p-2 text-charcoal/40 hover:text-charcoal rounded-full transition-colors" aria-label="Back">
          <ArrowLeftIcon />
        </motion.button>
        <div className="flex-1">
          <Heading as="h4">{isEdit ? 'Edit Product' : 'New Product'}</Heading>
          <Text variant="body-sm" className="text-charcoal/50 mt-0.5">
            {isEdit ? `Editing: ${form.name}` : 'Fill in the details below to create a new product.'}
          </Text>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => handleSubmit('draft')} loading={saving}>
            Save Draft
          </Button>
          <Button variant="primary" size="sm" onClick={() => handleSubmit('published')} loading={saving}>
            {isEdit ? 'Update' : 'Publish'}
          </Button>
        </div>
      </div>

      {/* ── Feedback ───────────────────────────────────────── */}
      {error && <div className="p-3 mb-lg rounded-md bg-red-50 border border-red-100 text-xs text-red-600">{error}</div>}
      {success && <div className="p-3 mb-lg rounded-md bg-green-50 border border-green-100 text-xs text-green-700">{success}</div>}

      <div className="space-y-2xl">
        {/* ── Basic Info ────────────────────────────────────── */}
        <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
          <Text variant="caption" as="div" className="mb-lg font-semibold text-charcoal/80">Basic Information</Text>
          <div className="space-y-lg">
            <Field label="Product Name" required>
              <input value={form.name} onChange={(e) => update({ name: e.target.value })} placeholder="The Milan Coat" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
            </Field>

            <Field label="Description" required>
              <textarea value={form.description} onChange={(e) => update({ description: e.target.value })} rows={4} placeholder="Describe the product..." className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors resize-y" />
            </Field>

            <FieldRow>
              <Field label="Category" required>
                <select value={form.category} onChange={(e) => update({ category: e.target.value as ProductCategory })} className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
                  {PRODUCT_CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
                </select>
              </Field>
              <Field label="Material">
                <select value={form.material} onChange={(e) => update({ material: e.target.value })} className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
                  <option value="">Select material</option>
                  {PRODUCT_MATERIALS.map((m) => <option key={m} value={m}>{m}</option>)}
                </select>
              </Field>
              <Field label="Status">
                <select value={form.status} onChange={(e) => update({ status: e.target.value as ProductStatus })} className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
                  <option value="draft">Draft</option>
                  <option value="published">Published</option>
                </select>
              </Field>
            </FieldRow>

            {/* ── Collections ────────────────────────────────── */}
            <Field label="Collections">
              <div className="flex flex-wrap gap-2">
                {PRODUCT_COLLECTIONS.map((col) => {
                  const active = form.collections.includes(col.value);
                  return (
                    <motion.button
                      key={col.value}
                      type="button"
                      whileTap={{ scale: 0.96 }}
                      onClick={() => toggleCollection(col.value)}
                      className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                        active ? 'border-gold bg-gold/10 text-gold' : 'border-charcoal/15 text-charcoal/50 hover:border-charcoal/30'
                      }`}
                    >
                      {col.label}
                    </motion.button>
                  );
                })}
              </div>
            </Field>
          </div>
        </section>

        {/* ── Pricing & Inventory ───────────────────────────── */}
        <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
          <Text variant="caption" as="div" className="mb-lg font-semibold text-charcoal/80">Pricing & Inventory</Text>
          <div className="space-y-lg">
            <FieldRow>
              <Field label="Price (₹)" required>
                <input type="number" value={form.price} onChange={(e) => update({ price: Number(e.target.value) })} placeholder="98000" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
              </Field>
              <Field label="Compare-at Price">
                <input type="number" value={form.compare_at_price ?? ''} onChange={(e) => update({ compare_at_price: e.target.value ? Number(e.target.value) : undefined })} placeholder="120000" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
              </Field>
              <Field label="SKU" required>
                <input value={form.sku} onChange={(e) => update({ sku: e.target.value })} placeholder="EDT-0001-S26" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
              </Field>
            </FieldRow>

            <FieldRow>
              <Field label="Stock" required>
                <input type="number" value={form.stock} onChange={(e) => update({ stock: Number(e.target.value) })} placeholder="50" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
              </Field>
              <Field label="Low Stock Threshold">
                <input type="number" value={form.low_stock_threshold} onChange={(e) => update({ low_stock_threshold: Number(e.target.value) })} placeholder="5" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
              </Field>
              <div className="flex items-end gap-4 pb-1">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <button type="button" onClick={() => update({ is_featured: !form.is_featured })} className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${form.is_featured ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                    {form.is_featured && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>}
                  </button>
                  <span className="text-xs text-charcoal/60">Featured</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <button type="button" onClick={() => update({ is_bestseller: !form.is_bestseller })} className={`w-4 h-4 rounded-xs border flex items-center justify-center transition-colors ${form.is_bestseller ? 'bg-gold border-gold' : 'border-charcoal/20'}`}>
                    {form.is_bestseller && <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>}
                  </button>
                  <span className="text-xs text-charcoal/60">Bestseller</span>
                </label>
              </div>
            </FieldRow>
          </div>
        </section>

        {/* ── Fit & Care ────────────────────────────────────── */}
        <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
          <Text variant="caption" as="div" className="mb-lg font-semibold text-charcoal/80">Fit & Care</Text>
          <div className="space-y-lg">
            <Field label="Fit">
              <input value={form.fit} onChange={(e) => update({ fit: e.target.value })} placeholder="Regular fit — true to size" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
            </Field>
            <Field label="Care Instructions">
              <div className="space-y-2">
                {form.care_instructions.map((ci, i) => (
                  <div key={i} className="flex gap-2">
                    <input value={ci} onChange={(e) => setCare(i, e.target.value)} placeholder="Dry clean only" className="flex-1 px-4 py-2 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
                    {form.care_instructions.length > 1 && (
                      <button onClick={() => { const arr = form.care_instructions.filter((_, j) => j !== i); update({ care_instructions: arr.length ? arr : [''] }); }} className="p-2 text-charcoal/25 hover:text-red-500 transition-colors"><XIcon /></button>
                    )}
                  </div>
                ))}
                <button onClick={addCare} className="flex items-center gap-1 text-xs text-gold hover:underline"><PlusIcon /> Add instruction</button>
              </div>
            </Field>
          </div>
        </section>

        {/* ── Variants ──────────────────────────────────────── */}
        <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
          <div className="flex items-center justify-between mb-lg">
            <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Variants (Size / Colour / Stock)</Text>
            <button onClick={addVariant} className="flex items-center gap-1 text-xs text-gold hover:underline"><PlusIcon /> Add variant</button>
          </div>
          {form.variants.length === 0 ? (
            <Text variant="body-sm" className="text-charcoal/30 italic">No variants defined.</Text>
          ) : (
            <div className="space-y-2">
              {form.variants.map((v, i) => (
                <div key={i} className="flex items-center gap-2 flex-wrap">
                  <input value={v.size} onChange={(e) => setVariant(i, 'size', e.target.value)} placeholder="Size" className="w-20 px-3 py-2 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors" />
                  <input value={v.color} onChange={(e) => setVariant(i, 'color', e.target.value)} placeholder="Colour" className="w-24 px-3 py-2 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors" />
                  <input type="number" value={v.stock} onChange={(e) => setVariant(i, 'stock', Number(e.target.value))} placeholder="Stock" className="w-20 px-3 py-2 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors" />
                  <button onClick={() => removeVariant(i)} className="p-2 text-charcoal/25 hover:text-red-500 transition-colors"><XIcon /></button>
                </div>
              ))}
            </div>
          )}
        </section>

        {/* ── Images ────────────────────────────────────────── */}
        <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
          <ImageDropzone
            existingUrls={form.existingImages}
            newFiles={form.newImages}
            onAddFiles={(files) => update({ newImages: [...form.newImages, ...files] })}
            onRemoveExisting={(imgId) => update({ removedImageIds: [...form.removedImageIds, imgId] })}
            onRemoveNew={(index) => update({ newImages: form.newImages.filter((_, i) => i !== index) })}
          />
        </section>

        {/* ── SEO ───────────────────────────────────────────── */}
        <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
          <Text variant="caption" as="div" className="mb-lg font-semibold text-charcoal/80">SEO</Text>
          <div className="space-y-lg">
            <Field label="Slug">
              <input value={form.seo.slug} onChange={(e) => update({ seo: { ...form.seo, slug: e.target.value } })} placeholder="the-milan-coat" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
            </Field>
            <Field label="Meta Title">
              <input value={form.seo.meta_title} onChange={(e) => update({ seo: { ...form.seo, meta_title: e.target.value } })} placeholder="The Milan Coat — Édition" className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
            </Field>
            <Field label="Meta Description">
              <textarea value={form.seo.meta_description} onChange={(e) => update({ seo: { ...form.seo, meta_description: e.target.value } })} rows={2} placeholder="Hand-crafted Italian wool coat..." className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors resize-y" />
            </Field>
          </div>
        </section>
      </div>

      {/* ── Sticky Bottom Bar ───────────────────────────────── */}
      <div className="fixed bottom-0 left-0 right-0 bg-ivory border-t border-charcoal/10 px-xl py-lg flex items-center justify-between z-30">
        <Text variant="body-sm" className="text-charcoal/40">{isEdit ? 'Editing product' : 'New product'}</Text>
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={() => navigate('/dashboard/products')}>Cancel</Button>
          <Button variant="outline" size="sm" onClick={() => handleSubmit('draft')} loading={saving}>Save Draft</Button>
          <Button variant="primary" size="sm" onClick={() => handleSubmit('published')} loading={saving}>
            {isEdit ? 'Update' : 'Publish'}
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
