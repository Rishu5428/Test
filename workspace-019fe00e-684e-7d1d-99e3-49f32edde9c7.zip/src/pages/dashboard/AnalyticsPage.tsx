import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { fetchAnalytics, type AnalyticsData } from '@/services/analytics';
import { fadeIn, staggerContainer, staggerImmediate, transition } from '@/utils/animation';

/* ── Icons ─────────────────────────────────────────────────── */
function TrendingUpIcon() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M23 6l-9.5 9.5-5-5L1 18"/><path d="M17 6h6v6"/></svg>); }
function DollarIcon() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v12M9 10h4.5a1.5 1.5 0 1 1 0 3H12"/></svg>); }
function PackageIcon() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M16.5 9.4L7.55 4.24M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></svg>); }
function UsersIcon() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/></svg>); }
function ShoppingBagIcon() { return (<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>); }

function formatINR(n: number): string {
  if (n >= 10000000) return `₹ ${(n / 10000000).toFixed(1)} Cr`;
  if (n >= 100000) return `₹ ${(n / 100000).toFixed(1)} L`;
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}
function formatNum(n: number): string {
  return new Intl.NumberFormat('en-IN').format(n);
}

/* ── Stat Card ──────────────────────────────────────────────── */
function StatCard({ label, value, change, icon, accent = false }: {
  label: string; value: string; change: number; icon: React.ReactNode; accent?: boolean;
}) {
  return (
    <motion.div
      variants={fadeIn}
      whileHover={{ y: -2 }}
      transition={transition.normal}
      className={`p-xl rounded-lg border bg-ivory ${accent ? 'border-gold/20' : 'border-charcoal/10'} shadow-subtle`}
    >
      <div className="flex items-center justify-between mb-md">
        <Text variant="caption" as="span" className="text-charcoal/50">{label}</Text>
        <span className={accent ? 'text-gold' : 'text-charcoal/25'}>{icon}</span>
      </div>
      <div className="flex items-baseline gap-3">
        <span className="font-heading text-3xl font-semibold text-charcoal tabular-nums">{value}</span>
        <span className={`flex items-center gap-0.5 text-xs font-medium ${change >= 0 ? 'text-green-600' : 'text-red-500'}`}>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round"><path d={change >= 0 ? 'M18 6l-12 12M6 6h12v12' : 'M6 18L18 6M6 6v12M18 6v12'}/></svg>
          {Math.abs(change)}%
        </span>
      </div>
    </motion.div>
  );
}

/* ── Revenue Line Chart (SVG) ───────────────────────────────── */
function RevenueChart({ data }: { data: { date: string; revenue: number }[] }) {
  const W = 600;
  const H = 240;
  const pad = { top: 20, right: 16, bottom: 28, left: 16 };

  const max = Math.max(...data.map((d) => d.revenue));
  const min = Math.min(...data.map((d) => d.revenue));
  const range = max - min || 1;

  const points = data.map((d, i) => {
    const x = pad.left + (i / Math.max(data.length - 1, 1)) * (W - pad.left - pad.right);
    const y = pad.top + ((max - d.revenue) / range) * (H - pad.top - pad.bottom);
    return `${x},${y}`;
  }).join(' ');

  /* Fill area */
  const fillPoints = `${pad.left},${H - pad.bottom} ${points} ${W - pad.right},${H - pad.bottom}`;

  return (
    <div className="w-full overflow-x-auto">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full h-auto min-w-[500px]" preserveAspectRatio="xMidYMid meet">
        {/* Grid lines */}
        {[0, 0.25, 0.5, 0.75, 1].map((pct) => {
          const y = pad.top + pct * (H - pad.top - pad.bottom);
          return <line key={pct} x1={pad.left} y1={y} x2={W - pad.right} y2={y} stroke="rgba(31,31,31,0.06)" strokeWidth="1" />;
        })}

        {/* Area fill */}
        <polygon points={fillPoints} fill="url(#rvGrad)" />

        {/* Line */}
        <polyline points={points} fill="none" stroke="#B89C5D" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />

        {/* Gradient */}
        <defs>
          <linearGradient id="rvGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#B89C5D" stopOpacity="0.2" />
            <stop offset="100%" stopColor="#B89C5D" stopOpacity="0" />
          </linearGradient>
        </defs>

        {/* Labels */}
        {data.filter((_, i) => i % 5 === 0).map((d, i) => {
          const x = pad.left + ((i * 5) / Math.max(data.length - 1, 1)) * (W - pad.left - pad.right);
          return (
            <text key={d.date} x={x} y={H - 6} textAnchor="middle" className="text-[10px]" fill="rgba(31,31,31,0.3)">
              {new Date(d.date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })}
            </text>
          );
        })}
      </svg>
    </div>
  );
}

/* ── Donut Chart (SVG) ──────────────────────────────────────── */
function DonutChart({ data, size = 160 }: { data: { category: string; percentage: number }[]; size?: number }) {
  const colors = ['#B89C5D', '#2a2a2a', '#8a8a8a', '#c4a882', '#4a4a4a', '#d4c4a2', '#6a6a6a', '#e4d4b2'];
  const cx = size / 2;
  const cy = size / 2;
  const r = (size - 24) / 2;
  let cumulative = 0;

  const slices = data.map((d, i) => {
    const angle = (d.percentage / 100) * 360;
    const startAngle = cumulative;
    cumulative += angle;

    const startRad = ((startAngle - 90) * Math.PI) / 180;
    const endRad = ((startAngle + angle - 90) * Math.PI) / 180;
    const x1 = cx + r * Math.cos(startRad);
    const y1 = cy + r * Math.sin(startRad);
    const x2 = cx + r * Math.cos(endRad);
    const y2 = cy + r * Math.sin(endRad);
    const largeArc = angle > 180 ? 1 : 0;

    return { d: `M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${largeArc} 1 ${x2},${y2} Z`, color: colors[i % colors.length], label: d.category, pct: d.percentage };
  });

  return (
    <div className="flex items-center gap-xl">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {slices.map((s, i) => (
          <motion.path
            key={s.label}
            d={s.d}
            fill={s.color}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: i * 0.08, duration: 0.4 }}
          />
        ))}
        <circle cx={cx} cy={cy} r={r * 0.52} fill="#FAF8F5" />
        <text x={cx} y={cy - 6} textAnchor="middle" className="font-heading text-lg font-bold" fill="#1F1F1F">{data.length}</text>
        <text x={cx} y={cy + 10} textAnchor="middle" className="text-[9px]" fill="rgba(31,31,31,0.4)">Categories</text>
      </svg>

      {/* Legend */}
      <div className="space-y-1.5 text-xs">
        {data.filter((d) => d.percentage >= 3).map((d, i) => (
          <div key={d.category} className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: colors[i % colors.length] }} />
            <span className="text-charcoal/60">{d.category}</span>
            <span className="text-charcoal/30 tabular-nums ml-auto">{d.percentage}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Horizontal Bar ─────────────────────────────────────────── */
function BarRow({ label, value, max, format, color = 'var(--color-gold)' }: {
  label: string; value: number; max: number; format: (v: number) => string; color?: string;
}) {
  const pct = max > 0 ? (value / max) * 100 : 0;
  return (
    <div className="mb-3 last:mb-0">
      <div className="flex items-center justify-between text-xs mb-1">
        <span className="text-charcoal/70 truncate mr-2">{label}</span>
        <span className="text-charcoal tabular-nums font-medium flex-shrink-0">{format(value)}</span>
      </div>
      <div className="h-1.5 rounded-full bg-charcoal/5 overflow-hidden">
        <motion.div
          className="h-full rounded-full"
          style={{ background: color }}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
        />
      </div>
    </div>
  );
}

/* ── Status Bar Chart ───────────────────────────────────────── */
function StatusBars({ data }: { data: { status: string; count: number }[] }) {
  const max = Math.max(...data.map((d) => d.count), 1);
  const colors: Record<string, string> = {
    delivered: '#4ade80', shipped: '#22d3ee', processing: '#c084fc',
    confirmed: '#60a5fa', pending: '#fbbf24', cancelled: '#f87171', refunded: '#9ca3af',
  };

  return (
    <div className="space-y-2">
      {data.map((d) => (
        <div key={d.status} className="flex items-center gap-3">
          <span className="w-14 text-xs text-charcoal/50 capitalize flex-shrink-0">{d.status}</span>
          <div className="flex-1 h-5 rounded bg-charcoal/3 overflow-hidden">
            <motion.div
              className="h-full rounded flex items-center justify-end pr-2"
              style={{ background: colors[d.status] ?? '#9ca3af', opacity: 0.65 }}
              initial={{ width: 0 }}
              animate={{ width: `${(d.count / max) * 100}%` }}
              transition={{ duration: 0.8, ease: [0.19, 1, 0.22, 1] }}
            >
              <span className="text-[10px] font-semibold text-white tabular-nums">{d.count}</span>
            </motion.div>
          </div>
        </div>
      ))}
    </div>
  );
}

/* ── AnalyticsPage ──────────────────────────────────────────── */
export default function AnalyticsPage() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAnalytics().then((d) => { setData(d); setLoading(false); });
  }, []);

  if (loading) {
    return (
      <div className="flex justify-center py-4xl">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full" />
      </div>
    );
  }

  if (!data) return null;

  const { summary, revenueOverTime, categorySales, topProducts, topCustomers, ordersByStatus } = data;

  const maxProdRevenue = Math.max(...topProducts.map((p) => p.revenue), 1);
  const maxCustSpent = Math.max(...topCustomers.map((c) => c.spent), 1);

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="pb-4xl">
      {/* ── Header ─────────────────────────────────────────── */}
      <motion.div variants={fadeIn} className="mb-2xl">
        <div className="flex items-center gap-3 mb-1">
          <span className="text-gold"><TrendingUpIcon /></span>
          <Text variant="overline">Analytics</Text>
        </div>
        <Heading as="h3">Business Overview</Heading>
        <Text variant="body-sm" className="text-charcoal/50 mt-1">
          Last 30 days &middot; All figures in INR
        </Text>
      </motion.div>

      {/* ── Stat Cards ─────────────────────────────────────── */}
      <motion.div variants={staggerImmediate} className="grid grid-cols-2 lg:grid-cols-5 gap-lg mb-2xl">
        <StatCard label="Total Revenue" value={formatINR(summary.totalRevenue)} change={summary.revenueChange} icon={<DollarIcon />} accent />
        <StatCard label="Orders" value={formatNum(summary.totalOrders)} change={summary.ordersChange} icon={<ShoppingBagIcon />} />
        <StatCard label="Products" value={formatNum(summary.totalProducts)} change={summary.productsChange} icon={<PackageIcon />} />
        <StatCard label="Customers" value={formatNum(summary.totalCustomers)} change={summary.customersChange} icon={<UsersIcon />} />
        <StatCard label="Avg. Order" value={formatINR(summary.avgOrderValue)} change={5.2} icon={<DollarIcon />} />
      </motion.div>

      {/* ── Revenue Chart ──────────────────────────────────── */}
      <motion.div variants={fadeIn} className="p-xl rounded-lg border border-charcoal/10 bg-ivory shadow-subtle mb-2xl">
        <div className="flex items-center justify-between mb-lg">
          <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Revenue &mdash; Last 30 Days</Text>
          <Text variant="caption" as="span" className="text-charcoal/30">Daily</Text>
        </div>
        <RevenueChart data={revenueOverTime} />
      </motion.div>

      {/* ── Mid Row: Categories + Status ───────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-2xl mb-2xl">
        {/* Category breakdown */}
        <motion.div variants={fadeIn} className="p-xl rounded-lg border border-charcoal/10 bg-ivory shadow-subtle">
          <Text variant="caption" as="div" className="font-semibold text-charcoal/80 mb-lg">Sales by Category</Text>
          <DonutChart data={categorySales} size={180} />
        </motion.div>

        {/* Orders by Status */}
        <motion.div variants={fadeIn} className="p-xl rounded-lg border border-charcoal/10 bg-ivory shadow-subtle">
          <Text variant="caption" as="div" className="font-semibold text-charcoal/80 mb-lg">Orders by Status</Text>
          <StatusBars data={ordersByStatus} />
        </motion.div>
      </div>

      {/* ── Bottom Row: Top Products + Top Customers ────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-2xl">
        {/* Top Products */}
        <motion.div variants={fadeIn} className="p-xl rounded-lg border border-charcoal/10 bg-ivory shadow-subtle">
          <Text variant="caption" as="div" className="font-semibold text-charcoal/80 mb-lg">Top Products</Text>
          {topProducts.map((p) => (
            <BarRow key={p.id} label={p.name} value={p.revenue} max={maxProdRevenue} format={formatINR} color="var(--color-gold)" />
          ))}
        </motion.div>

        {/* Top Customers */}
        <motion.div variants={fadeIn} className="p-xl rounded-lg border border-charcoal/10 bg-ivory shadow-subtle">
          <Text variant="caption" as="div" className="font-semibold text-charcoal/80 mb-lg">Top Customers</Text>
          {topCustomers.map((c) => (
            <BarRow key={c.id} label={c.name} value={c.spent} max={maxCustSpent} format={formatINR} color="#1F1F1F" />
          ))}
        </motion.div>
      </div>
    </motion.div>
  );
}
