import { useState, useEffect, useCallback, useRef, type DragEvent, type ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { fadeIn, staggerContainer, staggerImmediate, transition } from '@/utils/animation';
import {
  fetchMediaList,
  uploadMediaFiles,
  deleteMediaFiles,
} from '@/services/media';
import type { MediaItem, MediaFolder } from '@/types/media';
import { COMMON_FOLDERS } from '@/types/media';

/* ── Icons ─────────────────────────────────────────────────── */
function UploadIcon() { return (<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/></svg>); }
function SearchIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.35-4.35"/></svg>); }
function FolderIcon() { return (<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>); }
function TrashIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>); }
function CopyIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>); }
function CheckIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>); }
function XIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M18 6L6 18M6 6l12 12"/></svg>); }
function ChevronRightIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M9 18l6-6-6-6"/></svg>); }
function ImageIcon() { return (<svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" strokeLinecap="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>); }

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1048576).toFixed(1)} MB`;
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-IN', { month: 'short', day: 'numeric', year: 'numeric' });
}

/* ── MediaLibraryPage ───────────────────────────────────────── */
export default function MediaLibraryPage() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [folders, setFolders] = useState<MediaFolder[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [currentFolder, setCurrentFolder] = useState('');
  const [sort, setSort] = useState<"newest" | "oldest" | "name-asc" | "name-desc" | "size-asc" | "size-desc">("newest");
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [dragOver, setDragOver] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [previewItem, setPreviewItem] = useState<MediaItem | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [success, setSuccess] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const result = await fetchMediaList({ search, folder: currentFolder, sort, limit: 60 });
    setItems(result.items);
    setFolders(result.folders);
    setTotal(result.total);
    setLoading(false);
  }, [search, currentFolder, sort]);

  useEffect(() => { load(); }, [load]);

  const handleUpload = async (files: File[]) => {
    if (files.length === 0) return;
    setUploading(true);
    setUploadProgress(0);
    const uploaded = await uploadMediaFiles(files, currentFolder, (pct) => setUploadProgress(pct));
    setUploading(false);
    setSuccess(`${uploaded.length} file${uploaded.length !== 1 ? 's' : ''} uploaded to ${currentFolder || 'root'}`);
    setTimeout(() => setSuccess(''), 3000);
    load();
  };

  const handleDrop = (e: DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    handleUpload(Array.from(e.dataTransfer.files));
  };

  const handleFilePick = (e: ChangeEvent<HTMLInputElement>) => {
    handleUpload(Array.from(e.target.files ?? []));
    (e.target as HTMLInputElement).value = '';
  };

  const handleDelete = async (ids: string[]) => {
    if (!window.confirm(`Delete ${ids.length} file${ids.length !== 1 ? 's' : ''}?`)) return;
    const { count, errors } = await deleteMediaFiles(ids);
    setSelected(new Set());
    setSuccess(`${count} deleted${errors > 0 ? `, ${errors} failed` : ''}`);
    setTimeout(() => setSuccess(''), 3000);
    load();
  };

  const handleCopyUrl = (url: string, id: string) => {
    navigator.clipboard.writeText(url).then(() => {
      setCopied(id);
      setTimeout(() => setCopied(null), 2000);
    }).catch(() => {});
  };

  const toggleSelect = (id: string) => {
    setSelected((prev) => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const navigateFolder = (path: string) => {
    setCurrentFolder(path);
    setSearch('');
    setSelected(new Set());
  };

  return (
    <motion.div variants={staggerContainer} initial="hidden" animate="visible" className="pb-4xl">
      {/* ── Header ─────────────────────────────────────── */}
      <motion.div variants={fadeIn} className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-lg mb-xl">
        <div>
          <Heading as="h4">Media Library</Heading>
          <Text variant="body-sm" className="text-charcoal/50 mt-1">
            {total} file{total !== 1 ? 's' : ''} {currentFolder ? `in "${currentFolder}"` : 'total'}
          </Text>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => fileRef.current?.click()} disabled={uploading}>
            <UploadIcon /> Upload
          </Button>
          <input ref={fileRef} type="file" accept="image/*,video/*" multiple className="hidden" onChange={handleFilePick} />
        </div>
      </motion.div>

      {/* ── Feedback ───────────────────────────────────── */}
      {success && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="p-3 mb-lg rounded-md bg-green-50 border border-green-100 text-xs text-green-700">{success}</motion.div>
      )}

      {/* ── Toolbar ────────────────────────────────────── */}
      <motion.div variants={fadeIn} className="flex flex-col sm:flex-row gap-3 mb-lg">
        <div className="relative flex-1 max-w-sm">
          <span className="absolute left-3 top-1/2 -translate-y-1/2 text-charcoal/25"><SearchIcon /></span>
          <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search files..." className="w-full pl-9 pr-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors" />
        </div>
        <select value={sort} onChange={(e) => setSort(e.target.value as "newest" | "oldest" | "name-asc" | "name-desc" | "size-asc" | "size-desc")} className="px-3 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal outline-none focus:border-gold transition-colors">
          <option value="newest">Newest</option><option value="oldest">Oldest</option>
          <option value="name-asc">Name A–Z</option><option value="name-desc">Name Z–A</option>
          <option value="size-asc">Smallest</option><option value="size-desc">Largest</option>
        </select>
      </motion.div>

      {/* ── Folder Breadcrumb ──────────────────────────── */}
      <motion.div variants={fadeIn} className="flex items-center gap-2 mb-lg text-sm">
        <button onClick={() => navigateFolder('')} className={`${!currentFolder ? 'text-gold font-medium' : 'text-charcoal/50 hover:text-charcoal'} transition-colors`}>Library</button>
        {currentFolder.split('/').filter(Boolean).map((seg, i, arr) => {
          const path = arr.slice(0, i + 1).join('/');
          return (
            <span key={path} className="flex items-center gap-2">
              <ChevronRightIcon />
              <button onClick={() => navigateFolder(path)} className="text-charcoal/60 hover:text-charcoal transition-colors">{seg}</button>
            </span>
          );
        })}
      </motion.div>

      {/* ── Folders ────────────────────────────────────── */}
      {!search && folders.length > 0 && (
        <motion.div variants={fadeIn} className="flex flex-wrap gap-3 mb-xl">
          {folders.map((f) => (
            <motion.button
              key={f.path}
              whileTap={{ scale: 0.97 }}
              onClick={() => navigateFolder(f.path)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-charcoal/10 hover:border-gold/30 hover:bg-gold/5 transition-colors text-sm text-charcoal/70"
            >
              <span className="text-gold"><FolderIcon /></span>
              {f.name}
            </motion.button>
          ))}
        </motion.div>
      )}

      {/* ── Quick folders (only at root) ────────────────── */}
      {!search && !currentFolder && folders.length === 0 && (
        <motion.div variants={fadeIn} className="flex flex-wrap gap-3 mb-xl">
          <Text variant="caption" as="span" className="w-full">Suggested folders</Text>
          {COMMON_FOLDERS.map((f) => (
            <motion.button key={f} whileTap={{ scale: 0.97 }} onClick={() => navigateFolder(f)} className="flex items-center gap-2 px-4 py-2.5 rounded-lg border border-charcoal/10 hover:border-gold/30 hover:bg-gold/5 transition-colors text-sm text-charcoal/70">
              <span className="text-charcoal/30"><FolderIcon /></span> {f}
            </motion.button>
          ))}
        </motion.div>
      )}

      {/* ── Bulk Actions ───────────────────────────────── */}
      {selected.size > 0 && (
        <motion.div initial={{ opacity: 0, y: -8 }} animate={{ opacity: 1, y: 0 }} className="flex items-center gap-3 p-3 mb-lg rounded-md bg-gold/5 border border-gold/20">
          <Text variant="body-sm" className="text-charcoal/70">{selected.size} selected</Text>
          <button onClick={() => handleDelete([...selected])} className="text-xs text-red-500 hover:underline font-medium ml-auto">Delete</button>
        </motion.div>
      )}

      {/* ── Upload Zone ────────────────────────────────── */}
      <motion.div
        variants={fadeIn}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => fileRef.current?.click()}
        animate={{ borderColor: dragOver ? 'var(--color-gold)' : 'rgba(31,31,31,0.1)', scale: dragOver ? 1.01 : 1 }}
        className="border-2 border-dashed rounded-lg p-2xl mb-xl text-center cursor-pointer hover:border-charcoal/25 transition-all"
      >
        {uploading ? (
          <div>
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-8 h-8 border-2 border-gold/30 border-t-gold rounded-full mx-auto mb-3" />
            <Text variant="body-sm" className="text-charcoal/50">Uploading... {uploadProgress}%</Text>
            <div className="w-40 h-1.5 rounded-full bg-charcoal/5 mx-auto mt-2 overflow-hidden">
              <motion.div className="h-full bg-gold rounded-full" animate={{ width: `${uploadProgress}%` }} transition={{ duration: 0.3 }} />
            </div>
          </div>
        ) : (
          <>
            <span className="text-charcoal/20"><UploadIcon /></span>
            <Text variant="body-sm" className="text-charcoal/40 mt-3">Drag & drop files here, or click to browse</Text>
            <Text variant="caption" as="p" className="text-charcoal/25 mt-1">Supports JPG, PNG, WebP, GIF, SVG, MP4 — up to 25 MB</Text>
          </>
        )}
      </motion.div>

      {/* ── Content ─────────────────────────────────────── */}
      {loading ? (
        <div className="flex justify-center py-4xl">
          <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full" />
        </div>
      ) : items.length === 0 ? (
        <motion.div variants={fadeIn} className="flex flex-col items-center justify-center py-4xl text-center">
          <span className="text-charcoal/15"><ImageIcon /></span>
          <Text variant="body-lg" className="text-charcoal/30 mt-lg mb-sm">
            {search ? `No results for "${search}"` : currentFolder ? 'This folder is empty' : 'No files yet'}
          </Text>
          <Text variant="body-sm" className="text-charcoal/25 mb-xl">Upload images or videos to get started.</Text>
          {currentFolder && (
            <Button variant="ghost" size="sm" onClick={() => navigateFolder('')}>Back to Library</Button>
          )}
        </motion.div>
      ) : (
        /* ── Grid ────────────────────────────────────── */
        <motion.div variants={staggerImmediate} className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {items.map((item) => {
            const isImage = item.type === 'image';
            const sel = selected.has(item.id);
            return (
              <motion.div
                key={item.id}
                variants={fadeIn}
                whileHover={{ y: -2 }}
                transition={transition.normal}
                className={`relative group rounded-lg overflow-hidden border cursor-pointer transition-colors ${
                  sel ? 'border-gold ring-2 ring-gold/30' : 'border-charcoal/5 hover:border-charcoal/20'
                }`}
              >
                {/* Thumbnail */}
                <div
                  className="aspect-square bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex items-center justify-center"
                  onClick={() => isImage ? setPreviewItem(item) : toggleSelect(item.id)}
                >
                  {isImage ? (
                    <img src={item.url} alt={item.name} className="w-full h-full object-cover" loading="lazy" />
                  ) : (
                    <span className="text-charcoal/20"><ImageIcon /></span>
                  )}
                </div>

                {/* Info overlay */}
                <div className="absolute inset-x-0 bottom-0 p-2 bg-gradient-to-t from-charcoal/70 via-charcoal/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity">
                  <p className="text-[10px] text-white truncate leading-tight">{item.originalName}</p>
                  <p className="text-[9px] text-white/60">{formatSize(item.size)}</p>
                </div>

                {/* Select checkbox */}
                <button
                  onClick={(e) => { e.stopPropagation(); toggleSelect(item.id); }}
                  className={`absolute top-2 left-2 w-5 h-5 rounded-xs border flex items-center justify-center transition-all ${
                    sel ? 'bg-gold border-gold opacity-100' : 'border-white/40 bg-charcoal/30 opacity-0 group-hover:opacity-100'
                  }`}
                >
                  {sel && <CheckIcon />}
                </button>

                {/* Copy URL */}
                <button
                  onClick={(e) => { e.stopPropagation(); handleCopyUrl(item.url, item.id); }}
                  className="absolute top-2 right-8 p-1 rounded bg-charcoal/50 opacity-0 group-hover:opacity-100 transition-opacity text-white/80 hover:text-white"
                  aria-label="Copy URL"
                  title="Copy URL"
                >
                  {copied === item.id ? <CheckIcon /> : <CopyIcon />}
                </button>

                {/* Delete */}
                <button
                  onClick={(e) => { e.stopPropagation(); handleDelete([item.id]); }}
                  className="absolute top-2 right-2 p-1 rounded bg-charcoal/50 opacity-0 group-hover:opacity-100 transition-opacity text-white/80 hover:text-red-400"
                  aria-label="Delete"
                >
                  <TrashIcon />
                </button>
              </motion.div>
            );
          })}
        </motion.div>
      )}

      {/* ── Preview Modal ──────────────────────────────── */}
      <AnimatePresence>
        {previewItem && (
          <motion.div
            variants={fadeIn} initial="hidden" animate="visible" exit="hidden"
            className="fixed inset-0 z-[100] bg-charcoal/80 backdrop-blur-sm flex items-center justify-center p-xl"
            onClick={() => setPreviewItem(null)}
          >
            <button onClick={() => setPreviewItem(null)} className="absolute top-6 right-6 p-2 text-white/60 hover:text-white transition-colors rounded-full" aria-label="Close preview"><XIcon /></button>
            <motion.div
              initial={{ scale: 0.95 }} animate={{ scale: 1 }} exit={{ scale: 0.97 }}
              transition={transition.normal}
              className="max-w-4xl max-h-[85vh] rounded-lg overflow-hidden bg-ivory shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <img src={previewItem.url} alt={previewItem.name} className="max-w-full max-h-[70vh] object-contain" />
              <div className="p-lg bg-ivory flex items-center justify-between flex-wrap gap-4">
                <div className="min-w-0">
                  <Text variant="body-sm" weight="medium" className="text-charcoal truncate">{previewItem.originalName}</Text>
                  <Text variant="caption" as="div">{formatSize(previewItem.size)} &middot; {formatDate(previewItem.createdAt)}</Text>
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleCopyUrl(previewItem.url, previewItem.id)}>
                    {copied === previewItem.id ? <CheckIcon /> : <CopyIcon />} {copied === previewItem.id ? 'Copied' : 'Copy URL'}
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => handleDelete([previewItem.id])} className="text-red-500 hover:text-red-600">
                    <TrashIcon /> Delete
                  </Button>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
