import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { fetchOrder, updateOrderStatus, addOrderNote, generateInvoice } from '@/services/orders';
import type { Order, OrderStatus } from '@/types/orders';
import { ORDER_STATUSES, PAYMENT_STATUSES, SHIPPING_METHODS } from '@/types/orders';
import { fadeIn } from '@/utils/animation';

/* ── Icons ─────────────────────────────────────────────────── */
function ArrowLeftIcon() { return (<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>); }
function TruckIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><rect x="1" y="3" width="15" height="13" rx="1"/><path d="M16 8h4l3 4v4h-3"/><circle cx="6.5" cy="18.5" r="2.5"/><circle cx="17.5" cy="18.5" r="2.5"/></svg>); }
function PackageIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M16.5 9.4L7.55 4.24M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12"/></svg>); }
function ReceiptIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M4 2v20l2-2 2 2 2-2 2 2 2-2 2 2 2-2 2 2V2l-2 2-2-2-2 2-2-2-2 2-2-2-2 2z"/></svg>); }
function UserIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>); }
function MapPinIcon() { return (<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>); }
function ClockIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>); }
function CheckIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round"><path d="M20 6L9 17l-5-5"/></svg>); }

function formatINR(n: number): string {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(n);
}
function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('en-IN', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}
function formatDateTime(iso: string): string {
  return new Date(iso).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}
function getStatusStyle(status: string) {
  return ORDER_STATUSES.find((s) => s.value === status)?.color ?? 'bg-charcoal/5 text-charcoal/50';
}

/* ── OrderDetailPage ────────────────────────────────────────── */
export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [noteText, setNoteText] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    (async () => { const o = await fetchOrder(id!); setOrder(o); setLoading(false); })();
  }, [id]);

  const reload = async () => { const o = await fetchOrder(id!); setOrder(o); };

  const handleStatus = async (status: OrderStatus) => {
    setError(''); setSaving(true);
    await updateOrderStatus(id!, status);
    setSaving(false); setSuccess(`Order marked as "${status}".`);
    setTimeout(() => setSuccess(''), 3000);
    reload();
  };

  const handleNote = async () => {
    if (!noteText.trim()) return;
    setError(''); setSaving(true);
    await addOrderNote(id!, noteText.trim());
    setNoteText(''); setSaving(false);
    reload();
  };

  const handleInvoice = async () => {
    setError(''); setSaving(true);
    const r = await generateInvoice(id!);
    if (r.error) setError(r.error);
    else setSuccess('Invoice generated.');
    setSaving(false);
    setTimeout(() => setSuccess(''), 3000);
    reload();
  };

  if (loading) {
    return (
      <div className="flex justify-center py-4xl">
        <motion.div animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }} className="w-6 h-6 border-2 border-gold/30 border-t-gold rounded-full" />
      </div>
    );
  }

  if (!order) {
    return (
      <div className="text-center py-4xl">
        <Text variant="body-lg" className="text-charcoal/40">Order not found.</Text>
        <Button onClick={() => navigate('/dashboard/orders')} variant="outline" size="sm" className="mt-lg">Back to Orders</Button>
      </div>
    );
  }

  const status = order.status;
  const currentStatusIdx = ORDER_STATUSES.findIndex((s) => s.value === status);

  return (
    <motion.div variants={fadeIn} initial="hidden" animate="visible" className="max-w-5xl pb-4xl">
      {/* ── Top Bar ────────────────────────────────────────── */}
      <div className="flex items-center gap-4 mb-xl">
        <motion.button whileTap={{ scale: 0.9 }} onClick={() => navigate('/dashboard/orders')} className="p-2 text-charcoal/40 hover:text-charcoal rounded-full transition-colors" aria-label="Back"><ArrowLeftIcon /></motion.button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <Heading as="h4">Order #{order.number}</Heading>
            <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-medium ${getStatusStyle(status)}`}>{status}</span>
          </div>
          <Text variant="body-sm" className="text-charcoal/50 mt-0.5">{formatDate(order.created_at)}</Text>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleInvoice} loading={saving}>Generate Invoice</Button>
        </div>
      </div>

      {error && <div className="p-3 mb-lg rounded-md bg-red-50 border border-red-100 text-xs text-red-600">{error}</div>}
      {success && <div className="p-3 mb-lg rounded-md bg-green-50 border border-green-100 text-xs text-green-700">{success}</div>}

      {/* ── Status Timeline ─────────────────────────────────── */}
      <div className="p-xl rounded-lg border border-charcoal/10 bg-ivory mb-2xl">
        <div className="flex items-center gap-2 mb-lg">
          <span className="text-charcoal/40"><ClockIcon /></span>
          <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Order Progress</Text>
        </div>

        <div className="flex items-center justify-between relative">
          {/* Connector line */}
          <div className="absolute top-4 left-0 right-0 h-0.5 bg-charcoal/10" />
          <div className="absolute top-4 left-0 h-0.5 bg-gold transition-all duration-500" style={{ width: `${(currentStatusIdx / (ORDER_STATUSES.length - 2)) * 100}%` }} />

          {ORDER_STATUSES.filter((s) => !['cancelled', 'refunded'].includes(s.value)).map((s, i) => {
            const active = i <= currentStatusIdx || s.value === status;
            const current = s.value === status;
            return (
              <div key={s.value} className="relative flex flex-col items-center z-10">
                <motion.div
                  animate={{ scale: current ? 1.15 : 1 }}
                  className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${
                    active ? 'bg-gold text-ivory' : 'bg-charcoal/5 text-charcoal/25'
                  }`}
                >
                  <CheckIcon />
                </motion.div>
                <Text variant="caption" as="span" className={`mt-1.5 text-center ${active ? 'text-charcoal/70' : 'text-charcoal/25'}`}>{s.label}</Text>
              </div>
            );
          })}
        </div>

        {/* Status actions */}
        <div className="flex flex-wrap items-center gap-2 mt-xl pt-lg border-t border-charcoal/5">
          <Text variant="caption" as="span" className="text-charcoal/40 mr-2">Update:</Text>
          {ORDER_STATUSES.map((s) => (
            <motion.button
              key={s.value}
              whileTap={{ scale: 0.95 }}
              onClick={() => handleStatus(s.value)}
              disabled={s.value === status || saving}
              className={`px-3 py-1.5 text-xs rounded-full border transition-colors ${
                s.value === status
                  ? 'border-gold bg-gold/10 text-gold cursor-default'
                  : 'border-charcoal/10 text-charcoal/50 hover:border-charcoal/30 disabled:opacity-30'
              }`}
            >
              {s.label}
            </motion.button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-[1fr_380px] gap-2xl">
        {/* ── Left Column ───────────────────────────────────── */}
        <div className="space-y-2xl">
          {/* ── Line Items ───────────────────────────────────── */}
          <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
            <div className="flex items-center gap-2 mb-lg">
              <span className="text-charcoal/40"><PackageIcon /></span>
              <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Items ({order.line_items?.length ?? 0})</Text>
            </div>

            <div className="divide-y divide-charcoal/5">
              {order.line_items?.map((item) => (
                <div key={item.id} className="flex items-center gap-4 py-4 first:pt-0 last:pb-0">
                  <div className="w-12 h-16 rounded bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center">
                    <div className="w-5 h-8 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-charcoal">{item.product_name}</p>
                    <Text variant="caption" as="div">{item.variant} &middot; SKU: {item.sku}</Text>
                  </div>
                  <div className="text-right">
                    <Text variant="body-sm" className="text-charcoal tabular-nums">{formatINR(item.price)}</Text>
                    <Text variant="caption" as="div" className="text-charcoal/40">× {item.qty}</Text>
                  </div>
                  <span className="text-sm font-medium text-charcoal tabular-nums min-w-[80px] text-right">{formatINR(item.price * item.qty)}</span>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="mt-lg pt-lg border-t border-charcoal/5 space-y-1.5">
              <div className="flex justify-between text-sm"><span className="text-charcoal/50">Subtotal</span><span className="tabular-nums">{formatINR(order.subtotal)}</span></div>
              <div className="flex justify-between text-sm"><span className="text-charcoal/50">Tax (18%)</span><span className="tabular-nums">{formatINR(order.tax)}</span></div>
              <div className="flex justify-between text-sm"><span className="text-charcoal/50">Shipping</span><span className="tabular-nums">{order.shipping_cost === 0 ? <span className="text-gold">Complimentary</span> : formatINR(order.shipping_cost)}</span></div>
              {order.discount > 0 && (
                <div className="flex justify-between text-sm"><span className="text-gold">Discount</span><span className="tabular-nums text-gold">−{formatINR(order.discount)}</span></div>
              )}
              <div className="flex justify-between font-semibold text-charcoal pt-2 border-t border-charcoal/10">
                <span>Total</span><span className="tabular-nums text-base">{formatINR(order.total)}</span>
              </div>
            </div>
          </section>

          {/* ── Shipment ─────────────────────────────────────── */}
          {order.shipment && (
            <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
              <div className="flex items-center gap-2 mb-lg">
                <span className="text-charcoal/40"><TruckIcon /></span>
                <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Shipment</Text>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-lg">
                <div><Text variant="caption" as="div" className="mb-0.5">Carrier</Text><Text variant="body-sm" weight="medium">{order.shipment.carrier}</Text></div>
                <div><Text variant="caption" as="div" className="mb-0.5">Method</Text><Text variant="body-sm" weight="medium">{SHIPPING_METHODS.find((m) => m.value === order.shipment?.method)?.label ?? order.shipment?.method}</Text></div>
                <div><Text variant="caption" as="div" className="mb-0.5">Tracking</Text><Text variant="body-sm" weight="medium" className="text-gold font-mono text-xs">{order.shipment.tracking_number}</Text></div>
                <div><Text variant="caption" as="div" className="mb-0.5">Est. Delivery</Text><Text variant="body-sm" weight="medium">{formatDate(order.shipment.estimated_delivery)}</Text></div>
                {order.shipment.shipped_at && <div><Text variant="caption" as="div" className="mb-0.5">Shipped</Text><Text variant="body-sm" weight="medium">{formatDateTime(order.shipment.shipped_at)}</Text></div>}
                {order.shipment.delivered_at && <div><Text variant="caption" as="div" className="mb-0.5">Delivered</Text><Text variant="body-sm" weight="medium">{formatDateTime(order.shipment.delivered_at)}</Text></div>}
              </div>
            </section>
          )}

          {/* ── Activity ─────────────────────────────────────── */}
          <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
            <div className="flex items-center gap-2 mb-lg">
              <span className="text-charcoal/40"><ClockIcon /></span>
              <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Activity Log</Text>
            </div>

            {order.activity?.length ? (
              <div className="space-y-4">
                {[...order.activity].reverse().map((a) => (
                  <div key={a.id} className="flex gap-3">
                    <div className="w-6 h-6 rounded-full bg-charcoal/5 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <ClockIcon />
                    </div>
                    <div>
                      <p className="text-sm text-charcoal">{a.action}</p>
                      {a.note && <p className="text-xs text-charcoal/50 mt-0.5">{a.note}</p>}
                      <Text variant="caption" as="span" className="mt-0.5 block">{formatDateTime(a.timestamp)}</Text>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Text variant="body-sm" className="text-charcoal/30 italic">No activity recorded.</Text>
            )}

            {/* Add note */}
            <div className="mt-lg pt-lg border-t border-charcoal/5">
              <textarea
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                rows={2}
                placeholder="Add an internal note..."
                className="w-full px-4 py-2.5 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors resize-y"
              />
              <div className="flex justify-end mt-2">
                <Button variant="outline" size="sm" onClick={handleNote} loading={saving} disabled={!noteText.trim()}>Add Note</Button>
              </div>
            </div>
          </section>
        </div>

        {/* ── Right Column ──────────────────────────────────── */}
        <div className="space-y-2xl">
          {/* ── Customer ─────────────────────────────────────── */}
          <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
            <div className="flex items-center gap-2 mb-lg">
              <span className="text-charcoal/40"><UserIcon /></span>
              <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Customer</Text>
            </div>
            <div className="flex items-center gap-3 mb-lg">
              <div className="w-11 h-11 rounded-full bg-charcoal/5 flex items-center justify-center flex-shrink-0">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-charcoal/30"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
              </div>
              <div>
                <p className="text-sm font-semibold text-charcoal">{order.customer_name}</p>
                <Text variant="body-sm" className="text-charcoal/50">{order.customer_email}</Text>
              </div>
            </div>
          </section>

          {/* ── Shipping Address ─────────────────────────────── */}
          <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
            <div className="flex items-center gap-2 mb-lg">
              <span className="text-charcoal/40"><MapPinIcon /></span>
              <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Shipping Address</Text>
            </div>
            <div className="space-y-0.5">
              <Text variant="body-sm" weight="medium">{order.shipping_address.full_name}</Text>
              <Text variant="body-sm" className="text-charcoal/60">{order.shipping_address.line1}</Text>
              {order.shipping_address.line2 && <Text variant="body-sm" className="text-charcoal/60">{order.shipping_address.line2}</Text>}
              <Text variant="body-sm" className="text-charcoal/60">
                {order.shipping_address.city}, {order.shipping_address.state} {order.shipping_address.postal_code}
              </Text>
              <Text variant="body-sm" className="text-charcoal/60">{order.shipping_address.country}</Text>
              <Text variant="body-sm" className="text-charcoal/50 mt-1">{order.shipping_address.phone}</Text>
            </div>
          </section>

          {/* ── Invoice ──────────────────────────────────────── */}
          <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
            <div className="flex items-center gap-2 mb-lg">
              <span className="text-charcoal/40"><ReceiptIcon /></span>
              <Text variant="caption" as="div" className="font-semibold text-charcoal/80">Invoice</Text>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between"><Text variant="body-sm" className="text-charcoal/50">Number</Text><Text variant="body-sm" className="tabular-nums">{order.invoice.number}</Text></div>
              <div className="flex justify-between"><Text variant="body-sm" className="text-charcoal/50">Issued</Text><Text variant="body-sm">{order.invoice.issued_at ? formatDate(order.invoice.issued_at) : '—'}</Text></div>
              <div className="flex justify-between"><Text variant="body-sm" className="text-charcoal/50">Status</Text><span className={`px-2 py-0.5 rounded-full text-[11px] font-medium ${PAYMENT_STATUSES.find((s) => s.value === order.payment_status)?.color ?? ''}`}>{order.payment_status}</span></div>
              {order.invoice.paid_at && <div className="flex justify-between"><Text variant="body-sm" className="text-charcoal/50">Paid</Text><Text variant="body-sm">{formatDate(order.invoice.paid_at)}</Text></div>}
            </div>
          </section>

          {/* ── Payment Summary ──────────────────────────────── */}
          <section className="p-xl rounded-lg border border-charcoal/10 bg-ivory">
            <Text variant="caption" as="div" className="font-semibold text-charcoal/80 mb-lg">Payment Summary</Text>
            <div className="space-y-1.5">
              <div className="flex justify-between text-sm"><span className="text-charcoal/50">Subtotal</span><span className="tabular-nums">{formatINR(order.subtotal)}</span></div>
              <div className="flex justify-between text-sm"><span className="text-charcoal/50">Tax</span><span className="tabular-nums">{formatINR(order.tax)}</span></div>
              <div className="flex justify-between text-sm"><span className="text-charcoal/50">Shipping</span><span className="tabular-nums">{order.shipping_cost === 0 ? '—' : formatINR(order.shipping_cost)}</span></div>
              {order.discount > 0 && <div className="flex justify-between text-sm"><span className="text-gold">Discount</span><span className="tabular-nums text-gold">−{formatINR(order.discount)}</span></div>}
              <div className="flex justify-between font-semibold pt-2 border-t border-charcoal/10 mt-2"><span>Total</span><span className="tabular-nums">{formatINR(order.total)}</span></div>
            </div>
          </section>
        </div>
      </div>
    </motion.div>
  );
}
