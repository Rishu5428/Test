import { Link } from 'react-router-dom';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';

/* ── RegisterPage ─────────────────────────────────────────────
   Stub — redirects to a "contact admin" flow since this is an
   invite-only platform.
*/

export default function RegisterPage() {
  return (
    <div className="text-center">
      <div className="w-16 h-16 rounded-full bg-charcoal/5 flex items-center justify-center mx-auto mb-lg">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-charcoal/25">
          <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
          <circle cx="9" cy="7" r="4" />
          <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
        </svg>
      </div>
      <Heading as="h3" className="mb-sm">Request Access</Heading>
      <Text variant="body-sm" className="text-charcoal/50 mb-xl max-w-xs mx-auto">
        Édition Dashboard access is by invitation only. Please contact your administrator to create an account.
      </Text>
      <div className="space-y-3">
        <ButtonLink to="/" variant="outline" size="md" className="w-full">
          Return Home
        </ButtonLink>
        <Link to="/auth/login" className="block text-sm text-gold hover:underline">
          Back to Sign In
        </Link>
      </div>
    </div>
  );
}
