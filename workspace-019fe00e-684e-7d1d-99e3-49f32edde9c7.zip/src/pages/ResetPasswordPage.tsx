import { useState, useCallback, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { resetPassword } from '@/services/auth';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';

/* ── ResetPasswordPage ──────────────────────────────────────── */

export default function ResetPasswordPage() {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = useCallback(async (e: FormEvent) => {
    e.preventDefault();
    setError('');
    setSubmitting(true);

    const result = await resetPassword(email);
    setSubmitting(false);

    if (result.error) {
      setError(result.error.message);
    } else {
      setSent(true);
    }
  }, [email]);

  return (
    <div>
      <div className="text-center mb-xl">
        <Heading as="h3" className="mb-sm">Reset Password</Heading>
        <Text variant="body-sm" className="text-charcoal/50">
          Enter your email and we&rsquo;ll send you a reset link.
        </Text>
      </div>

      {sent ? (
        <motion.div
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          className="text-center"
        >
          <div className="w-16 h-16 rounded-full bg-gold/10 flex items-center justify-center mx-auto mb-lg">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-gold">
              <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
              <path d="M22 4L12 14.01l-3-3" />
            </svg>
          </div>
          <Text variant="body-md" className="text-charcoal/70 mb-lg">
            Check your inbox. If an account exists for <strong>{email}</strong>, you&rsquo;ll receive a reset link shortly.
          </Text>
          <Link to="/auth/login" className="text-sm text-gold hover:underline">
            Back to Sign In
          </Link>
        </motion.div>
      ) : (
        <form onSubmit={handleSubmit} className="space-y-lg">
          <div>
            <label htmlFor="reset-email" className="block text-xs font-medium text-charcoal/70 mb-1.5">
              Email
            </label>
            <input
              id="reset-email"
              type="email"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setError(''); }}
              required
              placeholder="you@example.com"
              className="w-full px-4 py-3 bg-transparent border border-charcoal/15 rounded-md text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors"
            />
          </div>

          {error && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 rounded-md bg-red-50 border border-red-100 text-xs text-red-600"
            >
              {error}
            </motion.div>
          )}

          <Button type="submit" variant="primary" size="lg" loading={submitting} className="w-full">
            Send Reset Link
          </Button>

          <Link to="/auth/login" className="block text-center text-sm text-charcoal/40 hover:text-gold transition-colors">
            Back to Sign In
          </Link>
        </form>
      )}
    </div>
  );
}
