import { useLocation, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import { Text } from '@/components/ui/Typography';

/* ── Icons ─────────────────────────────────────────────────── */
function BellIcon() { return (<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/></svg>); }
function ExternalLinkIcon() { return (<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6M15 3h6v6M10 14L21 3"/></svg>); }

/* ── Breadcrumb Generator ──────────────────────────────────── */
function getBreadcrumbs(pathname: string): { label: string; href?: string }[] {
  const crumbs: { label: string; href?: string }[] = [{ label: 'Dashboard', href: '/dashboard' }];
  if (pathname === '/dashboard') return crumbs;

  const parts = pathname.replace('/dashboard', '').split('/').filter(Boolean);
  let built = '/dashboard';
  for (const part of parts) {
    built += `/${part}`;
    crumbs.push({
      label: part.charAt(0).toUpperCase() + part.slice(1).replace(/-/g, ' '),
      href: built,
    });
  }
  return crumbs;
}

/* ── Topbar ─────────────────────────────────────────────────── */
export function Topbar() {
  const { profile } = useAuth();
  const location = useLocation();
  const breadcrumbs = getBreadcrumbs(location.pathname);

  return (
    <header className="h-16 bg-ivory border-b border-charcoal/5 flex items-center justify-between px-xl flex-shrink-0">
      {/* ── Breadcrumbs ───────────────────────────────────── */}
      <nav aria-label="Breadcrumb" className="flex items-center gap-2">
        {breadcrumbs.map((crumb, i) => (
          <div key={crumb.label} className="flex items-center gap-2">
            {i > 0 && (
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-charcoal/20 flex-shrink-0">
                <path d="M9 18l6-6-6-6" />
              </svg>
            )}
            {crumb.href && i < breadcrumbs.length - 1 ? (
              <Link
                to={crumb.href}
                className="text-xs text-charcoal/40 hover:text-gold transition-colors"
              >
                {crumb.label}
              </Link>
            ) : (
              <Text variant="caption" as="span" className="text-charcoal/70">
                {crumb.label}
              </Text>
            )}
          </div>
        ))}
      </nav>

      {/* ── Right Actions ──────────────────────────────────── */}
      <div className="flex items-center gap-3">
        {/* Notifications placeholder */}
        <motion.button
          type="button"
          whileTap={{ scale: 0.9 }}
          className="relative p-2 text-charcoal/40 hover:text-charcoal/70 transition-colors rounded-full"
          aria-label="Notifications"
        >
          <BellIcon />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-gold" />
        </motion.button>

        {/* View Store link */}
        <motion.a
          href="/"
          whileTap={{ scale: 0.96 }}
          className="hidden sm:flex items-center gap-1.5 text-xs text-charcoal/40 hover:text-gold transition-colors"
        >
          <ExternalLinkIcon />
          View Store
        </motion.a>

        {/* User pill */}
        <div className="flex items-center gap-2.5 pl-3 border-l border-charcoal/10">
          <div className="w-7 h-7 rounded-full bg-charcoal/5 flex items-center justify-center">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-charcoal/40">
              <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
            </svg>
          </div>
          <span className="hidden md:block text-xs font-medium text-charcoal/70">
            {profile?.full_name ?? 'User'}
          </span>
        </div>
      </div>
    </header>
  );
}
