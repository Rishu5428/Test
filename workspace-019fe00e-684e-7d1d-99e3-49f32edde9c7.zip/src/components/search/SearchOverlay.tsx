import { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useSearch } from '@/contexts/SearchContext';
import { Text } from '@/components/ui/Typography';
import { generateProducts } from '@/utils/products';
import { fadeIn } from '@/utils/animation';
import type { ProductData } from '@/components/ui/ProductCard';

/* ── Constants ──────────────────────────────────────────────── */
const RECENT_KEY = 'edition-recent-searches';
const MAX_RECENT = 5;

/* ── Icons ─────────────────────────────────────────────────── */
function SearchIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" />
    </svg>
  );
}
function CloseIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}
function ClockIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="12" cy="12" r="10" /><path d="M12 6v6l4 2" />
    </svg>
  );
}
function TrendingIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M23 6l-9.5 9.5-5-5L1 18" /><path d="M17 6h6v6" />
    </svg>
  );
}
function ArrowIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M5 12h14M12 5l7 7-7 7" />
    </svg>
  );
}
function CornerUpLeftIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M9 14L4 9l5-5" /><path d="M20 20v-7a4 4 0 0 0-4-4H4" />
    </svg>
  );
}

/* ── Helpers ───────────────────────────────────────────────── */
function getRecentSearches(): string[] {
  try {
    const raw = localStorage.getItem(RECENT_KEY);
    return raw ? (JSON.parse(raw) as string[]) : [];
  } catch {
    return [];
  }
}
function saveRecentSearch(term: string) {
  const recent = getRecentSearches().filter((t) => t !== term);
  recent.unshift(term);
  localStorage.setItem(RECENT_KEY, JSON.stringify(recent.slice(0, MAX_RECENT)));
}

/* ── Popular Products ──────────────────────────────────────── */
const popularProductsData = generateProducts(0, 2);

const popularSearches = [
  'Cashmere Overcoat',
  'Silk Evening Gown',
  'Leather Tote',
  'Linen Blazer',
  'Hand-Stitched Loafers',
];

const suggestions = [
  'Cashmere', 'Silk', 'Linen', 'Leather', 'Wool',
  'Outerwear', 'Evening', 'Tailoring', 'Knitwear', 'Footwear',
  'Blazer', 'Coat', 'Trousers', 'Scarf', 'Loafers',
];

/* ── SearchOverlay ──────────────────────────────────────────── */
export function SearchOverlay() {
  const { open, onClose } = useSearch();
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [query, setQuery] = useState('');
  const [selectedIdx, setSelectedIdx] = useState(-1);

  /* Reset on open */
  useEffect(() => {
    if (open) {
      setQuery('');
      setSelectedIdx(-1);
      /* Small delay for animation then focus */
      const t = setTimeout(() => inputRef.current?.focus(), 150);
      return () => clearTimeout(t);
    }
  }, [open]);

  const allProducts = useMemo(() => {
    /* Memoized once — we generate a pool to search against */
    try {
      return generateProducts(0, 64);
    } catch {
      return [] as ProductData[];
    }
  }, []);

  /* Filtered results */
  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [] as ProductData[];
    return allProducts.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q),
    ).slice(0, 6);
  }, [query, allProducts]);

  /* Filtered suggestions */
  const filteredSuggestions = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [] as string[];
    return suggestions
      .filter((s) => s.toLowerCase().includes(q))
      .slice(0, 5);
  }, [query]);

  const recentSearches = useMemo(() => getRecentSearches(), [open]);

  type SearchResultItem =
    | { type: 'product'; id: string; name: string; category: string; price: string }
    | { type: 'suggestion'; id: string; label: string };

  const allResults: SearchResultItem[] = [
    ...results.map((p) => ({ type: 'product' as const, id: p.id, name: p.name, category: p.category, price: p.price })),
    ...filteredSuggestions.map((s) => ({ type: 'suggestion' as const, id: s, label: s })),
  ];

  const hasResults = allResults.length > 0;
  const showEmpty = query.trim().length > 0 && !hasResults;

  /* Navigation */
  const handleSelect = useCallback(
    (item: SearchResultItem) => {
      const term = item.type === 'product' ? item.name : item.label;
      saveRecentSearch(term);
      if (item.type === 'product') {
        navigate(`/products/${item.id}`);
      } else {
        navigate(`/collections?q=${encodeURIComponent(item.label)}`);
      }
      onClose();
    },
    [navigate, onClose],
  );

  const handleSearchSubmit = useCallback(
    (term: string) => {
      const t = term.trim();
      if (!t) return;
      saveRecentSearch(t);
      navigate(`/collections?q=${encodeURIComponent(t)}`);
      onClose();
    },
    [navigate, onClose],
  );

  /* Keyboard nav */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (!open) return;
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIdx((v) => Math.min(v + 1, allResults.length - 1));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIdx((v) => Math.max(v - 1, -1));
      } else if (e.key === 'Enter' && selectedIdx >= 0 && selectedIdx < allResults.length) {
        e.preventDefault();
        handleSelect(allResults[selectedIdx]);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [open, allResults, selectedIdx, handleSelect]);

  const handlePopularClick = useCallback(
    (term: string) => handleSearchSubmit(term),
    [handleSearchSubmit],
  );

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            variants={fadeIn}
            initial="hidden"
            animate="visible"
            exit="hidden"
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[70] bg-charcoal/40 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Panel */}
          <motion.div
            initial={{ opacity: 0, y: -16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -16, scale: 0.98 }}
            transition={{ duration: 0.3, ease: [0.19, 1, 0.22, 1] }}
            className="fixed inset-x-0 top-0 z-[71] bg-ivory shadow-elevated"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="max-w-2xl mx-auto px-md py-lg">
              {/* Search input row */}
              <div className="flex items-center gap-4">
                <span className="text-charcoal/40"><SearchIcon /></span>
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => {
                    setQuery(e.target.value);
                    setSelectedIdx(-1);
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && selectedIdx === -1 && query.trim()) {
                      e.preventDefault();
                      handleSearchSubmit(query);
                    }
                  }}
                  placeholder="Search the collection..."
                  className="flex-1 bg-transparent text-lg font-heading text-charcoal placeholder:text-charcoal/25 outline-none py-2"
                />
                {/* Close + shortcut hint */}
                <div className="flex items-center gap-3">
                  <kbd className="hidden sm:inline-flex items-center gap-0.5 px-2 py-1 rounded-md bg-charcoal/5 text-[10px] text-charcoal/30 font-sans">
                    <span>esc</span>
                  </kbd>
                  <motion.button
                    type="button"
                    onClick={onClose}
                    whileTap={{ scale: 0.9 }}
                    className="p-1.5 text-charcoal/40 hover:text-charcoal transition-colors rounded-full"
                    aria-label="Close search"
                  >
                    <CloseIcon />
                  </motion.button>
                </div>
              </div>
            </div>

            {/* ── Results Area ──────────────────────────────── */}
            <div className="border-t border-charcoal/5">
              <div className="max-w-2xl mx-auto px-md py-lg max-h-[60vh] overflow-y-auto">
                {/* Product results */}
                {results.length > 0 && (
                  <div className="mb-xl">
                    <Text variant="caption" as="div" className="mb-md">
                      Products
                    </Text>
                    <div className="space-y-1">
                      {results.map((product, i) => {
                        const isSelected = selectedIdx === i;
                        return (
                          <motion.button
                            key={product.id}
                            type="button"
                            onClick={() => {
                              saveRecentSearch(product.name);
                              navigate(`/products/${product.id}`);
                              onClose();
                            }}
                            onMouseEnter={() => setSelectedIdx(i)}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: i * 0.03, duration: 0.25 }}
                            className={`flex items-center gap-4 w-full text-left p-3 rounded-md transition-colors ${
                              isSelected
                                ? 'bg-charcoal/5'
                                : 'hover:bg-charcoal/3'
                            }`}
                          >
                            {/* Thumbnail */}
                            <div className="w-10 h-10 rounded-md bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center">
                              <div className="w-4 h-5 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-sm font-medium text-charcoal truncate">
                                {product.name}
                              </p>
                              <Text variant="caption" as="span">
                                {product.category}
                              </Text>
                            </div>
                            <Text variant="body-sm" className="text-charcoal/40 flex-shrink-0">
                              {product.price}
                            </Text>
                          </motion.button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Suggestions */}
                {filteredSuggestions.length > 0 && (
                  <div className="mb-xl">
                    <Text variant="caption" as="div" className="mb-md">
                      Suggestions
                    </Text>
                    <div className="flex flex-wrap gap-2">
                      {filteredSuggestions.map((s, i) => {
                        const si = results.length + i;
                        return (
                          <motion.button
                            key={s}
                            type="button"
                            onClick={() => handleSearchSubmit(s)}
                            onMouseEnter={() => setSelectedIdx(si)}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ delay: si * 0.03, duration: 0.25 }}
                            className={`flex items-center gap-2 px-3 py-1.5 text-sm rounded-full border transition-colors ${
                              selectedIdx === si
                                ? 'border-gold text-gold bg-gold/5'
                                : 'border-charcoal/10 text-charcoal/60 hover:border-charcoal/30'
                            }`}
                          >
                            <ArrowIcon />
                            {s}
                          </motion.button>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Empty state */}
                {showEmpty && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-center py-2xl"
                  >
                    <Text variant="body-lg" className="text-charcoal/30 mb-sm">
                      No results for &ldquo;{query}&rdquo;
                    </Text>
                    <Text variant="body-sm" className="text-charcoal/30">
                      Try a different search term or browse our collections.
                    </Text>
                  </motion.div>
                )}

                {/* Empty query — show popular & recent */}
                {!query.trim() && (
                  <>
                    {/* Popular products */}
                    <div className="mb-xl">
                      <div className="flex items-center gap-2 mb-md">
                        <span className="text-gold"><TrendingIcon /></span>
                        <Text variant="caption" as="div">
                          Popular Products
                        </Text>
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        {popularProductsData.map((product) => (
                          <motion.button
                            key={product.id}
                            type="button"
                            onClick={() => {
                              saveRecentSearch(product.name);
                              navigate(`/products/${product.id}`);
                              onClose();
                            }}
                            initial={{ opacity: 0, y: 8 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.3 }}
                            className="flex items-center gap-3 p-3 rounded-md border border-charcoal/5 hover:border-charcoal/15 transition-colors text-left"
                          >
                            <div className="w-10 h-10 rounded-md bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center">
                              <div className="w-4 h-5 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-charcoal truncate">{product.name}</p>
                              <Text variant="caption" as="span">{product.price}</Text>
                            </div>
                          </motion.button>
                        ))}
                      </div>
                    </div>

                    {/* Popular searches */}
                    <div className="mb-xl">
                      <div className="flex items-center gap-2 mb-md">
                        <span className="text-gold"><TrendingIcon /></span>
                        <Text variant="caption" as="div">
                          Popular Searches
                        </Text>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {popularSearches.map((term) => (
                          <motion.button
                            key={term}
                            type="button"
                            onClick={() => handlePopularClick(term)}
                            whileTap={{ scale: 0.96 }}
                            className="px-3 py-1.5 text-sm text-charcoal/60 border border-charcoal/10 rounded-full hover:border-charcoal/30 hover:text-charcoal transition-colors"
                          >
                            {term}
                          </motion.button>
                        ))}
                      </div>
                    </div>

                    {/* Recent searches */}
                    {recentSearches.length > 0 && (
                      <div>
                        <div className="flex items-center gap-2 mb-md">
                          <span className="text-charcoal/40"><ClockIcon /></span>
                          <Text variant="caption" as="div">
                            Recent Searches
                          </Text>
                        </div>
                        <div className="space-y-0.5">
                          {recentSearches.map((term) => (
                            <motion.button
                              key={term}
                              type="button"
                              onClick={() => handlePopularClick(term)}
                              initial={{ opacity: 0, y: 6 }}
                              animate={{ opacity: 1, y: 0 }}
                              whileTap={{ scale: 0.98 }}
                              className="flex items-center gap-3 w-full text-left p-2.5 rounded-md hover:bg-charcoal/3 transition-colors"
                            >
                              <span className="text-charcoal/30"><CornerUpLeftIcon /></span>
                              <span className="text-sm text-charcoal/60">{term}</span>
                            </motion.button>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Keyboard shortcut footer */}
                    <div className="mt-xl pt-lg border-t border-charcoal/5 flex flex-wrap items-center gap-5 text-[11px] text-charcoal/25">
                      <span className="flex items-center gap-1.5">
                        <kbd className="px-1.5 py-0.5 rounded bg-charcoal/5 font-sans">↑↓</kbd> navigate
                      </span>
                      <span className="flex items-center gap-1.5">
                        <kbd className="px-1.5 py-0.5 rounded bg-charcoal/5 font-sans">↵</kbd> select
                      </span>
                      <span className="flex items-center gap-1.5">
                        <kbd className="px-1.5 py-0.5 rounded bg-charcoal/5 font-sans">esc</kbd> close
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
