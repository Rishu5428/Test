import { forwardRef } from 'react';
import type { HeadingLevel, BodyVariant } from '@/types';

/* ── Heading ────────────────────────────────────────────────── */
interface HeadingProps {
  as?: HeadingLevel;
  children: React.ReactNode;
  className?: string;
  id?: string;
}

const headingStyles: Record<HeadingLevel, string> = {
  h1: 'text-5xl lg:text-7xl font-bold tracking-tight',
  h2: 'text-4xl lg:text-5xl font-semibold tracking-tight',
  h3: 'text-3xl lg:text-4xl font-semibold',
  h4: 'text-2xl lg:text-3xl font-medium',
  h5: 'text-xl lg:text-2xl font-medium',
  h6: 'text-lg lg:text-xl font-medium',
};

export const Heading = forwardRef<HTMLHeadingElement, HeadingProps>(
  ({ as: Tag = 'h2', children, className = '', ...rest }, ref) => {
    const base = headingStyles[Tag];
    return (
      <Tag ref={ref} className={`${base} ${className}`} {...rest}>
        {children}
      </Tag>
    );
  },
);
Heading.displayName = 'Heading';

/* ── Text ──────────────────────────────────────────────────── */
interface TextProps {
  variant?: BodyVariant;
  as?: 'p' | 'span' | 'div' | 'figcaption' | 'label';
  children: React.ReactNode;
  className?: string;
  weight?: 'light' | 'normal' | 'medium' | 'semibold';
}

const variantStyles: Record<BodyVariant, string> = {
  'body-lg': 'text-lg leading-relaxed',
  'body-md': 'text-base leading-relaxed',
  'body-sm': 'text-sm leading-relaxed',
  caption: 'text-xs tracking-wide uppercase text-charcoal/60',
  overline: 'text-xs tracking-[0.2em] uppercase font-medium text-gold',
};

const weightStyles = {
  light: 'font-light',
  normal: 'font-normal',
  medium: 'font-medium',
  semibold: 'font-semibold',
};

export const Text = forwardRef<
  HTMLParagraphElement | HTMLSpanElement,
  TextProps
>(
  (
    { variant = 'body-md', as: Tag = 'p', children, className = '', weight },
    ref,
  ) => {
    const base = variantStyles[variant];
    const wt = weight ? weightStyles[weight] : '';
    return (
      <Tag ref={ref as never} className={`${base} ${wt} ${className}`}>
        {children}
      </Tag>
    );
  },
);
Text.displayName = 'Text';
