import { forwardRef } from 'react';
import { motion, type HTMLMotionProps } from 'framer-motion';
import { Link, type LinkProps } from 'react-router-dom';
import type { ButtonVariant, ButtonSize } from '@/types';
import { transition } from '@/utils/animation';

/* ── Style Maps ────────────────────────────────────────────── */
const variantStyles: Record<ButtonVariant, string> = {
  primary:
    'bg-charcoal text-ivory border border-charcoal hover:bg-charcoal/90 shadow-subtle hover:shadow-elevated',
  secondary:
    'bg-gold text-charcoal border border-gold hover:bg-gold/90 shadow-subtle hover:shadow-elevated',
  outline:
    'bg-transparent text-charcoal border border-charcoal/20 hover:border-charcoal hover:bg-charcoal/5',
  ghost:
    'bg-transparent text-charcoal border border-transparent hover:bg-charcoal/5',
};

const sizeStyles: Record<ButtonSize, string> = {
  sm: 'px-4 py-2 text-sm gap-2',
  md: 'px-6 py-3 text-sm gap-2',
  lg: 'px-8 py-4 text-base gap-3',
};

/* ── Shared base ───────────────────────────────────────────── */
const baseStyle =
  'inline-flex items-center justify-center font-medium rounded-md cursor-pointer select-none disabled:opacity-40 disabled:cursor-not-allowed focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/50 transition-colors';

/* ── Motion Props ──────────────────────────────────────────── */
const motionProps = {
  whileTap: { scale: 0.975 },
  whileHover: { scale: 1.01, y: -1 },
  transition: transition.spring,
};

/* ── Button Component ──────────────────────────────────────── */
interface ButtonProps
  extends Omit<HTMLMotionProps<'button'>, 'children'> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  loading?: boolean;
  children: React.ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    {
      variant = 'primary',
      size = 'md',
      loading = false,
      disabled,
      children,
      className = '',
      ...rest
    },
    ref,
  ) => {
    const cls = `${baseStyle} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`;

    return (
      <motion.button
        ref={ref}
        className={cls}
        disabled={disabled || loading}
        aria-busy={loading || undefined}
        {...motionProps}
        {...rest}
      >
        {loading && <Spinner />}
        {children}
      </motion.button>
    );
  },
);
Button.displayName = 'Button';

/* ── ButtonLink Component ──────────────────────────────────── */
interface ButtonLinkProps extends Omit<LinkProps, 'children'> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  children: React.ReactNode;
  className?: string;
}

export const ButtonLink = forwardRef<HTMLAnchorElement, ButtonLinkProps>(
  (
    { variant = 'primary', size = 'md', children, className = '', ...rest },
    ref,
  ) => {
    const cls = `${baseStyle} ${variantStyles[variant]} ${sizeStyles[size]} ${className}`;

    return (
      <motion.div {...motionProps} className="inline-flex">
        <Link ref={ref} className={cls} {...rest}>
          {children}
        </Link>
      </motion.div>
    );
  },
);
ButtonLink.displayName = 'ButtonLink';

/* ── Spinner ───────────────────────────────────────────────── */
function Spinner() {
  return (
    <svg
      className="animate-spin h-4 w-4"
      viewBox="0 0 16 16"
      fill="none"
      aria-hidden
    >
      <circle
        cx="8"
        cy="8"
        r="6"
        stroke="currentColor"
        strokeWidth="2"
        strokeDasharray="28"
        strokeDashoffset="12"
        strokeLinecap="round"
      />
    </svg>
  );
}
