import { useState, useCallback, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Text } from '@/components/ui/Typography';
import { useTilt } from '@/hooks/useTilt';
import { transition } from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
export interface ProductData {
  id: string;
  name: string;
  category: string;
  price: string;
  href: string;
  rating?: number; // 0-5 (halves allowed)
}

/* ── SVG Icons ──────────────────────────────────────────────── */
function HeartIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

function EyeIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" /><circle cx="12" cy="12" r="3" />
    </svg>
  );
}

function CartIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
    </svg>
  );
}

/* ── Star Rating ────────────────────────────────────────────── */
let starCounter = 0;
function Star({ pct }: { pct: number }) {
  const id = useMemo(() => { starCounter++; return `s${starCounter}`; }, []);
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.2" aria-hidden>
      <defs>
        <linearGradient id={id}><stop offset={`${pct * 100}%`} stopColor="currentColor" /><stop offset={`${pct * 100}%`} stopColor="transparent" stopOpacity="0" /></linearGradient>
      </defs>
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" fill={`url(#${id})`} />
    </svg>
  );
}

function Rating({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5 text-gold" aria-label={`${value} out of 5 stars`}>
      {[1, 2, 3, 4, 5].map((i) => {
        const pct = Math.min(1, Math.max(0, value - (i - 1)));
        return <Star key={i} pct={pct} />;
      })}
    </div>
  );
}

/* ── ProductCard Props ─────────────────────────────────────── */
interface ProductCardProps {
  product: ProductData;
  aspectRatio?: string;
  className?: string;

  /* Feature toggles */
  showWishlist?: boolean;
  showQuickView?: boolean;
  showAddToCart?: boolean;
  showRating?: boolean;
  enableTilt?: boolean;

  /* Callbacks */
  onWishlist?: (product: ProductData) => void;
  onAddToCart?: (product: ProductData) => void;
  onQuickView?: (product: ProductData) => void;
}

/* ── ProductCard Component ─────────────────────────────────── */
export function ProductCard({
  product,
  aspectRatio = 'aspect-[3/4]',
  className = '',
  showWishlist = true,
  showQuickView = true,
  showAddToCart = true,
  showRating = true,
  enableTilt = true,
  onWishlist,
  onAddToCart,
  onQuickView,
}: ProductCardProps) {
  const tilt = useTilt(6);
  const [wishlisted, setWishlisted] = useState(false);
  const [hovered, setHovered] = useState(false);
  const rating = product.rating ?? 4.5;

  const handleWishlist = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setWishlisted((v) => !v);
      onWishlist?.(product);
    },
    [product, onWishlist],
  );

  const handleQuickView = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      onQuickView?.(product);
    },
    [product, onQuickView],
  );

  const handleAddToCart = useCallback(
    (e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      onAddToCart?.(product);
    },
    [product, onAddToCart],
  );

  const hoverProps = enableTilt
    ? { ref: tilt.ref, onMouseMove: tilt.onMouseMove }
    : {};

  const handleMouseLeave = useCallback(() => {
    setHovered(false);
    if (enableTilt) tilt.onMouseLeave();
  }, [enableTilt, tilt]);

  return (
    <motion.div
      {...hoverProps}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      className={`group relative ${className}`}
      whileHover={enableTilt ? undefined : { y: -4 }}
      transition={transition.normal}
    >
      <Link to={product.href} className="block">
        {/* ── Image Container ──────────────────────────────── */}
        <div
          className={`${aspectRatio} rounded-lg bg-gradient-to-br from-charcoal/5 via-ivory to-gold/15 overflow-hidden relative shadow-subtle`}
        >
          {/* Hover glow layer */}
          <motion.div
            className="absolute inset-0 bg-gradient-to-br from-gold/10 via-transparent to-charcoal/5 pointer-events-none"
            initial={false}
            animate={{ opacity: hovered ? 1 : 0 }}
            transition={{ duration: 0.4 }}
          />

          {/* Product silhouette */}
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="w-1/2 h-3/5 bg-gradient-to-b from-charcoal/8 via-charcoal/5 to-charcoal/10 rounded-b-lg rounded-t-full transition-transform duration-500 group-hover:scale-105" />
          </div>

          {/* Accent bar */}
          <div className="absolute bottom-8 left-1/2 -translate-x-1/2 w-10 h-px bg-gold/30 group-hover:w-14 transition-all duration-500" />

          {/* ── Wishlist ────────────────────────────────────── */}
          {showWishlist && (
            <motion.button
              type="button"
              aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
              onClick={handleWishlist}
              className={`absolute top-3 right-3 p-2 rounded-full transition-colors ${
                wishlisted ? 'text-gold bg-gold/10' : 'text-charcoal/50 bg-ivory/80 backdrop-blur-sm hover:text-gold'
              }`}
              initial={false}
              animate={{ opacity: hovered || wishlisted ? 1 : 0, scale: hovered || wishlisted ? 1 : 0.8 }}
              transition={transition.fast}
              whileTap={{ scale: 0.85 }}
            >
              <HeartIcon filled={wishlisted} />
            </motion.button>
          )}

          {/* ── Hover Actions ───────────────────────────────── */}
          {(showQuickView || showAddToCart) && (
            <motion.div
              className="absolute inset-x-0 bottom-0 p-3 sm:p-4 flex flex-col gap-2"
              initial={false}
              animate={{ opacity: hovered ? 1 : 0, y: hovered ? 0 : 8 }}
              transition={{ duration: 0.3, ease: [0.19, 1, 0.22, 1] }}
            >
              {showQuickView && (
                <motion.button
                  type="button"
                  onClick={handleQuickView}
                  className="flex items-center justify-center gap-2 w-full py-2.5 px-3 text-[11px] sm:text-xs font-medium tracking-wide uppercase text-charcoal bg-ivory/90 backdrop-blur-sm rounded-md hover:bg-ivory hover:text-gold transition-colors border border-charcoal/10"
                  whileTap={{ scale: 0.97 }}
                >
                  <EyeIcon /> Quick View
                </motion.button>
              )}
              {showAddToCart && (
                <motion.button
                  type="button"
                  onClick={handleAddToCart}
                  className="flex items-center justify-center gap-2 w-full py-2.5 px-3 text-[11px] sm:text-xs font-medium tracking-wide uppercase text-ivory bg-charcoal rounded-md hover:bg-charcoal/90 transition-colors border border-charcoal"
                  whileTap={{ scale: 0.97 }}
                >
                  <CartIcon /> Add to Cart
                </motion.button>
              )}
            </motion.div>
          )}
        </div>

        {/* ── Product Info ──────────────────────────────────── */}
        <div className="mt-sm">
          <Text variant="caption" className="mb-1">{product.category}</Text>
          <p className="text-sm font-medium text-charcoal group-hover:text-gold transition-colors mb-0.5">
            {product.name}
          </p>

          <div className="flex items-center justify-between mt-1">
            {showRating && <Rating value={rating} />}
            <Text variant="body-sm" className="text-charcoal/60 tabular-nums">{product.price}</Text>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}
