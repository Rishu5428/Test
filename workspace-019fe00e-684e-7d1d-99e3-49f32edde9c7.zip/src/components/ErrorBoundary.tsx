import { Component, type ErrorInfo, type ReactNode } from 'react';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';

interface Props { children: ReactNode; }
interface State { hasError: boolean; error: Error | null; }

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack);
  }

  handleReset = () => this.setState({ hasError: false, error: null });

  render() {
    if (this.state.hasError) {
      return (
        <div className="min-h-screen bg-ivory flex items-center justify-center px-md">
          <div className="text-center max-w-md">
            <div className="w-20 h-20 rounded-full bg-charcoal/5 flex items-center justify-center mx-auto mb-lg">
              <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" className="text-charcoal/20">
                <circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>
              </svg>
            </div>
            <Heading as="h3" className="mb-sm">Something went wrong</Heading>
            <Text variant="body-sm" className="text-charcoal/50 mb-xl">
              An unexpected error occurred. Please try refreshing.
            </Text>
            <div className="flex items-center justify-center gap-3">
              <Button variant="outline" size="sm" onClick={this.handleReset}>Try Again</Button>
              <a href="/"><Button variant="primary" size="sm">Go Home</Button></a>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
