import { useState, useCallback, useMemo, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useCart } from '@/contexts/CartContext';
import { Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { generateProducts } from '@/utils/products';
import { fadeIn } from '@/utils/animation';
import type { ProductData } from '@/components/ui/ProductCard';

/* ── Icons ─────────────────────────────────────────────────── */
function CloseIcon() {
  return (
    <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}
function TrashIcon() {
  return (
    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}
function MinusIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M5 12h14" />
    </svg>
  );
}
function PlusIcon() {
  return (
    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}
function PackageIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M16.5 9.4L7.55 4.24M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
      <path d="M3.27 6.96L12 12.01l8.73-5.05M12 22.08V12" />
    </svg>
  );
}
function TagIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82zM7 7h.01" />
    </svg>
  );
}
function TruckIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <rect x="1" y="3" width="15" height="13" rx="1" />
      <path d="M16 8h4l3 4v4h-3" /><circle cx="6.5" cy="18.5" r="2.5" /><circle cx="17.5" cy="18.5" r="2.5" />
    </svg>
  );
}
function ShieldIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  );
}

/* ── Helpers ───────────────────────────────────────────────── */
function formatPrice(n: number): string {
  const formatter = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 0 });
  return `₹ ${formatter.format(n)}`;
}

function getDeliveryEstimate(): string {
  const d = new Date();
  d.setDate(d.getDate() + 4);
  const opts: Intl.DateTimeFormatOptions = { month: 'short', day: 'numeric' };
  /* Format: "Mon DD – Mon DD" (4 to 7 days) */
  const end = new Date(d);
  end.setDate(end.getDate() + 3);
  return `${d.toLocaleDateString('en-US', opts)} – ${end.toLocaleDateString('en-US', opts)}`;
}

const recommendations: ProductData[] = generateProducts(11, 3);

/* ── CartDrawer ─────────────────────────────────────────────── */
export function CartDrawer() {
  const { open, onClose, items, removeItem, updateQty, itemCount, subtotal } = useCart();
  const [couponCode, setCouponCode] = useState('');
  const [couponApplied, setCouponApplied] = useState(false);
  const [couponError, setCouponError] = useState('');

  const deliveryEstimate = useMemo(() => getDeliveryEstimate(), []);
  const tax = Math.round(subtotal * 0.18);
  const shipping = subtotal > 50000 ? 0 : 1500;
  const discount = couponApplied ? Math.round(subtotal * 0.1) : 0;
  const total = subtotal + tax + shipping - discount;

  const handleCoupon = useCallback(
    (e: FormEvent) => {
      e.preventDefault();
      const code = couponCode.trim().toUpperCase();
      if (code === 'EDITION10') {
        setCouponApplied(true);
        setCouponError('');
      } else {
        setCouponError('Invalid coupon code');
        setCouponApplied(false);
      }
    },
    [couponCode],
  );

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            variants={fadeIn}
            initial="hidden"
            animate="visible"
            exit="hidden"
            transition={{ duration: 0.25 }}
            className="fixed inset-0 z-[80] bg-charcoal/40 backdrop-blur-sm"
            onClick={onClose}
          />

          {/* Drawer */}
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.4, ease: [0.19, 1, 0.22, 1] }}
            className="fixed top-0 right-0 bottom-0 z-[81] w-full max-w-md bg-ivory shadow-2xl flex flex-col"
          >
            {/* ── Header ────────────────────────────────────── */}
            <div className="flex items-center justify-between px-md h-16 border-b border-charcoal/10 flex-shrink-0">
              <div className="flex items-center gap-3">
                <span className="font-heading text-lg font-semibold text-charcoal">
                  Your Cart
                </span>
                {itemCount > 0 && (
                  <span className="w-6 h-6 rounded-full bg-charcoal text-ivory text-[11px] font-medium flex items-center justify-center">
                    {itemCount}
                  </span>
                )}
              </div>
              <motion.button
                type="button"
                onClick={onClose}
                whileTap={{ scale: 0.9 }}
                className="p-1.5 text-charcoal/40 hover:text-charcoal transition-colors rounded-full"
                aria-label="Close cart"
              >
                <CloseIcon />
              </motion.button>
            </div>

            {/* ── Body ───────────────────────────────────────── */}
            <div className="flex-1 overflow-y-auto">
              {items.length === 0 ? (
                /* Empty state */
                <motion.div
                  variants={fadeIn}
                  initial="hidden"
                  animate="visible"
                  className="flex flex-col items-center justify-center py-4xl px-md text-center"
                >
                  <div className="w-20 h-20 rounded-full bg-charcoal/3 flex items-center justify-center mb-lg">
                    <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" strokeLinecap="round" className="text-charcoal/15">
                      <circle cx="9" cy="21" r="1" /><circle cx="20" cy="21" r="1" />
                      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
                    </svg>
                  </div>
                  <Text variant="body-lg" className="text-charcoal/40 mb-sm">
                    Your cart is empty
                  </Text>
                  <Text variant="body-sm" className="text-charcoal/30 mb-xl max-w-xs">
                    Pieces you add will appear here. Discover something extraordinary in our collection.
                  </Text>
                  <Link to="/collections" onClick={onClose}>
                    <Button variant="outline" size="md">
                      Browse Collections
                    </Button>
                  </Link>
                </motion.div>
              ) : (
                <div className="px-md py-lg">
                  {/* ── Items ────────────────────────────────── */}
                  <ul className="space-y-lg pb-lg border-b border-charcoal/5">
                    {items.map((item, i) => {
                      const p = parseInt(item.price.replace(/[₹,\s]/g, ''), 10);
                      return (
                        <motion.li
                          key={item.id + item.variant}
                          initial={{ opacity: 0, x: 20 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ delay: i * 0.05, duration: 0.3 }}
                          className="flex gap-4"
                        >
                          {/* Thumbnail */}
                          <div className="w-20 h-24 rounded-md bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center overflow-hidden">
                            <div className="w-8 h-12 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                          </div>

                          {/* Info */}
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-charcoal leading-snug">
                              {item.name}
                            </p>
                            <Text variant="caption" as="p" className="mt-0.5">
                              {item.variant}
                            </Text>

                            {/* Qty controls + price + remove */}
                            <div className="flex items-center justify-between mt-2">
                              <div className="flex items-center border border-charcoal/15 rounded-md">
                                <motion.button
                                  type="button"
                                  onClick={() => updateQty(item.id, item.qty - 1)}
                                  whileTap={{ scale: 0.9 }}
                                  className="p-1.5 text-charcoal/50 hover:text-charcoal transition-colors"
                                  aria-label="Reduce quantity"
                                >
                                  <MinusIcon />
                                </motion.button>
                                <span className="w-7 text-center text-xs font-medium tabular-nums">
                                  {item.qty}
                                </span>
                                <motion.button
                                  type="button"
                                  onClick={() => updateQty(item.id, item.qty + 1)}
                                  whileTap={{ scale: 0.9 }}
                                  className="p-1.5 text-charcoal/50 hover:text-charcoal transition-colors"
                                  aria-label="Increase quantity"
                                >
                                  <PlusIcon />
                                </motion.button>
                              </div>

                              <div className="flex items-center gap-3">
                                <span className="text-sm font-medium text-charcoal tabular-nums">
                                  {formatPrice(p * item.qty)}
                                </span>
                                <motion.button
                                  type="button"
                                  onClick={() => removeItem(item.id)}
                                  whileTap={{ scale: 0.85 }}
                                  className="text-charcoal/25 hover:text-charcoal/60 transition-colors"
                                  aria-label={`Remove ${item.name}`}
                                >
                                  <TrashIcon />
                                </motion.button>
                              </div>
                            </div>
                          </div>
                        </motion.li>
                      );
                    })}
                  </ul>

                  {/* ── Coupon ────────────────────────────────── */}
                  <div className="py-lg border-b border-charcoal/5">
                    <div className="flex items-center gap-2 mb-3">
                      <span className="text-gold"><TagIcon /></span>
                      <Text variant="caption" as="span" className="text-charcoal/80">
                        Promo Code
                      </Text>
                    </div>
                    <form onSubmit={handleCoupon} className="flex gap-2">
                      <input
                        type="text"
                        value={couponCode}
                        onChange={(e) => {
                          setCouponCode(e.target.value);
                          setCouponError('');
                        }}
                        placeholder="Enter code"
                        className="flex-1 bg-transparent border border-charcoal/15 rounded-md px-3 py-2 text-sm text-charcoal placeholder:text-charcoal/25 outline-none focus:border-gold transition-colors"
                      />
                      <Button type="submit" variant="outline" size="sm" className="whitespace-nowrap">
                        Apply
                      </Button>
                    </form>
                    {couponApplied && (
                      <motion.p
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs text-gold mt-2"
                      >
                        10% discount applied — EDITION10
                      </motion.p>
                    )}
                    {couponError && (
                      <motion.p
                        initial={{ opacity: 0, y: 4 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="text-xs text-red-400 mt-2"
                      >
                        {couponError}
                      </motion.p>
                    )}
                    <p className="text-[10px] text-charcoal/25 mt-2">
                      Try: EDITION10
                    </p>
                  </div>

                  {/* ── Order Summary ─────────────────────────── */}
                  <div className="py-lg border-b border-charcoal/5 space-y-2">
                    <div className="flex items-center justify-between">
                      <Text variant="body-sm" className="text-charcoal/60">Subtotal</Text>
                      <Text variant="body-sm" className="text-charcoal tabular-nums">{formatPrice(subtotal)}</Text>
                    </div>
                    <div className="flex items-center justify-between">
                      <Text variant="body-sm" className="text-charcoal/60">Tax (18%)</Text>
                      <Text variant="body-sm" className="text-charcoal tabular-nums">{formatPrice(tax)}</Text>
                    </div>
                    <div className="flex items-center justify-between">
                      <Text variant="body-sm" className="text-charcoal/60">Shipping</Text>
                      {shipping === 0 ? (
                        <Text variant="body-sm" className="text-gold">Complimentary</Text>
                      ) : (
                        <Text variant="body-sm" className="text-charcoal tabular-nums">{formatPrice(shipping)}</Text>
                      )}
                    </div>
                    {discount > 0 && (
                      <div className="flex items-center justify-between">
                        <Text variant="body-sm" className="text-gold">Discount (10%)</Text>
                        <Text variant="body-sm" className="text-gold tabular-nums">−{formatPrice(discount)}</Text>
                      </div>
                    )}
                  </div>

                  {/* ── Total ─────────────────────────────────── */}
                  <div className="flex items-center justify-between py-lg border-b border-charcoal/10">
                    <span className="font-heading text-lg font-semibold text-charcoal">Total</span>
                    <span className="font-heading text-lg font-semibold text-charcoal tabular-nums">
                      {formatPrice(total)}
                    </span>
                  </div>

                  {/* ── Delivery Estimate ─────────────────────── */}
                  <div className="py-lg border-b border-charcoal/5 space-y-3">
                    <div className="flex items-center gap-2">
                      <span className="text-charcoal/40"><TruckIcon /></span>
                      <Text variant="body-sm" className="text-charcoal/60">
                        Estimated delivery: <span className="text-charcoal/80 font-medium">{deliveryEstimate}</span>
                      </Text>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-charcoal/40"><PackageIcon /></span>
                      <Text variant="body-sm" className="text-charcoal/60">
                        Complimentary gift wrapping & signature box
                      </Text>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-charcoal/40"><ShieldIcon /></span>
                      <Text variant="body-sm" className="text-charcoal/60">
                        30-day returns & lifetime care
                      </Text>
                    </div>
                  </div>

                  {/* ── Recommendations ────────────────────────── */}
                  <div className="py-lg">
                    <Text variant="caption" as="div" className="mb-md">
                      You May Also Like
                    </Text>
                    <div className="space-y-3">
                      {recommendations.map((rec, i) => (
                        <motion.div
                          key={rec.id}
                          initial={{ opacity: 0, y: 8 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.3 + i * 0.06, duration: 0.3 }}
                        >
                          <Link
                            to={rec.href}
                            onClick={onClose}
                            className="flex items-center gap-3 p-2 rounded-md hover:bg-charcoal/3 transition-colors group"
                          >
                            <div className="w-12 h-14 rounded-md bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 flex-shrink-0 flex items-center justify-center overflow-hidden">
                              <div className="w-5 h-7 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/8 rounded-t-full rounded-b" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-xs font-medium text-charcoal group-hover:text-gold transition-colors truncate">
                                {rec.name}
                              </p>
                              <Text variant="caption" as="span">{rec.price}</Text>
                            </div>
                            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" className="text-charcoal/25 group-hover:text-gold transition-colors flex-shrink-0">
                              <path d="M5 12h14M12 5l7 7-7 7" />
                            </svg>
                          </Link>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>

                        {/* ── Footer CTA ─────────────────────────────────── */}
            {items.length > 0 && (
              <div className="px-md py-lg border-t border-charcoal/10 flex-shrink-0 space-y-3">
                <Link to="/checkout" onClick={onClose}>
                  <Button variant="primary" size="lg" className="w-full">
                    Checkout — {formatPrice(total)}
                  </Button>
                </Link>
                <button
                  type="button"
                  onClick={onClose}
                  className="block w-full text-center text-sm text-charcoal/50 hover:text-charcoal transition-colors"
                >
                  Continue Shopping
                </button>
              </div>
            )}
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
