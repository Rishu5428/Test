import { useState, useRef, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useScrollPosition } from '@/hooks/useScrollPosition';
import { useToggle } from '@/hooks/useToggle';
import { useTheme } from '@/hooks/useTheme';
import { useSearch } from '@/contexts/SearchContext';
import { useCart } from '@/contexts/CartContext';
import { useWishlist } from '@/contexts/WishlistContext';
import { fadeIn, transition } from '@/utils/animation';

/* ── Navigation Data ────────────────────────────────────────── */
interface MegaLink {
  label: string;
  href: string;
  description?: string;
}

interface NavItem {
  label: string;
  href?: string;
  megaColumns?: { title: string; links: MegaLink[] }[];
}

const navItems: NavItem[] = [
  { label: 'Home', href: '/' },
  {
    label: 'Collections',
    megaColumns: [
      {
        title: 'Featured',
        links: [
          { label: 'New Arrivals', href: '/collections', description: 'This season\'s finest' },
          { label: 'Bestsellers', href: '/collections', description: 'Timeless favorites' },
          { label: 'Limited Edition', href: '/collections', description: 'Exclusive pieces' },
          { label: 'Curated Sets', href: '/collections', description: 'Hand-picked ensembles' },
        ],
      },
      {
        title: 'Categories',
        links: [
          { label: 'Ready to Wear', href: '/collections' },
          { label: 'Leather Goods', href: '/collections' },
          { label: 'Accessories', href: '/collections' },
          { label: 'Home & Objet', href: '/collections' },
        ],
      },
      {
        title: 'By Season',
        links: [
          { label: 'Spring / Summer 2026', href: '/collections' },
          { label: 'Fall / Winter 2025', href: '/collections' },
          { label: 'Resort 2026', href: '/collections' },
        ],
      },
      {
        title: 'Editorial',
        links: [
          { label: 'The Journal', href: '/collections', description: 'Stories & features' },
          { label: 'Lookbooks', href: '/collections', description: 'Seasonal visuals' },
          { label: 'Campaigns', href: '/collections', description: 'Latest films' },
        ],
      },
    ],
  },
  {
    label: 'Maison',
    megaColumns: [
      {
        title: 'Heritage',
        links: [
          { label: 'Our Story', href: '/collections' },
          { label: 'Craftsmanship', href: '/collections' },
          { label: 'Ateliers', href: '/collections' },
        ],
      },
      {
        title: 'Services',
        links: [
          { label: 'Personal Styling', href: '/collections' },
          { label: 'Bespoke Orders', href: '/collections' },
          { label: 'Care & Repair', href: '/collections' },
        ],
      },
    ],
  },
  { label: 'Journal', href: '/collections' },
  { label: 'Boutiques', href: '/collections' },
];

/* ── Icons ──────────────────────────────────────────────────── */
function SearchIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.35-4.35" />
    </svg>
  );
}

function HeartIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

function CartIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="9" cy="21" r="1" />
      <circle cx="20" cy="21" r="1" />
      <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6" />
    </svg>
  );
}

function SunIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="12" cy="12" r="5" />
      <path d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
    </svg>
  );
}

function MenuIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M3 6h18M3 12h12M3 18h18" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

/* ── IconButton ──────────────────────────────────────────────── */
function IconButton({ label, onClick, children }: { label: string; onClick?: () => void; children: React.ReactNode }) {
  return (
    <motion.button
      type="button"
      aria-label={label}
      onClick={onClick}
      className="relative p-2 text-charcoal hover:text-gold rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/50"
      whileTap={{ scale: 0.9 }}
      transition={transition.fast}
    >
      {children}
    </motion.button>
  );
}

/* ── Navbar ─────────────────────────────────────────────────── */
export function Navbar() {
  const { scrolled } = useScrollPosition();
  const { resolved, toggle: toggleTheme } = useTheme();
  const mobileMenu = useToggle();
  const search = useSearch();
  const cart = useCart();
  const wishlist = useWishlist();
  const [activeMega, setActiveMega] = useState<string | null>(null);
  const megaTimer = useRef<ReturnType<typeof setTimeout>>(undefined);

  const openMega = useCallback((label: string) => {
    clearTimeout(megaTimer.current);
    setActiveMega(label);
  }, []);

  const closeMega = useCallback(() => {
    megaTimer.current = setTimeout(() => setActiveMega(null), 200);
  }, []);

  /* Lock body scroll when mobile menu open (preserves previous value) */
  useEffect(() => {
    if (!mobileMenu.open) return;
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => {
      if (document.body.style.overflow === 'hidden') {
        document.body.style.overflow = prev;
      }
    };
  }, [mobileMenu.open]);

  const showBlur = scrolled || mobileMenu.open;

  return (
    <>
      {/* ── Sticky Navbar ─────────────────────────────────── */}
      <header
        className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
          showBlur
            ? 'bg-ivory/85 backdrop-blur-xl shadow-subtle'
            : 'bg-transparent'
        }`}
      >
        {/* Decorative top rule */}
        <div className="h-[3px] bg-gradient-to-r from-charcoal via-gold to-charcoal" />

        <nav className="max-w-7xl mx-auto flex items-center justify-between px-md h-16 lg:h-20">
          {/* ── Logo ───────────────────────────────────────── */}
          <Link to="/" className="flex-shrink-0" aria-label="Home">
            <span className="font-heading text-2xl tracking-tight font-bold text-charcoal">
              ÉDITION
            </span>
          </Link>

          {/* ── Desktop Nav Links ──────────────────────────── */}
          <ul className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <li
                key={item.label}
                className="relative"
                onMouseEnter={() => item.megaColumns && openMega(item.label)}
                onMouseLeave={() => item.megaColumns && closeMega()}
              >
                {item.megaColumns ? (
                  <button
                    type="button"
                    onClick={() =>
                      setActiveMega(activeMega === item.label ? null : item.label)
                    }
                    className={`px-4 py-2 text-sm font-medium rounded-md transition-colors ${
                      activeMega === item.label
                        ? 'text-gold'
                        : 'text-charcoal hover:text-gold'
                    }`}
                  >
                    {item.label}
                  </button>
                ) : (
                  <Link
                    to={item.href ?? '/'}
                    className="block px-4 py-2 text-sm font-medium text-charcoal hover:text-gold rounded-md transition-colors"
                  >
                    {item.label}
                  </Link>
                )}
              </li>
            ))}
          </ul>

          {/* ── Actions ────────────────────────────────────── */}
          <div className="flex items-center gap-1">
            {/* Theme Toggle */}
            <IconButton label="Toggle theme" onClick={toggleTheme}>
              {resolved === 'dark' ? <SunIcon /> : <MoonIcon />}
            </IconButton>

            {/* Search */}
            <IconButton label="Search" onClick={search.toggle}>
              <SearchIcon />
            </IconButton>

            {/* Wishlist */}
            <Link
              to="/wishlist"
              aria-label="Wishlist"
              className="relative p-2 text-charcoal hover:text-gold rounded-full transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-gold/50"
            >
              <HeartIcon />
              {wishlist.itemCount > 0 && (
                <span className="absolute -top-0.5 -right-1 w-4 h-4 rounded-full bg-gold text-charcoal text-[9px] font-bold flex items-center justify-center">
                  {wishlist.itemCount}
                </span>
              )}
            </Link>

            {/* Cart */}
            <IconButton label="Cart" onClick={cart.toggle}>
              <div className="relative">
                <CartIcon />
                {cart.itemCount > 0 && (
                  <span className="absolute -top-1 -right-1.5 w-4 h-4 rounded-full bg-gold text-charcoal text-[9px] font-bold flex items-center justify-center">
                    {cart.itemCount}
                  </span>
                )}
              </div>
            </IconButton>

            {/* Mobile menu toggle */}
            <div className="lg:hidden ml-1">
              <IconButton label={mobileMenu.open ? 'Close menu' : 'Open menu'} onClick={mobileMenu.toggle}>
                {mobileMenu.open ? <CloseIcon /> : <MenuIcon />}
              </IconButton>
            </div>
          </div>
        </nav>

        {/* ── Mega Menu Panel ──────────────────────────────── */}
        <AnimatePresence>
          {activeMega && (
            <motion.div
              key="mega-menu"
              variants={fadeIn}
              initial="hidden"
              animate="visible"
              exit="hidden"
              transition={{ duration: 0.25 }}
              className="absolute top-full left-0 right-0 bg-ivory/95 backdrop-blur-xl border-t border-charcoal/10 shadow-elevated"
              onMouseEnter={() => {
                const item = navItems.find((n) => n.label === activeMega);
                if (item?.megaColumns) openMega(activeMega);
              }}
              onMouseLeave={closeMega}
            >
              <div className="max-w-7xl mx-auto px-md py-xl">
                {navItems
                  .filter((n) => n.label === activeMega && n.megaColumns)
                  .map((item) => (
                    <div key={item.label} className="grid grid-cols-4 gap-xl">
                      {item.megaColumns?.map((col) => (
                        <div key={col.title}>
                          <p className="text-xs tracking-[0.2em] uppercase font-medium text-gold mb-md">
                            {col.title}
                          </p>
                          <ul className="space-y-3">
                            {col.links.map((link) => (
                              <li key={link.label}>
                                <Link
                                  to={link.href}
                                  className="block group"
                                  onClick={() => setActiveMega(null)}
                                >
                                  <span className="text-sm font-medium text-charcoal group-hover:text-gold transition-colors">
                                    {link.label}
                                  </span>
                                  {link.description && (
                                    <span className="block text-xs text-charcoal/50 mt-0.5 leading-tight">
                                      {link.description}
                                    </span>
                                  )}
                                </Link>
                              </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* ── Mobile Drawer ──────────────────────────────────── */}
      <AnimatePresence>
        {mobileMenu.open && (
          <>
            {/* Backdrop */}
            <motion.div
              variants={fadeIn}
              initial="hidden"
              animate="visible"
              exit="hidden"
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[55] bg-charcoal/20 lg:hidden"
              onClick={mobileMenu.off}
            />

            {/* Drawer */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.3, ease: [0.19, 1, 0.22, 1] }}
              className="fixed top-0 right-0 bottom-0 z-[56] w-full max-w-sm bg-ivory shadow-elevated lg:hidden flex flex-col"
            >
              <div className="flex items-center justify-between px-md h-16 border-b border-charcoal/10">
                <span className="font-heading text-xl font-bold text-charcoal">
                  ÉDITION
                </span>
                <IconButton label="Close menu" onClick={mobileMenu.off}>
                  <CloseIcon />
                </IconButton>
              </div>

              <div className="flex-1 overflow-y-auto px-md py-lg">
                <ul className="space-y-1">
                  {navItems.map((item, i) => (
                    <motion.li
                      key={item.label}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.05 * i, duration: 0.3 }}
                    >
                      {item.megaColumns ? (
                        <MobileMegaGroup
                          item={item}
                          onLinkClick={mobileMenu.off}
                        />
                      ) : (
                        <Link
                          to={item.href ?? '/'}
                          onClick={mobileMenu.off}
                          className="block py-3 text-base font-medium text-charcoal hover:text-gold transition-colors"
                        >
                          {item.label}
                        </Link>
                      )}
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Mobile theme toggle */}
              <div className="px-md py-lg border-t border-charcoal/10">
                <button
                  type="button"
                  onClick={toggleTheme}
                  className="flex items-center gap-3 text-sm text-charcoal hover:text-gold transition-colors w-full py-2"
                >
                  {resolved === 'dark' ? <SunIcon /> : <MoonIcon />}
                  <span>{resolved === 'dark' ? 'Light' : 'Dark'} Mode</span>
                </button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* ── Spacer (so content doesn't sit under the fixed nav) ── */}
      <div className="h-16 lg:h-20" />
    </>
  );
}

/* ── Mobile Accordion Mega ──────────────────────────────────── */
function MobileMegaGroup({
  item,
  onLinkClick,
}: {
  item: NavItem;
  onLinkClick: () => void;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div>
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="flex items-center justify-between w-full py-3 text-base font-medium text-charcoal hover:text-gold transition-colors"
      >
        {item.label}
        <motion.span
          animate={{ rotate: expanded ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="text-charcoal/40"
        >
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M6 9l6 6 6-6" />
          </svg>
        </motion.span>
      </button>
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25 }}
            className="overflow-hidden"
          >
            <div className="pb-3 space-y-2">
              {item.megaColumns?.map((col) => (
                <div key={col.title} className="pl-4">
                  <p className="text-xs tracking-[0.2em] uppercase font-medium text-gold mb-2 pt-2">
                    {col.title}
                  </p>
                  {col.links.map((link) => (
                    <Link
                      key={link.label}
                      to={link.href}
                      onClick={onLinkClick}
                      className="block py-1.5 text-sm text-charcoal/80 hover:text-gold transition-colors"
                    >
                      {link.label}
                    </Link>
                  ))}
                </div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
