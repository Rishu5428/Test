import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/Button';
import { transition } from '@/utils/animation';

/* ── Footer Data ────────────────────────────────────────────── */
const footerColumns = [
  {
    title: 'Company',
    links: [
      { label: 'Our Story', href: '/collections' },
      { label: 'Craftsmanship', href: '/collections' },
      { label: 'Careers', href: '/collections' },
      { label: 'Press', href: '/collections' },
    ],
  },
  {
    title: 'Collections',
    links: [
      { label: 'New Arrivals', href: '/collections' },
      { label: 'Bestsellers', href: '/collections' },
      { label: 'Ready to Wear', href: '/collections' },
      { label: 'Accessories', href: '/collections' },
    ],
  },
  {
    title: 'Support',
    links: [
      { label: 'Contact', href: '/collections' },
      { label: 'Shipping & Returns', href: '/collections' },
      { label: 'Care Guide', href: '/collections' },
      { label: 'FAQ', href: '/collections' },
    ],
  },
];

const socialLinks = [
  { label: 'Instagram', href: '#', icon: InstagramIcon },
  { label: 'Pinterest', href: '#', icon: PinterestIcon },
  { label: 'YouTube', href: '#', icon: YoutubeIcon },
  { label: 'LinkedIn', href: '#', icon: LinkedInIcon },
];

/* ── Social Icons ───────────────────────────────────────────── */
function InstagramIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <rect x="2" y="2" width="20" height="20" rx="5" />
      <circle cx="12" cy="12" r="4.5" />
      <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
    </svg>
  );
}

function PinterestIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a10 10 0 0 0-3 19.5c-.1-1 .3-2.6.5-3.7l2-8.2s-.5-1-.5-2.4c0-2.2 1.3-3.9 2.9-3.9 1.4 0 2 1 2 2.3 0 1.4-.9 3.5-1.3 5.4-.4 1.6.8 2.9 2.3 2.9 2.8 0 4.7-3.6 4.7-7.8 0-3.2-2.2-5.6-6.1-5.6-4.4 0-7.2 3.3-7.2 7 0 1.3.4 2.2 1 3" />
    </svg>
  );
}

function YoutubeIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M22.54 6.42a2.78 2.78 0 0 0-1.94-2C18.88 4 12 4 12 4s-6.88 0-8.6.46a2.78 2.78 0 0 0-1.94 2A29.9 29.9 0 0 0 1 11.75a29.9 29.9 0 0 0 .46 5.33 2.78 2.78 0 0 0 1.94 2c1.72.46 8.6.46 8.6.46s6.88 0 8.6-.46a2.78 2.78 0 0 0 1.94-2 29.9 29.9 0 0 0 .46-5.25 29.9 29.9 0 0 0-.46-5.41z" />
      <polygon points="9.75 15.02 15.5 11.75 9.75 8.48 9.75 15.02" fill="currentColor" stroke="none" />
    </svg>
  );
}

function LinkedInIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <rect x="2" y="2" width="20" height="20" rx="3" />
      <path d="M7 10v7M7 7v.01M11 17v-4.5a1.5 1.5 0 1 1 3 0V17M16 17v-5a2 2 0 0 0-4 0" />
    </svg>
  );
}

/* ── Footer ─────────────────────────────────────────────────── */
export function Footer() {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletter = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer className="bg-charcoal text-ivory">
      <div className="max-w-7xl mx-auto">
        {/* ── Newsletter ────────────────────────────────────── */}
        <div className="px-md pt-3xl pb-2xl border-b border-ivory/10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={transition.reveal}
            className="max-w-2xl"
          >
            <p className="text-xs tracking-[0.2em] uppercase font-medium text-gold mb-sm">
              The Newsletter
            </p>
            <h3 className="font-heading text-2xl lg:text-3xl font-semibold tracking-tight mb-sm">
              Receive our latest collections,<br />stories, and invitations.
            </h3>
            <p className="text-sm text-ivory/60 mb-md leading-relaxed">
              Join a discerning community. Delivered weekly — unsubscribe at any time.
            </p>

            {subscribed ? (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-sm text-gold font-medium"
              >
                Thank you for subscribing.
              </motion.p>
            ) : (
              <form
                onSubmit={handleNewsletter}
                className="flex flex-col sm:flex-row gap-3"
              >
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Your email address"
                  required
                  aria-label="Email address"
                  className="flex-1 bg-transparent border border-ivory/20 rounded-md px-5 py-3 text-sm text-ivory placeholder:text-ivory/30 outline-none focus:border-gold transition-colors"
                />
                <Button type="submit" size="md" className="bg-gold text-charcoal border-gold hover:bg-gold/90 whitespace-nowrap">
                  Subscribe
                </Button>
              </form>
            )}
          </motion.div>
        </div>

        {/* ── Columns ────────────────────────────────────────── */}
        <div className="px-md py-2xl grid grid-cols-2 md:grid-cols-4 gap-xl">
          {footerColumns.map((col) => (
            <motion.div
              key={col.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: '-40px' }}
              transition={transition.reveal}
            >
              <p className="text-xs tracking-[0.2em] uppercase font-medium text-gold mb-md">
                {col.title}
              </p>
              <ul className="space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.href}
                      className="text-sm text-ivory/70 hover:text-ivory transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}

          {/* Social column */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: '-40px' }}
            transition={transition.reveal}
          >
            <p className="text-xs tracking-[0.2em] uppercase font-medium text-gold mb-md">
              Social
            </p>
            <div className="flex items-center gap-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  aria-label={social.label}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-ivory/60 hover:text-gold transition-colors"
                >
                  <social.icon />
                </a>
              ))}
            </div>
          </motion.div>
        </div>

        {/* ── Bottom Bar ─────────────────────────────────────── */}
        <div className="px-md py-lg border-t border-ivory/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-ivory/40">
            &copy; {new Date().getFullYear()} Édition. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link to="/legal/privacy" className="text-xs text-ivory/40 hover:text-ivory/70 transition-colors">
              Privacy Policy
            </Link>
            <Link to="/legal/terms" className="text-xs text-ivory/40 hover:text-ivory/70 transition-colors">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
