import { Navigate, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuth } from '@/contexts/AuthContext';
import type { AuthRole } from '@/types';

/* ── ProtectedRoute ───────────────────────────────────────────
   Wraps dashboard / admin routes. Redirects unauthenticated
   users to login, and unauthorized roles to a "forbidden" view.
*/

interface ProtectedRouteProps {
  children: React.ReactNode;
  /** Minimum role required. Defaults to 'staff' (any logged-in user). */
  minRole?: AuthRole;
}

export function ProtectedRoute({
  children,
  minRole = 'staff',
}: ProtectedRouteProps) {
  const { isAuthenticated, hasRole, loading } = useAuth();
  const location = useLocation();

  /* Show spinner while session is being restored */
  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
          className="w-8 h-8 border-2 border-gold/30 border-t-gold rounded-full"
        />
      </div>
    );
  }

  /* Not logged in — redirect to login with return path */
  if (!isAuthenticated) {
    return (
      <Navigate
        to={`/auth/login?redirect=${encodeURIComponent(location.pathname)}`}
        replace
      />
    );
  }

  /* Logged in but insufficient role */
  if (!hasRole(minRole)) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-md">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="w-20 h-20 rounded-full bg-charcoal/5 flex items-center justify-center mb-lg mx-auto">
            <svg
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              strokeLinecap="round"
              className="text-charcoal/25"
            >
              <rect x="3" y="11" width="18" height="11" rx="2" />
              <path d="M7 11V7a5 5 0 0 1 10 0v4" />
            </svg>
          </div>
          <h2 className="font-heading text-2xl font-semibold text-charcoal mb-2">
            Access Denied
          </h2>
          <p className="text-charcoal/50 text-sm max-w-sm">
            You don&rsquo;t have permission to view this page. Please contact your administrator if you believe this is a mistake.
          </p>
        </motion.div>
      </div>
    );
  }

  return <>{children}</>;
}
