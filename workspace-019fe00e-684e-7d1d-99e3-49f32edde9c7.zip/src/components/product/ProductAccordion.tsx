import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Text } from '@/components/ui/Typography';
import { transition } from '@/utils/animation';

/* ── Accordion Item ─────────────────────────────────────────── */
interface AccordionItemProps {
  label: string;
  defaultOpen?: boolean;
  children: React.ReactNode;
}

function ChevronDown() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M6 9l6 6 6-6" />
    </svg>
  );
}

function AccordionItem({ label, defaultOpen = false, children }: AccordionItemProps) {
  const [open, setOpen] = useState(defaultOpen);

  return (
    <div className="border-b border-charcoal/10 last:border-b-0">
      <motion.button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="flex items-center justify-between w-full py-lg text-left"
        whileTap={{ scale: 0.99 }}
      >
        <Text variant="body-sm" weight="medium" className="text-charcoal/80">
          {label}
        </Text>
        <motion.span
          animate={{ rotate: open ? 180 : 0 }}
          transition={{ duration: 0.2 }}
          className="text-charcoal/30 ml-4 flex-shrink-0"
        >
          <ChevronDown />
        </motion.span>
      </motion.button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: [0.19, 1, 0.22, 1] }}
            className="overflow-hidden"
          >
            <div className="pb-lg text-charcoal/60 text-sm leading-relaxed">
              {children}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

/* ── ProductAccordion ───────────────────────────────────────── */
interface ProductAccordionProps {
  description: string;
  material: string;
  fit: string;
  care: string[];
  shipping: string;
  returns: string;
}

export function ProductAccordion({
  description,
  material,
  fit,
  care,
  shipping,
  returns,
}: ProductAccordionProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 16 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={transition.reveal}
    >
      <AccordionItem label="Description" defaultOpen>
        <p className="mb-md">{description}</p>
        <div className="space-y-2 border-t border-charcoal/5 pt-md">
          <div>
            <Text variant="caption" as="span" className="text-charcoal/50">
              Material
            </Text>
            <p className="mt-0.5">{material}</p>
          </div>
          <div>
            <Text variant="caption" as="span" className="text-charcoal/50">
              Fit
            </Text>
            <p className="mt-0.5">{fit}</p>
          </div>
        </div>
      </AccordionItem>

      <AccordionItem label="Care Instructions">
        <ul className="space-y-2">
          {care.map((item) => (
            <li key={item} className="flex items-start gap-2">
              <span className="mt-1.5 w-1 h-1 rounded-full bg-gold/60 flex-shrink-0" />
              {item}
            </li>
          ))}
        </ul>
      </AccordionItem>

      <AccordionItem label="Shipping">
        <p>{shipping}</p>
      </AccordionItem>

      <AccordionItem label="Returns & Exchanges">
        <p>{returns}</p>
      </AccordionItem>
    </motion.div>
  );
}
