import { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import { fadeIn, staggerContainer } from '@/utils/animation';
import type { Variant } from '@/utils/productDetail';

/* ── Types ─────────────────────────────────────────────────── */
interface StickyBuyPanelProps {
  name: string;
  category: string;
  price: string;
  rating: number;
  sku: string;
  variantGroups: Variant[][];
  inStock?: boolean;
  onAddToCart?: (data: { qty: number; variants: Record<number, string> }) => void;
  onWishlist?: () => void;
}

/* ── Icons ─────────────────────────────────────────────────── */
function HeartIcon({ filled }: { filled: boolean }) {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}

function MinusIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M5 12h14" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
      <path d="M12 5v14M5 12h14" />
    </svg>
  );
}

function StarIconFilled() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" className="text-gold">
      <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
    </svg>
  );
}

/* ── Variant Labels ─────────────────────────────────────────── */
const variantLabels = ['Size', 'Colour'];

/* ── StickyBuyPanel ─────────────────────────────────────────── */
export function StickyBuyPanel({
  name,
  category,
  price,
  rating,
  sku,
  variantGroups,
  inStock = true,
  onAddToCart,
  onWishlist,
}: StickyBuyPanelProps) {
  const [selectedVariants, setSelectedVariants] = useState<Record<number, string>>({});
  const [qty, setQty] = useState(1);
  const [wishlisted, setWishlisted] = useState(false);
  const [added, setAdded] = useState(false);

  const handleVariant = useCallback(
    (groupIdx: number, variantId: string) => {
      setSelectedVariants((prev) => ({
        ...prev,
        [groupIdx]: prev[groupIdx] === variantId ? '' : variantId,
      }));
    },
    [],
  );

  const handleWishlist = useCallback(() => {
    setWishlisted((v) => !v);
    onWishlist?.();
  }, [onWishlist]);

  const handleAddToCart = useCallback(() => {
    setAdded(true);
    onAddToCart?.({ qty, variants: selectedVariants });
    setTimeout(() => setAdded(false), 2000);
  }, [qty, selectedVariants, onAddToCart]);

  return (
    <motion.div
      variants={staggerContainer}
      initial="hidden"
      animate="visible"
      className="lg:sticky lg:top-24 space-y-lg"
    >
      {/* ── Header ─────────────────────────────────────────── */}
      <motion.div variants={fadeIn}>
        <Text variant="overline" className="mb-1">{category}</Text>
        <Heading as="h2" className="mb-sm">{name}</Heading>

        {/* Rating + SKU */}
        <div className="flex items-center gap-3 mb-3">
          <div className="flex items-center gap-1">
            <StarIconFilled />
            <Text variant="body-sm" className="text-charcoal/70">{rating}</Text>
          </div>
          <span className="w-1 h-1 rounded-full bg-charcoal/20" />
          <Text variant="caption" as="span">SKU: {sku}</Text>
        </div>

        {/* Price */}
        <div className="flex items-baseline gap-2">
          <span className="font-heading text-3xl font-semibold text-charcoal">
            {price}
          </span>
          <Text variant="caption" as="span">INR</Text>
        </div>
      </motion.div>

      {/* ── Variants ────────────────────────────────────────── */}
      {variantGroups.map((group, gi) => (
        <motion.div key={gi} variants={fadeIn}>
          <div className="flex items-center justify-between mb-2">
            <Text variant="caption" as="div" className="font-semibold text-charcoal/80">
              {variantLabels[gi] ?? `Option ${gi + 1}`}
            </Text>
            {selectedVariants[gi] && (
              <Text variant="caption" as="span">
                {group.find((v) => v.id === selectedVariants[gi])?.label}
              </Text>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {group.map((variant) => {
              const selected = selectedVariants[gi] === variant.id;
              return (
                <motion.button
                  key={variant.id}
                  type="button"
                  onClick={() => handleVariant(gi, variant.id)}
                  whileTap={{ scale: 0.95 }}
                  className={`px-4 py-2.5 text-sm rounded-md border transition-colors ${
                    selected
                      ? 'border-charcoal bg-charcoal text-ivory'
                      : 'border-charcoal/15 text-charcoal/70 hover:border-charcoal/40'
                  }`}
                >
                  {variant.label}
                </motion.button>
              );
            })}
          </div>
        </motion.div>
      ))}

      {/* ── Quantity ────────────────────────────────────────── */}
      <motion.div variants={fadeIn}>
        <Text variant="caption" as="div" className="font-semibold text-charcoal/80 mb-2">
          Quantity
        </Text>
        <div className="flex items-center gap-3">
          <div className="flex items-center border border-charcoal/15 rounded-md">
            <motion.button
              type="button"
              onClick={() => setQty((v) => Math.max(1, v - 1))}
              whileTap={{ scale: 0.9 }}
              disabled={qty <= 1}
              className="p-3 text-charcoal/60 hover:text-charcoal disabled:opacity-30 transition-colors"
              aria-label="Decrease quantity"
            >
              <MinusIcon />
            </motion.button>
            <span className="w-10 text-center text-sm font-medium tabular-nums">{qty}</span>
            <motion.button
              type="button"
              onClick={() => setQty((v) => Math.min(10, v + 1))}
              whileTap={{ scale: 0.9 }}
              disabled={qty >= 10}
              className="p-3 text-charcoal/60 hover:text-charcoal disabled:opacity-30 transition-colors"
              aria-label="Increase quantity"
            >
              <PlusIcon />
            </motion.button>
          </div>
        </div>
      </motion.div>

      {/* ── Actions ─────────────────────────────────────────── */}
      <motion.div variants={fadeIn} className="flex flex-col gap-3 pt-md">
        {inStock ? (
          <>
            <Button
              onClick={handleAddToCart}
              variant="primary"
              size="lg"
              className="w-full"
            >
              {added ? 'Added to Cart' : 'Add to Cart'}
            </Button>

            <motion.button
              type="button"
              onClick={handleWishlist}
              className={`flex items-center justify-center gap-2 w-full py-3 text-sm font-medium rounded-md border transition-colors ${
                wishlisted
                  ? 'border-gold/30 text-gold bg-gold/5'
                  : 'border-charcoal/15 text-charcoal/70 hover:border-charcoal/30'
              }`}
              whileTap={{ scale: 0.97 }}
            >
              <HeartIcon filled={wishlisted} />
              {wishlisted ? 'Saved to Wishlist' : 'Add to Wishlist'}
            </motion.button>

            {/* Trust badges */}
            <div className="flex items-center justify-center gap-6 pt-2">
              <span className="flex items-center gap-1.5 text-xs text-charcoal/40">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><rect x="1" y="3" width="15" height="13"/><path d="M16 8h5l3 4.5V16h-3a2 2 0 0 1-4 0"/><circle cx="7" cy="18" r="2"/></svg>
                Free Shipping
              </span>
              <span className="flex items-center gap-1.5 text-xs text-charcoal/40">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="M22 4L12 14.01l-3-3"/></svg>
                30-Day Returns
              </span>
            </div>
          </>
        ) : (
          <div className="text-center py-lg border border-charcoal/10 rounded-md">
            <Text variant="body-sm" className="text-charcoal/50">
              Currently out of stock
            </Text>
            <Link to="/collections" className="text-sm text-gold hover:underline mt-1 inline-block">
              Notify me when available
            </Link>
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
