import { useState, useCallback, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { fadeIn, transition } from '@/utils/animation';

/* ── Gallery ──────────────────────────────────────────────────
   Luxury editorial gallery with thumbnail strip, hover zoom,
   and fullscreen lightbox. Reuses existing animation system.
*/

interface GalleryProps {
  images: string[];
  alt: string;
}

function ZoomIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35M11 8v6M8 11h6" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

function ChevronLeft() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M15 18l-6-6 6-6" />
    </svg>
  );
}

function ChevronRight() {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M9 18l6-6-6-6" />
    </svg>
  );
}

/* ── Gradient palette for placeholders ─────────────────────── */
const gradients = [
  'from-charcoal/5 via-ivory to-gold/15',
  'from-gold/10 via-ivory to-charcoal/5',
  'from-charcoal/8 via-gold/5 to-ivory',
  'from-ivory via-gold/10 to-charcoal/6',
  'from-gold/8 via-ivory to-charcoal/7',
];

const shapes = [
  'rounded-t-full rounded-b-lg',
  'rounded-lg',
  'rounded-full',
  'rounded-b-full rounded-t-lg',
  'rounded-t-full rounded-b-lg',
];

const PlaceholderImage = ({ idx, className = '' }: { idx: number; className?: string }) => (
  <div className={`absolute inset-0 bg-gradient-to-br ${gradients[idx % gradients.length]} ${className}`}>
    <div className="absolute inset-0 flex items-center justify-center">
      <div className={`w-2/5 h-3/5 bg-gradient-to-b from-charcoal/10 via-charcoal/5 to-charcoal/8 ${shapes[idx % shapes.length]}`} />
    </div>
    <div className="absolute bottom-6 left-6 w-12 h-px bg-gold/30" />
  </div>
);

/* ── Gallery Component ──────────────────────────────────────── */
export function Gallery({ images }: GalleryProps) {
  const [activeIdx, setActiveIdx] = useState(0);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [zoomPos, setZoomPos] = useState({ x: 0.5, y: 0.5, show: false });
  const imageRef = useRef<HTMLDivElement>(null);

  const total = images.length;

  const handleZoomMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    const el = imageRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    setZoomPos({
      x: (e.clientX - rect.left) / rect.width,
      y: (e.clientY - rect.top) / rect.height,
      show: true,
    });
  }, []);

  const next = useCallback(() => setActiveIdx((v) => (v + 1) % total), [total]);
  const prev = useCallback(() => setActiveIdx((v) => (v - 1 + total) % total), [total]);

  return (
    <div className="w-full">
      {/* ── Main Image ─────────────────────────────────────── */}
      <motion.div
        ref={imageRef}
        variants={fadeIn}
        initial="hidden"
        animate="visible"
        className="relative aspect-[3/4] rounded-lg overflow-hidden shadow-elevated cursor-crosshair"
        onMouseMove={handleZoomMove}
        onMouseEnter={() => setZoomPos((p) => ({ ...p, show: true }))}
        onMouseLeave={() => setZoomPos((p) => ({ ...p, show: false }))}
      >
        <AnimatePresence mode="wait">
          <motion.div
            key={activeIdx}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0"
          >
            {/* Zoom transform */}
            <div
              className="absolute inset-0 transition-transform duration-150"
              style={{
                transform: zoomPos.show
                  ? `scale(1.8) translate(${(0.5 - zoomPos.x) * 30}%, ${(0.5 - zoomPos.y) * 30}%)`
                  : 'scale(1) translate(0, 0)',
                transformOrigin: `${zoomPos.x * 100}% ${zoomPos.y * 100}%`,
              }}
            >
              <PlaceholderImage idx={activeIdx} />
            </div>
          </motion.div>
        </AnimatePresence>

        {/* Zoom hint */}
        <div className="absolute top-4 right-4 p-2 rounded-full bg-ivory/60 backdrop-blur-sm text-charcoal/40 pointer-events-none">
          <ZoomIcon />
        </div>

        {/* Arrows */}
        {total > 1 && (
          <>
            <motion.button
              type="button"
              onClick={prev}
              whileTap={{ scale: 0.9 }}
              className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-ivory/80 backdrop-blur-sm text-charcoal/60 hover:text-charcoal transition-colors shadow-subtle"
              aria-label="Previous image"
            >
              <ChevronLeft />
            </motion.button>
            <motion.button
              type="button"
              onClick={next}
              whileTap={{ scale: 0.9 }}
              className="absolute right-4 top-1/2 -translate-y-1/2 p-2 rounded-full bg-ivory/80 backdrop-blur-sm text-charcoal/60 hover:text-charcoal transition-colors shadow-subtle"
              aria-label="Next image"
            >
              <ChevronRight />
            </motion.button>
          </>
        )}

        {/* Fullscreen trigger */}
        <motion.button
          type="button"
          onClick={() => setLightboxOpen(true)}
          whileTap={{ scale: 0.9 }}
          className="absolute bottom-4 right-4 p-2 rounded-full bg-ivory/80 backdrop-blur-sm text-charcoal/50 hover:text-charcoal transition-colors shadow-subtle"
          aria-label="Open fullscreen"
        >
          <ZoomIcon />
        </motion.button>
      </motion.div>

      {/* ── Thumbnail Strip ─────────────────────────────────── */}
      {total > 1 && (
        <motion.div
          variants={fadeIn}
          initial="hidden"
          animate="visible"
          transition={{ delay: 0.2, ...transition.reveal }}
          className="flex gap-3 mt-md"
        >
          {images.map((img, i) => (
            <motion.button
              key={img}
              type="button"
              onClick={() => setActiveIdx(i)}
              whileTap={{ scale: 0.95 }}
              className={`relative w-16 md:w-20 aspect-square rounded-md overflow-hidden flex-shrink-0 transition-all duration-300 ${
                i === activeIdx
                  ? 'ring-2 ring-gold ring-offset-2 ring-offset-ivory'
                  : 'opacity-50 hover:opacity-80'
              }`}
            >
              <PlaceholderImage idx={i} />
            </motion.button>
          ))}
        </motion.div>
      )}

      {/* ── Fullscreen Lightbox ─────────────────────────────── */}
      <AnimatePresence>
        {lightboxOpen && (
          <motion.div
            variants={fadeIn}
            initial="hidden"
            animate="visible"
            exit="hidden"
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-[100] bg-ivory flex items-center justify-center"
          >
            {/* Close */}
            <button
              type="button"
              onClick={() => setLightboxOpen(false)}
              className="absolute top-6 right-6 p-2 text-charcoal/60 hover:text-charcoal z-10 transition-colors"
              aria-label="Close gallery"
            >
              <CloseIcon />
            </button>

            {/* Counter */}
            <span className="absolute top-6 left-6 text-xs tracking-wider text-charcoal/40 z-10">
              {activeIdx + 1} / {total}
            </span>

            {/* Main */}
            <div className="w-full max-w-5xl px-4">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeIdx}
                  initial={{ opacity: 0, scale: 0.96 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 1.02 }}
                  transition={{ duration: 0.3 }}
                  className="aspect-[3/4] max-h-[80vh] mx-auto rounded-lg overflow-hidden relative"
                >
                  <PlaceholderImage idx={activeIdx} />
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Arrows */}
            {total > 1 && (
              <>
                <button
                  type="button"
                  onClick={prev}
                  className="absolute left-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-ivory/50 backdrop-blur-sm text-charcoal/60 hover:text-charcoal transition-colors"
                  aria-label="Previous"
                >
                  <ChevronLeft />
                </button>
                <button
                  type="button"
                  onClick={next}
                  className="absolute right-6 top-1/2 -translate-y-1/2 p-3 rounded-full bg-ivory/50 backdrop-blur-sm text-charcoal/60 hover:text-charcoal transition-colors"
                  aria-label="Next"
                >
                  <ChevronRight />
                </button>
              </>
            )}

            {/* Thumbnails */}
            <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex gap-3">
              {images.map((img, i) => (
                <button
                  key={img}
                  type="button"
                  onClick={() => setActiveIdx(i)}
                  className={`w-12 h-12 rounded-md overflow-hidden transition-all duration-300 ${
                    i === activeIdx
                      ? 'ring-2 ring-gold ring-offset-2 ring-offset-ivory scale-110'
                      : 'opacity-40 hover:opacity-70'
                  }`}
                >
                  <PlaceholderImage idx={i} className="rounded-md" />
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
