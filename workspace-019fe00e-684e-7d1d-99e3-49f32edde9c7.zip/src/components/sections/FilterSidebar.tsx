import { useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import {
  fadeInStatic,
} from '@/utils/animation';
import { filterOptions } from '@/utils/products';

/* ── Types ─────────────────────────────────────────────────── */
export interface FilterState {
  category: string[];
  material: string[];
  priceRange: string | null;
  sort: string;
}

interface FilterSidebarProps {
  filters: FilterState;
  onChange: (filters: FilterState) => void;
  open: boolean;
  onClose: () => void;
  totalResults: number;
}

/* ── Icons ─────────────────────────────────────────────────── */
function FilterIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M22 3H2l8 9.46V19l4 2v-8.54L22 3z" />
    </svg>
  );
}

function CloseIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M18 6L6 18M6 6l12 12" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  );
}

/* ── FilterSidebar ──────────────────────────────────────────── */
export function FilterSidebar({
  filters,
  onChange,
  open,
  onClose,
  totalResults,
}: FilterSidebarProps) {
  const toggle = useCallback(
    (group: 'category' | 'material', value: string) => {
      const current = filters[group];
      const next = current.includes(value)
        ? current.filter((v) => v !== value)
        : [...current, value];
      onChange({ ...filters, [group]: next });
    },
    [filters, onChange],
  );

  const setSort = useCallback(
    (value: string) => onChange({ ...filters, sort: value }),
    [filters, onChange],
  );

  const setPrice = useCallback(
    (value: string | null) =>
      onChange({ ...filters, priceRange: filters.priceRange === value ? null : value }),
    [filters, onChange],
  );

  const clearAll = useCallback(() => {
    onChange({ category: [], material: [], priceRange: null, sort: 'featured' });
  }, [onChange]);

  const hasActiveFilters =
    filters.category.length > 0 ||
    filters.material.length > 0 ||
    filters.priceRange !== null ||
    filters.sort !== 'featured';

  const activeCount =
    filters.category.length +
    filters.material.length +
    (filters.priceRange ? 1 : 0) +
    (filters.sort !== 'featured' ? 1 : 0);

  const sidebar = (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between px-md py-lg border-b border-charcoal/10">
        <div className="flex items-center gap-2">
          <span className="text-gold"><FilterIcon /></span>
          <Text variant="body-sm" weight="medium">
            Filters
            {activeCount > 0 && (
              <span className="ml-1 text-gold">({activeCount})</span>
            )}
          </Text>
        </div>
        <div className="flex items-center gap-3">
          {hasActiveFilters && (
            <button
              type="button"
              onClick={clearAll}
              className="text-xs text-charcoal/50 hover:text-charcoal transition-colors"
            >
              Clear all
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="lg:hidden p-1 text-charcoal/50 hover:text-charcoal transition-colors"
            aria-label="Close filters"
          >
            <CloseIcon />
          </button>
        </div>
      </div>

      {/* Filter groups */}
      <div className="flex-1 overflow-y-auto px-md py-lg space-y-xl">
        {/* Sort */}
        <FilterGroup title="Sort By">
          <div className="space-y-1">
            {filterOptions.sort.map((opt) => (
              <FilterChip
                key={opt.value}
                label={opt.label}
                active={filters.sort === opt.value}
                onClick={() => setSort(opt.value)}
              />
            ))}
          </div>
        </FilterGroup>

        {/* Category */}
        <FilterGroup title="Category">
          <div className="space-y-1">
            {filterOptions.category.map((cat) => (
              <FilterCheck
                key={cat}
                label={cat}
                checked={filters.category.includes(cat)}
                onChange={() => toggle('category', cat)}
              />
            ))}
          </div>
        </FilterGroup>

        {/* Material */}
        <FilterGroup title="Material">
          <div className="space-y-1">
            {filterOptions.material.map((mat) => (
              <FilterCheck
                key={mat}
                label={mat}
                checked={filters.material.includes(mat)}
                onChange={() => toggle('material', mat)}
              />
            ))}
          </div>
        </FilterGroup>

        {/* Price Range */}
        <FilterGroup title="Price Range">
          <div className="space-y-1">
            {filterOptions.priceRanges.map((pr) => (
              <FilterChip
                key={pr.value}
                label={pr.label}
                active={filters.priceRange === pr.value}
                onClick={() => setPrice(pr.value)}
              />
            ))}
          </div>
        </FilterGroup>
      </div>

      {/* Bottom bar */}
      <div className="px-md py-lg border-t border-charcoal/10 lg:hidden">
        <Button
          onClick={onClose}
          variant="primary"
          size="md"
          className="w-full"
        >
          Show {totalResults} Results
        </Button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop: inline sidebar */}
      <aside className="hidden lg:block w-56 flex-shrink-0">
        <div className="sticky top-24 rounded-lg border border-charcoal/5 bg-ivory/80 backdrop-blur-sm overflow-hidden">
          {sidebar}
        </div>
      </aside>

      {/* Mobile: slide-in drawer */}
      <AnimatePresence>
        {open && (
          <>
            <motion.div
              variants={fadeInStatic}
              initial="hidden"
              animate="visible"
              exit="hidden"
              transition={{ duration: 0.2 }}
              className="fixed inset-0 z-[70] bg-charcoal/30 lg:hidden"
              onClick={onClose}
            />
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ duration: 0.3, ease: [0.19, 1, 0.22, 1] }}
              className="fixed top-0 left-0 bottom-0 z-[71] w-72 max-w-[85vw] bg-ivory shadow-elevated lg:hidden"
            >
              {sidebar}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}

/* ── Sub-components ─────────────────────────────────────────── */
function FilterGroup({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Text
        variant="caption"
        as="div"
        className="mb-2 font-semibold text-charcoal/80"
      >
        {title}
      </Text>
      {children}
    </div>
  );
}

function FilterChip({
  label,
  active,
  onClick,
}: {
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <motion.button
      type="button"
      onClick={onClick}
      whileTap={{ scale: 0.97 }}
      className={`block w-full text-left px-3 py-2 text-sm rounded-md transition-colors ${
        active
          ? 'bg-charcoal/5 text-gold font-medium'
          : 'text-charcoal/60 hover:text-charcoal hover:bg-charcoal/3'
      }`}
    >
      {label}
    </motion.button>
  );
}

function FilterCheck({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <motion.button
      type="button"
      onClick={onChange}
      whileTap={{ scale: 0.97 }}
      className="flex items-center gap-2 w-full px-3 py-2 text-sm rounded-md text-charcoal/70 hover:text-charcoal hover:bg-charcoal/3 transition-colors"
    >
      <span
        className={`w-4 h-4 rounded-xs border flex items-center justify-center flex-shrink-0 transition-colors ${
          checked
            ? 'bg-gold border-gold text-ivory'
            : 'border-charcoal/20'
        }`}
      >
        {checked && <CheckIcon />}
      </span>
      {label}
    </motion.button>
  );
}
