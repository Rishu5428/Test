import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';
import type { ProductData } from '@/components/ui/ProductCard';
import { useScrollPosition } from '@/hooks/useScrollPosition';
import {
  slideInLeft,
  slideInRight,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
interface FeaturedProductProps {
  overline?: string;
  title?: string;
  description?: string;
  product?: ProductData;
  features?: string[];
  ctaLabel?: string;
  secondaryLabel?: string;
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultProduct: ProductData = {
  id: 'fp1',
  name: 'The Artisan Coat',
  category: 'Limited Edition',
  price: '₹ 1,85,000',
  href: '/products/artisan-coat',
};

const defaultFeatures = [
  'Italian virgin wool — Loro Piana mill',
  'Hand-set horn buttons',
  'Half-canvas construction, fully lined in cupro',
  'Made in our Milan atelier',
];

/* ── Section ───────────────────────────────────────────────── */
export function FeaturedProduct({
  overline = 'Featured Piece',
  title = 'The Artisan Coat',
  description = 'Six months in the making. From the first sketch to the final stitch, every detail of this coat is a testament to the pursuit of perfection. Limited to 50 pieces worldwide.',
  product = defaultProduct,
  features = defaultFeatures,
  ctaLabel = 'Discover This Piece',
  secondaryLabel = 'View Collection',
}: FeaturedProductProps) {
  const { scrollY } = useScrollPosition();
  const parallaxY = scrollY * 0.06;

  return (
    <section className="py-3xl lg:py-4xl overflow-hidden">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-3xl items-center">
        {/* ── Product Visual ──────────────────────────────── */}
        <motion.div
          variants={slideInLeft}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
          className="relative"
          style={{ y: parallaxY }}
        >
          <motion.div
            animate={{ y: [0, -8, 0] }}
            transition={{ duration: 7, repeat: Infinity, ease: 'easeInOut' }}
            className="relative aspect-[3/4] max-w-md mx-auto lg:max-w-none"
          >
            {/* Product placeholder */}
            <div className="absolute inset-4 rounded-lg bg-gradient-to-br from-charcoal/5 via-ivory to-gold/15 shadow-elevated overflow-hidden">
              <div className="absolute inset-8 flex items-center justify-center">
                <div className="w-3/5 h-4/5 bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/10 rounded-t-full rounded-b-xl" />
              </div>
              <div className="absolute top-8 right-8 w-8 h-8 rounded-full bg-gold/10" />
              <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-20 h-px bg-gold/30" />
            </div>
            {/* Rings */}
            <div aria-hidden className="absolute -inset-2 rounded-full border border-gold/8" />
          </motion.div>
        </motion.div>

        {/* ── Product Info ─────────────────────────────────── */}
        <motion.div
          variants={slideInRight}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-80px' }}
        >
          <Text variant="overline" className="mb-sm">{overline}</Text>
          <Heading as="h2" className="mb-md">{title}</Heading>
          <Text variant="body-lg" className="text-charcoal/70 mb-lg leading-relaxed">
            {description}
          </Text>

          {/* Features list */}
          <ul className="space-y-3 mb-xl">
            {features.map((feat) => (
              <li key={feat} className="flex items-start gap-3">
                <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-gold flex-shrink-0" />
                <Text variant="body-sm" className="text-charcoal/70">{feat}</Text>
              </li>
            ))}
          </ul>

          {/* Price & CTAs */}
          <div className="flex items-baseline gap-3 mb-lg">
            <span className="font-heading text-2xl font-semibold text-charcoal">
              {product.price}
            </span>
            <Text variant="caption" as="span">INR</Text>
          </div>

          <div className="flex items-center gap-md">
            <ButtonLink to={product.href} variant="primary" size="lg">
              {ctaLabel}
            </ButtonLink>
            <ButtonLink
              to="/collections"
              variant="outline"
              size="lg"
            >
              {secondaryLabel}
            </ButtonLink>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
