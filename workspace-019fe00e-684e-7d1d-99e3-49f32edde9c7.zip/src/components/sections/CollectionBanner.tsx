import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { fadeIn } from '@/utils/animation';

/* ── CollectionBanner ─────────────────────────────────────────
   Reusable editorial banner for collection/category pages.
   Accepts typed props with sensible defaults.
*/

interface CollectionBannerProps {
  overline?: string;
  title?: string;
  subtitle?: string;
  /** Number of total products shown in the count badge */
  totalProducts?: number;
  /** Custom background gradient override */
  background?: string;
}

export function CollectionBanner({
  overline = 'The Collection',
  title = 'All Products',
  subtitle = 'Explore our complete range of meticulously crafted pieces — each one a study in restraint, form, and enduring quality.',
  totalProducts,
  background = 'from-charcoal/3 via-ivory to-gold/5',
}: CollectionBannerProps) {
  return (
    <section className="relative -mx-md px-md py-3xl lg:py-4xl overflow-hidden">
      {/* Background gradient */}
      <div
        aria-hidden
        className={`absolute inset-0 bg-gradient-to-b ${background} pointer-events-none`}
      />

      {/* Decorative accent */}
      <div
        aria-hidden
        className="absolute top-0 left-1/2 -translate-x-1/2 w-px h-16 bg-gradient-to-b from-transparent via-gold/20 to-transparent"
      />

      <motion.div
        variants={fadeIn}
        initial="hidden"
        animate="visible"
        className="relative max-w-3xl mx-auto text-center"
      >
        <Text variant="overline" className="mb-sm">
          {overline}
        </Text>
        <Heading as="h1" className="mb-md text-balance">
          {title}
        </Heading>
        <Text variant="body-lg" className="text-charcoal/60 max-w-xl mx-auto mb-lg">
          {subtitle}
        </Text>

        {totalProducts !== undefined && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.4, duration: 0.4 }}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-charcoal/10 text-xs text-charcoal/50"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-gold" />
            {totalProducts} pieces
          </motion.div>
        )}
      </motion.div>
    </section>
  );
}
