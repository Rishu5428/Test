import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import {
  fadeIn,
  staggerContainer,
  staggerImmediate,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
export interface Reason {
  id: string;
  number: string;
  title: string;
  description: string;
}

interface WhyChooseUsProps {
  overline?: string;
  title?: string;
  subtitle?: string;
  reasons?: Reason[];
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultReasons: Reason[] = [
  {
    id: 'r1',
    number: '01',
    title: 'Curated Excellence',
    description:
      'Every piece in our collection is individually selected by our creative director. We reject more than we accept.',
  },
  {
    id: 'r2',
    number: '02',
    title: 'Personal Styling',
    description:
      'Complimentary one-on-one consultations — in person at our boutiques or virtually from wherever you are.',
  },
  {
    id: 'r3',
    number: '03',
    title: 'Transparent Sourcing',
    description:
      'We publish the origin of every material. From the sheep farm in New Zealand to the mill in Biella. No secrets.',
  },
  {
    id: 'r4',
    number: '04',
    title: 'Lifetime Care',
    description:
      'Complimentary alterations, repairs, and refresh services. We stand behind our work for as long as you own it.',
  },
];

/* ── Section ───────────────────────────────────────────────── */
export function WhyChooseUs({
  overline = 'The Édition Difference',
  title = 'Why Choose Us',
  subtitle = 'Luxury is not just what you wear — it\'s the experience, the integrity, and the relationship that endures.',
  reasons = defaultReasons,
}: WhyChooseUsProps) {
  return (
    <section className="py-3xl lg:py-4xl bg-charcoal text-ivory -mx-md px-md">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
      >
        {/* ── Header ───────────────────────────────────────── */}
        <div className="text-center max-w-2xl mx-auto mb-2xl">
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">{overline}</Text>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Heading as="h2" className="mb-md">{title}</Heading>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Text variant="body-lg" className="text-ivory/60">{subtitle}</Text>
          </motion.div>
        </div>

        {/* ── Numbered List ────────────────────────────────── */}
        <motion.div
          variants={staggerImmediate}
          className="grid grid-cols-1 md:grid-cols-2 gap-xl max-w-4xl mx-auto"
        >
          {reasons.map((reason) => (
            <motion.div
              key={reason.id}
              variants={fadeIn}
              className="flex gap-lg p-lg"
            >
              <span className="font-heading text-3xl text-gold/60 flex-shrink-0 leading-none">
                {reason.number}
              </span>
              <div>
                <Heading as="h6" className="mb-1 text-ivory">{reason.title}</Heading>
                <Text variant="body-sm" className="text-ivory/60 leading-relaxed">
                  {reason.description}
                </Text>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
}
