import { useState, type FormEvent } from 'react';
import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { Button } from '@/components/ui/Button';
import {
  fadeIn,
  staggerContainer,
  transition,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
interface NewsletterCTAProps {
  overline?: string;
  title?: string;
  description?: string;
  placeholder?: string;
  buttonLabel?: string;
  successMessage?: string;
}

/* ── Section ───────────────────────────────────────────────── */
export function NewsletterCTA({
  overline = 'Stay Connected',
  title = 'The Édition Dispatch',
  description = 'Receive our seasonal lookbooks, private sale invitations, and stories from the atelier — delivered with the same care as our garments.',
  placeholder = 'Your email address',
  buttonLabel = 'Subscribe',
  successMessage = 'Welcome. Expect something beautiful in your inbox soon.',
}: NewsletterCTAProps) {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribed(true);
    setEmail('');
  };

  return (
    <section className="py-3xl lg:py-4xl bg-charcoal text-ivory -mx-md px-md">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
        className="max-w-2xl mx-auto text-center"
      >
        <motion.div variants={fadeIn}>
          <Text variant="overline" className="mb-sm">{overline}</Text>
        </motion.div>
        <motion.div variants={fadeIn}>
          <Heading as="h2" className="mb-md">{title}</Heading>
        </motion.div>
        <motion.div variants={fadeIn}>
          <Text variant="body-lg" className="text-ivory/60 mb-xl max-w-lg mx-auto">
            {description}
          </Text>
        </motion.div>

        {/* ── Form ─────────────────────────────────────────── */}
        <motion.div variants={fadeIn}>
          {subscribed ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.96 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={transition.normal}
            >
              <div className="inline-flex items-center gap-3 px-xl py-lg rounded-lg border border-gold/30">
                <svg
                  width="20"
                  height="20"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  strokeLinecap="round"
                  className="text-gold flex-shrink-0"
                >
                  <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
                  <path d="M22 4L12 14.01l-3-3" />
                </svg>
                <Text variant="body-md" className="text-ivory/80">
                  {successMessage}
                </Text>
              </div>
            </motion.div>
          ) : (
            <form
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto"
            >
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={placeholder}
                required
                aria-label="Email address"
                className="flex-1 bg-transparent border border-ivory/20 rounded-md px-5 py-3 text-sm text-ivory placeholder:text-ivory/30 outline-none focus:border-gold transition-colors"
              />
              <Button
                type="submit"
                size="md"
                className="bg-gold text-charcoal border-gold hover:bg-gold/90 whitespace-nowrap"
              >
                {buttonLabel}
              </Button>
            </form>
          )}
        </motion.div>
      </motion.div>
    </section>
  );
}
