import { useState, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import {
  fadeIn,
  staggerContainer,
  transition,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
export interface Testimonial {
  id: string;
  quote: string;
  author: string;
  title: string;
  location: string;
}

interface TestimonialsProps {
  overline?: string;
  title?: string;
  testimonials?: Testimonial[];
}

/* ── Icons ─────────────────────────────────────────────────── */
function QuoteIcon() {
  return (
    <svg width="40" height="40" viewBox="0 0 40 40" fill="none" aria-hidden>
      <path
        d="M10 30V20C10 14 14 10 20 10M30 30V20C30 14 34 10 40 10"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        className="text-gold/30"
      />
    </svg>
  );
}

function ChevronLeft() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M15 18l-6-6 6-6" />
    </svg>
  );
}
function ChevronRight() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M9 18l6-6-6-6" />
    </svg>
  );
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultTestimonials: Testimonial[] = [
  {
    id: 't1',
    quote:
      'Édition understands that true luxury is personal. My stylist remembers every preference — the fit, the fabrics, even my aversion to certain shades of blue. It feels less like shopping and more like visiting an old friend who happens to have impeccable taste.',
    author: 'Priya Sharma',
    title: 'Architect',
    location: 'Mumbai',
  },
  {
    id: 't2',
    quote:
      'The craftsmanship is unmistakable. I\'ve worn their cashmere overcoat through three winters and it looks better today than the day I bought it. There\'s something profoundly reassuring about owning things made this well.',
    author: 'Arjun Mehta',
    title: 'Creative Director',
    location: 'Bangalore',
  },
  {
    id: 't3',
    quote:
      'I was skeptical about ordering bespoke remotely, but the virtual consultation was extraordinary. The suit arrived fitting better than anything I\'ve had made in person. The attention to detail in the communication alone was worth it.',
    author: 'Rohan Desai',
    title: 'Entrepreneur',
    location: 'Delhi',
  },
];

/* ── Section ───────────────────────────────────────────────── */
export function Testimonials({
  overline = 'The Word',
  title = 'What Our Clients Say',
  testimonials = defaultTestimonials,
}: TestimonialsProps) {
  const [active, setActive] = useState(0);

  const next = useCallback(() => {
    setActive((v) => (v + 1) % testimonials.length);
  }, [testimonials.length]);

  const prev = useCallback(() => {
    setActive((v) => (v - 1 + testimonials.length) % testimonials.length);
  }, [testimonials.length]);

  const current = testimonials[active];

  return (
    <section className="py-3xl lg:py-4xl">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
      >
        {/* ── Header ───────────────────────────────────────── */}
        <div className="text-center max-w-2xl mx-auto mb-2xl">
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">{overline}</Text>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Heading as="h2">{title}</Heading>
          </motion.div>
        </div>

        {/* ── Testimonial Card ─────────────────────────────── */}
        <motion.div
          variants={fadeIn}
          className="max-w-3xl mx-auto"
        >
          <div className="text-center p-2xl">
            {/* Quote icon */}
            <div className="mb-lg flex justify-center">
              <QuoteIcon />
            </div>

            {/* Quote text with AnimatePresence */}
            <div className="relative min-h-[180px]">
              <AnimatePresence mode="wait">
                <motion.blockquote
                  key={current.id}
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -16 }}
                  transition={transition.slow}
                  className="text-lg lg:text-xl leading-relaxed text-charcoal/80 italic font-light mb-lg"
                >
                  &ldquo;{current.quote}&rdquo;
                </motion.blockquote>
              </AnimatePresence>
            </div>

            {/* Author */}
            <AnimatePresence mode="wait">
              <motion.div
                key={`a-${current.id}`}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
              >
                <p className="font-heading text-lg font-semibold text-charcoal">
                  {current.author}
                </p>
                <Text variant="body-sm" className="text-charcoal/50">
                  {current.title} &middot; {current.location}
                </Text>
              </motion.div>
            </AnimatePresence>

            {/* Navigation dots + arrows */}
            <div className="flex items-center justify-center gap-lg mt-xl">
              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={prev}
                className="p-2 text-charcoal/40 hover:text-gold transition-colors"
                aria-label="Previous testimonial"
              >
                <ChevronLeft />
              </motion.button>

              <div className="flex items-center gap-2">
                {testimonials.map((t, i) => (
                  <button
                    key={t.id}
                    onClick={() => setActive(i)}
                    aria-label={`Testimonial ${i + 1}`}
                    className={`w-2 h-2 rounded-full transition-all duration-300 ${
                      i === active
                        ? 'bg-gold w-6'
                        : 'bg-charcoal/15 hover:bg-charcoal/30'
                    }`}
                  />
                ))}
              </div>

              <motion.button
                whileTap={{ scale: 0.9 }}
                onClick={next}
                className="p-2 text-charcoal/40 hover:text-gold transition-colors"
                aria-label="Next testimonial"
              >
                <ChevronRight />
              </motion.button>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
}
