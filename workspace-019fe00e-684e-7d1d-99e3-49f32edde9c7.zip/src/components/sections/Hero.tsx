import { useRef } from 'react';
import { motion } from 'framer-motion';
import { useScrollPosition } from '@/hooks/useScrollPosition';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';
import {
  fadeIn,
  staggerContainer,
  transition,
} from '@/utils/animation';

/* ── Hero ──────────────────────────────────────────────────────
   Full-bleed 100vh editorial hero.
   Breaks out of the parent container via negative margins.
   Reuses only existing primitives — no ad-hoc styles.
*/

export function Hero() {
  const { scrollY } = useScrollPosition();
  const containerRef = useRef<HTMLDivElement>(null);

  /* Soft parallax: product shifts upward as user scrolls */
  const parallaxY = scrollY * 0.12;

  return (
    <section
      ref={containerRef}
      aria-label="Hero"
      className="relative min-h-screen -mx-md flex items-center overflow-hidden max-w-[100vw]"
    >
      {/* ── Background ambient texture ──────────────────────── */}
      <div
        aria-hidden
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            'radial-gradient(ellipse 80% 60% at 70% 50%, rgba(184,156,93,0.08) 0%, transparent 60%), radial-gradient(ellipse 50% 50% at 20% 40%, rgba(31,31,31,0.03) 0%, transparent 70%)',
        }}
      />

      <div className="w-full max-w-7xl mx-auto px-md grid grid-cols-1 lg:grid-cols-2 gap-2xl lg:gap-3xl items-center">
        {/* ── Editorial Text ────────────────────────────────── */}
        <motion.div
          variants={staggerContainer}
          initial="hidden"
          animate="visible"
          className="order-2 lg:order-1 pt-sm lg:pt-0 pb-2xl lg:pb-0"
        >
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">
              Spring / Summer 2026
            </Text>
          </motion.div>

          <motion.div variants={fadeIn}>
            <Heading as="h1" className="text-balance mb-md lg:mb-lg">
              The Art of<br />
              Quiet Luxury
            </Heading>
          </motion.div>

          <motion.div variants={fadeIn} className="max-w-md">
            <Text variant="body-lg" className="text-charcoal/70 mb-lg lg:mb-xl">
              A study in restraint. Each piece is an exploration of form,
              texture, and silence — crafted for those who understand that true
              elegance speaks in whispers.
            </Text>
          </motion.div>

          <motion.div variants={fadeIn} className="flex items-center gap-md">
            <ButtonLink to="/collections" variant="primary" size="lg">
              Explore the Collection
            </ButtonLink>
            <ButtonLink to="/collections" variant="outline" size="lg">
              Read the Journal
            </ButtonLink>
          </motion.div>
        </motion.div>

        {/* ── Product Showcase ───────────────────────────────── */}
        <motion.div
          variants={fadeIn}
          initial="hidden"
          animate="visible"
          className="order-1 lg:order-2 relative flex items-center justify-center"
          style={{ y: -parallaxY }}
        >
          {/* Floating wrapper */}
          <motion.div
            animate={{ y: [0, -12, 0] }}
            transition={{
              duration: 6,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
            className="relative w-full max-w-lg lg:max-w-none aspect-[3/4] lg:aspect-[4/5]"
          >
            {/* Product placeholder — abstract luxury form */}
            <div className="absolute inset-4 lg:inset-6 rounded-lg bg-gradient-to-br from-charcoal/5 via-ivory to-gold/20 shadow-elevated overflow-hidden">
              {/* Inner decorative geometry */}
              <div
                aria-hidden
                className="absolute inset-0"
                style={{
                  background:
                    'linear-gradient(135deg, rgba(184,156,93,0.15) 0%, transparent 40%, rgba(31,31,31,0.06) 100%)',
                }}
              />
              {/* Product silhouette */}
              <div className="absolute inset-8 lg:inset-12 flex items-center justify-center">
                <div className="w-2/3 h-full max-h-[70%] bg-gradient-to-b from-charcoal/8 via-charcoal/4 to-charcoal/12 rounded-t-full rounded-b-lg" />
              </div>
              {/* Subtle accent line */}
              <div className="absolute bottom-12 left-1/2 -translate-x-1/2 w-16 h-px bg-gold/40" />
            </div>

            {/* Decorative ring */}
            <div
              aria-hidden
              className="absolute -inset-2 lg:-inset-4 rounded-full border border-gold/10"
            />
            <div
              aria-hidden
              className="absolute -inset-6 lg:-inset-8 rounded-full border border-gold/5"
            />
          </motion.div>
        </motion.div>
      </div>

      {/* ── Scroll Indicator ─────────────────────────────────── */}
      <motion.div
        variants={fadeIn}
        initial="hidden"
        animate="visible"
        transition={{ ...transition.reveal, delay: 1.2 }}
        className="absolute bottom-lg left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
      >
        <span className="text-[10px] tracking-[0.25em] uppercase text-charcoal/30">
          Scroll
        </span>
        <motion.div
          animate={{ y: [0, 6, 0] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          className="text-charcoal/25"
        >
          <svg
            width="16"
            height="24"
            viewBox="0 0 16 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
          >
            <rect x="1" y="1" width="14" height="22" rx="7" />
            <motion.line
              x1="8"
              y1="6"
              x2="8"
              y2="10"
              animate={{ opacity: [0.4, 1, 0.4] }}
              transition={{ duration: 1.5, repeat: Infinity }}
            />
          </svg>
        </motion.div>
      </motion.div>
    </section>
  );
}
