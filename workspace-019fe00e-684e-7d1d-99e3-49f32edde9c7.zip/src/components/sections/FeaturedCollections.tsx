import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';
import {
  fadeIn,
  staggerContainer,
  transition,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
export interface CollectionData {
  id: string;
  name: string;
  description: string;
  productCount: number;
  href: string;
}

interface FeaturedCollectionsProps {
  overline?: string;
  title?: string;
  subtitle?: string;
  collections?: CollectionData[];
  ctaLabel?: string;
  ctaHref?: string;
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultCollections: CollectionData[] = [
  {
    id: '1',
    name: 'Spring Summer 2026',
    description: 'Lightweight tailoring and fluid silhouettes for the warmer months.',
    productCount: 48,
    href: '/collections/ss26',
  },
  {
    id: '2',
    name: 'The Leather Atelier',
    description: 'Hand-stitched bags, wallets, and accessories from our Florentine workshop.',
    productCount: 32,
    href: '/collections/leather',
  },
  {
    id: '3',
    name: 'Evening & Occasion',
    description: 'Gowns, dinner jackets, and refined separates for the most memorable nights.',
    productCount: 26,
    href: '/collections/evening',
  },
];

/* ── Section ───────────────────────────────────────────────── */
export function FeaturedCollections({
  overline = 'Curated',
  title = 'Featured Collections',
  subtitle = 'Discover our most celebrated ensembles, each telling its own story of craftsmanship and vision.',
  collections = defaultCollections,
  ctaLabel = 'View All Collections',
  ctaHref = '/collections',
}: FeaturedCollectionsProps) {
  return (
    <section className="py-3xl lg:py-4xl">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
      >
        {/* ── Header ───────────────────────────────────────── */}
        <div className="text-center max-w-2xl mx-auto mb-2xl">
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">{overline}</Text>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Heading as="h2" className="mb-md">{title}</Heading>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Text variant="body-lg" className="text-charcoal/60">{subtitle}</Text>
          </motion.div>
        </div>

        {/* ── Cards ────────────────────────────────────────── */}
        <motion.div
          variants={fadeIn}
          className="grid grid-cols-1 md:grid-cols-3 gap-xl mb-2xl"
        >
          {collections.map((col) => (
            <motion.div
              key={col.id}
              whileHover={{ y: -4 }}
              transition={transition.normal}
              className="group cursor-pointer"
            >
              {/* Placeholder visual */}
              <div className="aspect-[4/3] rounded-lg bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 overflow-hidden mb-md relative shadow-subtle">
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-2/3 h-4/5 bg-gradient-to-b from-charcoal/6 via-charcoal/3 to-charcoal/8 rounded-lg" />
                </div>
                <div className="absolute bottom-6 left-6 flex items-center gap-2">
                  <div className="w-8 h-px bg-gold/50 group-hover:w-12 transition-all duration-500" />
                  <Text variant="caption" as="span">{col.productCount} pieces</Text>
                </div>
              </div>
              <Heading as="h4" className="mb-1 group-hover:text-gold transition-colors">
                {col.name}
              </Heading>
              <Text variant="body-sm" className="text-charcoal/60">
                {col.description}
              </Text>
            </motion.div>
          ))}
        </motion.div>

        {/* ── CTA ──────────────────────────────────────────── */}
        <motion.div variants={fadeIn} className="text-center">
          <ButtonLink to={ctaHref} variant="outline" size="lg">
            {ctaLabel}
          </ButtonLink>
        </motion.div>
      </motion.div>
    </section>
  );
}
