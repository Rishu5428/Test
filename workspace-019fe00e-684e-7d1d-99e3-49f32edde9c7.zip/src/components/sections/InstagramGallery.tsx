import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';
import {
  fadeIn,
  staggerContainer,
  staggerImmediate,
  transition,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
export interface GalleryImage {
  id: string;
  alt: string;
}

interface InstagramGalleryProps {
  overline?: string;
  title?: string;
  subtitle?: string;
  images?: GalleryImage[];
  ctaLabel?: string;
  ctaHref?: string;
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultImages: GalleryImage[] = [
  { id: 'ig1', alt: 'Editorial shot — morning light through linen curtains' },
  { id: 'ig2', alt: 'Close-up of hand-stitched leather detail' },
  { id: 'ig3', alt: 'Artisan at work in the Milan atelier' },
  { id: 'ig4', alt: 'Spring collection — outdoor editorial' },
  { id: 'ig5', alt: 'Silk scarf detail with gold accent' },
  { id: 'ig6', alt: 'Florentine workshop tools and materials' },
];

/* ── Placeholder gradient generator ────────────────────────── */
const gradients = [
  'from-charcoal/6 via-ivory to-gold/12',
  'from-gold/10 via-ivory to-charcoal/5',
  'from-charcoal/8 via-gold/5 to-ivory',
  'from-ivory via-gold/10 to-charcoal/6',
  'from-gold/8 via-ivory to-charcoal/7',
  'from-charcoal/5 via-gold/5 to-ivory',
];

const shapes = ['rounded-t-full rounded-b-lg', 'rounded-lg', 'rounded-full', 'rounded-b-full rounded-t-lg', 'rounded-lg', 'rounded-t-full rounded-b-lg'];

/* ── Section ───────────────────────────────────────────────── */
export function InstagramGallery({
  overline = 'Follow Along',
  title = 'On Instagram',
  subtitle = 'Behind the scenes, atelier moments, and stories from the world of Édition.',
  images = defaultImages,
  ctaLabel = 'Follow @edition',
  ctaHref = '#',
}: InstagramGalleryProps) {
  return (
    <section className="py-3xl lg:py-4xl">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
      >
        {/* ── Header ───────────────────────────────────────── */}
        <div className="text-center max-w-2xl mx-auto mb-2xl">
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">{overline}</Text>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Heading as="h2" className="mb-md">{title}</Heading>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Text variant="body-lg" className="text-charcoal/60">{subtitle}</Text>
          </motion.div>
        </div>

        {/* ── Gallery Grid ─────────────────────────────────── */}
        <motion.div
          variants={staggerImmediate}
          className="grid grid-cols-2 md:grid-cols-3 gap-2xs md:gap-2xs mb-2xl"
        >
          {images.map((img, i) => (
            <motion.div
              key={img.id}
              variants={fadeIn}
              whileHover={{ scale: 1.02 }}
              transition={transition.normal}
              className="aspect-square overflow-hidden rounded-md cursor-pointer relative shadow-subtle"
            >
              {/* Abstract placeholder */}
              <div
                className={`absolute inset-0 bg-gradient-to-br ${gradients[i % gradients.length]}`}
              />
              {/* Decorative shape */}
              <div className="absolute inset-6 flex items-center justify-center">
                <div
                  className={`w-2/5 h-3/5 bg-gradient-to-b from-charcoal/10 via-charcoal/5 to-charcoal/8 ${shapes[i % shapes.length]}`}
                />
              </div>
              {/* Gold accent dot */}
              <div className="absolute bottom-4 right-4 w-3 h-3 rounded-full bg-gold/40" />

              {/* Hover overlay */}
              <div className="absolute inset-0 bg-charcoal/0 hover:bg-charcoal/5 transition-colors duration-500 flex items-center justify-center">
                <span className="opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="1.5" strokeLinecap="round">
                    <path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zM12 16v-4M12 8v-.5" />
                  </svg>
                </span>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* ── CTA ──────────────────────────────────────────── */}
        <motion.div variants={fadeIn} className="text-center">
          <ButtonLink to={ctaHref} variant="outline" size="lg">
            {ctaLabel}
          </ButtonLink>
        </motion.div>
      </motion.div>
    </section>
  );
}
