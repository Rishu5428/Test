import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import {
  fadeIn,
  staggerContainer,
  transition,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
export interface CraftFeature {
  id: string;
  icon: React.ReactNode;
  title: string;
  description: string;
}

interface CraftsmanshipProps {
  overline?: string;
  title?: string;
  subtitle?: string;
  features?: CraftFeature[];
  imageAlt?: string;
}

/* ── Icons ─────────────────────────────────────────────────── */
function StitchIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M4 4l20 20M4 24l5-5M14 4l-4 4M8 18l4 4M24 4l-8 8M20 24L6 10" />
    </svg>
  );
}
function HandIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M12 8V5a3 3 0 0 0-3-3H5a3 3 0 0 0-3 3v12a8 8 0 0 0 8 8h4a8 8 0 0 0 8-8v-3M20 2a3 3 0 0 0-3 3v9M14 10V9a3 3 0 0 0-3-3M17 6V5a3 3 0 0 0-3-3" />
    </svg>
  );
}
function MaterialIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <rect x="2" y="2" width="10" height="10" rx="2" />
      <rect x="16" y="2" width="10" height="10" rx="2" />
      <rect x="2" y="16" width="10" height="10" rx="2" />
      <rect x="16" y="16" width="10" height="10" rx="2" />
    </svg>
  );
}
function AtelierIcon() {
  return (
    <svg width="28" height="28" viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <circle cx="14" cy="14" r="10" />
      <path d="M14 4v20M4 14h20" />
      <circle cx="14" cy="14" r="4" />
    </svg>
  );
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultFeatures: CraftFeature[] = [
  {
    id: 'c1',
    icon: <StitchIcon />,
    title: 'Hand-Finished',
    description:
      'Every seam is inspected, pressed, and finished by hand. Our tailors spend an average of 12 hours on a single jacket.',
  },
  {
    id: 'c2',
    icon: <HandIcon />,
    title: 'Artisan Partners',
    description:
      'We collaborate with family-owned ateliers across Italy, France, and Japan — some with over 200 years of heritage.',
  },
  {
    id: 'c3',
    icon: <MaterialIcon />,
    title: 'Exceptional Materials',
    description:
      'From Loro Piana cashmere to Japanese selvedge denim. We source only from mills that meet our exacting standards.',
  },
  {
    id: 'c4',
    icon: <AtelierIcon />,
    title: 'Made to Last',
    description:
      'Every piece is designed with longevity in mind. We offer complimentary repairs for the lifetime of the garment.',
  },
];

/* ── Section ───────────────────────────────────────────────── */
export function Craftsmanship({
  overline = 'Our Philosophy',
  title = 'Craftsmanship Without Compromise',
  subtitle = 'Behind every piece lies a story of dedication — from the hands that weave the fabric to the artisans who bring it to life.',
  features = defaultFeatures,
}: CraftsmanshipProps) {
  return (
    <section className="py-3xl lg:py-4xl">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
      >
        {/* ── Header ───────────────────────────────────────── */}
        <div className="text-center max-w-2xl mx-auto mb-2xl">
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">{overline}</Text>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Heading as="h2" className="mb-md">{title}</Heading>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Text variant="body-lg" className="text-charcoal/60">{subtitle}</Text>
          </motion.div>
        </div>

        {/* ── Two-Column Layout ────────────────────────────── */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-3xl items-center">
          {/* Visual placeholder */}
          <motion.div variants={fadeIn} className="max-w-md mx-auto lg:max-w-none">
            <div className="aspect-[4/5] rounded-lg bg-gradient-to-br from-charcoal/5 via-ivory to-gold/10 shadow-subtle overflow-hidden relative">
              <div className="absolute inset-10 flex items-center justify-center">
                <div className="relative w-full h-full max-w-xs max-h-80">
                  {/* Abstract workshop scene */}
                  <div className="absolute bottom-0 inset-x-0 h-1/2 bg-charcoal/4 rounded-lg" />
                  <div className="absolute bottom-1/4 left-1/4 w-1/2 h-3/5 bg-gradient-to-t from-charcoal/6 to-charcoal/2 rounded-t-full" />
                  <div className="absolute top-1/4 left-1/3 w-1/3 h-px bg-gold/30" />
                </div>
              </div>
              {/* Overlay accent */}
              <div className="absolute top-6 left-6 w-12 h-12 rounded-full border border-gold/15" />
            </div>
          </motion.div>

          {/* Features grid */}
          <motion.div variants={fadeIn} className="grid grid-cols-1 sm:grid-cols-2 gap-lg">
            {features.map((feat) => (
              <motion.div
                key={feat.id}
                whileHover={{ y: -2 }}
                transition={transition.normal}
                className="p-lg rounded-lg border border-charcoal/5 hover:border-gold/20 transition-colors"
              >
                <div className="text-gold mb-sm">{feat.icon}</div>
                <Heading as="h6" className="mb-1">{feat.title}</Heading>
                <Text variant="body-sm" className="text-charcoal/60 leading-relaxed">
                  {feat.description}
                </Text>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
}
