import { motion } from 'framer-motion';
import { Heading, Text } from '@/components/ui/Typography';
import { ButtonLink } from '@/components/ui/Button';
import { ProductCard, type ProductData } from '@/components/ui/ProductCard';
import {
  fadeIn,
  staggerContainer,
  staggerImmediate,
} from '@/utils/animation';

/* ── Types ─────────────────────────────────────────────────── */
interface BestSellersProps {
  overline?: string;
  title?: string;
  subtitle?: string;
  products?: ProductData[];
  ctaLabel?: string;
  ctaHref?: string;
}

/* ── Defaults ──────────────────────────────────────────────── */
const defaultProducts: ProductData[] = [
  { id: 'bs1', name: 'Cashmere Overcoat', category: 'Outerwear', price: '₹ 98,000', href: '/products/cashmere-overcoat' },
  { id: 'bs2', name: 'Silk Evening Gown', category: 'Evening', price: '₹ 1,45,000', href: '/products/silk-evening-gown' },
  { id: 'bs3', name: 'Hand-Stitched Loafers', category: 'Footwear', price: '₹ 42,000', href: '/products/loafers' },
  { id: 'bs4', name: 'Linen Blazer', category: 'Tailoring', price: '₹ 76,000', href: '/products/linen-blazer' },
];

/* ── Section ───────────────────────────────────────────────── */
export function BestSellers({
  overline = 'Most Loved',
  title = 'Best Sellers',
  subtitle = 'The pieces our clients return to season after season — timeless essentials crafted to last.',
  products = defaultProducts,
  ctaLabel = 'Shop All Best Sellers',
  ctaHref = '/collections/bestsellers',
}: BestSellersProps) {
  return (
    <section className="py-3xl lg:py-4xl bg-charcoal/3 -mx-md px-md">
      <motion.div
        variants={staggerContainer}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, margin: '-80px' }}
      >
        {/* ── Header ───────────────────────────────────────── */}
        <div className="text-center max-w-2xl mx-auto mb-2xl">
          <motion.div variants={fadeIn}>
            <Text variant="overline" className="mb-sm">{overline}</Text>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Heading as="h2" className="mb-md">{title}</Heading>
          </motion.div>
          <motion.div variants={fadeIn}>
            <Text variant="body-lg" className="text-charcoal/60">{subtitle}</Text>
          </motion.div>
        </div>

        {/* ── Product Grid ─────────────────────────────────── */}
        <motion.div
          variants={staggerImmediate}
          className="grid grid-cols-2 md:grid-cols-4 gap-lg mb-2xl"
        >
          {products.map((product) => (
            <motion.div key={product.id} variants={fadeIn}>
              <ProductCard product={product} />
            </motion.div>
          ))}
        </motion.div>

        {/* ── CTA ──────────────────────────────────────────── */}
        <motion.div variants={fadeIn} className="text-center">
          <ButtonLink to={ctaHref} variant="secondary" size="lg">
            {ctaLabel}
          </ButtonLink>
        </motion.div>
      </motion.div>
    </section>
  );
}
