/* ── Animation Utilities ───────────────────────────────────────
   Framer Motion variants and transitions for editorial luxury.
   Use these exclusively – never define ad-hoc animations.

   Usage:
     import { fadeIn, stagger, easing } from '@/utils/animation';
     <motion.div variants={fadeIn} ... />
*/

import type { Variants, Transition } from 'framer-motion';

/* ── Easing Presets ────────────────────────────────────────── */
export const easing = {
  /** Smooth exit – use for elements fading out */
  outExpo: [0.19, 1, 0.22, 1] as const,
  /** Elegant in/out – use for modals, page transitions */
  inOutExpo: [0.87, 0, 0.13, 1] as const,
  /** Snappy – use for micro-interactions */
  outBack: [0.34, 1.56, 0.64, 1] as const,
} as const;

/* ── Transition Presets ────────────────────────────────────── */
export const transition = {
  fast: { duration: 0.15, ease: easing.outExpo } satisfies Transition,
  normal: { duration: 0.3, ease: easing.outExpo } satisfies Transition,
  slow: { duration: 0.5, ease: easing.outExpo } satisfies Transition,
  reveal: { duration: 0.8, ease: easing.outExpo } satisfies Transition,
  /** Light spring — gestures, tap feedback, micro-interactions */
  spring: { type: 'spring' as const, stiffness: 400, damping: 30 } satisfies Transition,
};

/* ── Variant Presets ───────────────────────────────────────── */

/** Fades in + slides up slightly. The most common editorial entrance. */
export const fadeIn: Variants = {
  hidden: {
    opacity: 0,
    y: 24,
  },
  visible: {
    opacity: 1,
    y: 0,
    transition: transition.reveal,
  },
};

/** Fades in with no movement. Suitable for overlays and subtle reveals. */
export const fadeInStatic: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: transition.normal,
  },
};

/** Staggers children with fadeIn. Use on container elements. */
export const staggerContainer: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.1,
    },
  },
};

/** Stagger children with no delay between them. */
export const staggerImmediate: Variants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.06,
      delayChildren: 0,
    },
  },
};

/** Slides in from the left – editorial pull-quote entrance. */
export const slideInLeft: Variants = {
  hidden: { opacity: 0, x: -40 },
  visible: {
    opacity: 1,
    x: 0,
    transition: transition.slow,
  },
};

/** Slides in from the right. */
export const slideInRight: Variants = {
  hidden: { opacity: 0, x: 40 },
  visible: {
    opacity: 1,
    x: 0,
    transition: transition.slow,
  },
};

/** Subtle scale-up for card reveals. */
export const scaleIn: Variants = {
  hidden: { opacity: 0, scale: 0.96 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: transition.slow,
  },
};
