import type { ProductData } from '@/components/ui/ProductCard';

/* ── Product Generator ────────────────────────────────────────
   Generates placeholder product data for the collections grid.
   Used by CollectionsPage for both initial load and infinite scroll.
*/

const categories = [
  'Outerwear', 'Tailoring', 'Evening', 'Knitwear',
  'Footwear', 'Accessories', 'Leather Goods', 'Loungewear',
];

const materials = [
  'Cashmere', 'Linen', 'Silk', 'Wool',
  'Cotton', 'Leather', 'Suede', 'Linen-Cotton',
] as const;

const names = [
  'The Milan Coat', 'Palazzo Trousers', 'Silk Camisole', 'Cashmere Rollneck',
  'Linen Blazer', 'Evening Gown', 'Hand-Stitched Loafers', 'Leather Tote',
  'Wool Overcoat', 'Satin Shirt', 'Pleated Skirt', 'Cashmere Scarf',
  'Tailored Shorts', 'Silk Dress', 'Suede Sneakers', 'Canvas Weekender',
  'Double-Breasted Jacket', 'Merino Cardigan', 'Wide-Leg Trouser', 'Leather Belt',
  'Crocodile Clutch', 'Linen Shirt', 'Structured Blazer', 'Silk Pajama Set',
  'Cashmere Throw', 'Wool Trousers', 'Satin Slip Dress', 'Leather Gloves',
  'Camel Coat', 'Tuxedo Jacket', 'Organza Blouse', 'Suede Loafers',
];

const prices = [
  '₹ 42,000', '₹ 58,000', '₹ 76,000', '₹ 95,000',
  '₹ 1,10,000', '₹ 1,35,000', '₹ 1,65,000', '₹ 2,10,000',
  '₹ 28,000', '₹ 34,000', '₹ 52,000', '₹ 88,000',
];

const ratings = [4.0, 4.5, 4.5, 5.0, 4.5, 4.0, 4.5, 5.0, 4.0, 4.5];

export function generateProduct(index: number): ProductData {
  return {
    id: `prod-${index}`,
    name: names[index % names.length],
    category: categories[index % categories.length],
    price: prices[index % prices.length],
    href: `/products/prod-${index}`,
    rating: ratings[index % ratings.length],
  };
}

export function generateProducts(
  start: number,
  count: number,
): ProductData[] {
  return Array.from({ length: count }, (_, i) => generateProduct(start + i));
}

/* ── Filter Options ─────────────────────────────────────────── */
export const filterOptions = {
  category: categories,
  material: materials as unknown as string[],
  sort: [
    { label: 'Featured', value: 'featured' },
    { label: 'Newest', value: 'newest' },
    { label: 'Price: Low to High', value: 'price-asc' },
    { label: 'Price: High to Low', value: 'price-desc' },
    { label: 'Best Rated', value: 'rating' },
  ],
  priceRanges: [
    { label: 'Under ₹ 50,000', value: 'under-50k', min: 0, max: 50000 },
    { label: '₹ 50,000 – ₹ 1,00,000', value: '50k-100k', min: 50000, max: 100000 },
    { label: '₹ 1,00,000 – ₹ 2,00,000', value: '100k-200k', min: 100000, max: 200000 },
    { label: 'Over ₹ 2,00,000', value: 'over-200k', min: 200000, max: Infinity },
  ],
};
