/* ── Color Tokens ──────────────────────────────────────────────
   Single source of truth for the editorial palette.

   Usage:
     import { colors } from '@/utils/colors';
     <div style={{ background: colors.ivory }} />
*/

export const colors = {
  ivory: '#FAF8F5',
  charcoal: '#1F1F1F',
  gold: '#B89C5D',
  walnut: '#5C3A21',
  pureWhite: '#FFFFFF',
} as const;

export const semanticColors = {
  surface: {
    primary: colors.ivory,
    inverse: colors.charcoal,
  },
  text: {
    primary: colors.charcoal,
    inverse: colors.ivory,
    muted: '#6B6B6B',
  },
  accent: {
    primary: colors.gold,
    deep: colors.walnut,
    hover: '#A88B4D',
  },
  border: {
    subtle: 'rgba(31, 31, 31, 0.1)',
    medium: 'rgba(31, 31, 31, 0.2)',
  },
} as const;

export type ColorKey = keyof typeof colors;
export type SemanticColorGroup = keyof typeof semanticColors;
