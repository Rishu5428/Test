/* ── Spacing Scale ─────────────────────────────────────────────
   Editorial rhythm based on a 4px/0.25rem base unit.
   All values in rem for consistent relative sizing.

   Usage:
     import { spacing } from '@/utils/spacing';
     <div style={{ padding: spacing.md }} />
*/

export const spacing = {
  '4xs': '0.125rem', //   2px
  '3xs': '0.25rem',  //   4px
  '2xs': '0.5rem',   //   8px
  xs: '0.75rem',     //  12px
  sm: '1rem',        //  16px
  md: '1.5rem',      //  24px
  lg: '2rem',        //  32px
  xl: '3rem',        //  48px
  '2xl': '4rem',     //  64px
  '3xl': '6rem',     //  96px
  '4xl': '8rem',     // 128px
} as const;

export const spacingPx = {
  '4xs': 2,
  '3xs': 4,
  '2xs': 8,
  xs: 12,
  sm: 16,
  md: 24,
  lg: 32,
  xl: 48,
  '2xl': 64,
  '3xl': 96,
  '4xl': 128,
} as const;

export type SpacingKey = keyof typeof spacing;
