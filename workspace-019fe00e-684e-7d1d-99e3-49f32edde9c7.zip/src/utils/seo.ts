/* ── Structured Data (JSON-LD) ────────────────────────────────
   Generates ld+json script blocks for SEO.
   Usage: <script type="application/ld+json">{orgSchema()}</script>
*/

/* Organization */
export function organizationSchema() {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: 'Édition',
    url: 'https://edition.com',
    logo: 'https://edition.com/favicon.svg',
    description:
      'Luxury fashion house — meticulously crafted garments and accessories for the discerning.',
    sameAs: [
      'https://instagram.com/edition',
      'https://pinterest.com/edition',
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      telephone: '+91-0000000000',
      contactType: 'customer service',
      areaServed: 'IN',
      availableLanguage: ['en', 'hi'],
    },
  });
}

/* Product */
export function productSchema(product: {
  name: string;
  description: string;
  image: string;
  sku: string;
  price: number;
  currency: string;
  url: string;
}) {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'Product',
    name: product.name,
    description: product.description,
    image: product.image,
    sku: product.sku,
    offers: {
      '@type': 'Offer',
      url: product.url,
      priceCurrency: product.currency,
      price: product.price,
      availability: 'https://schema.org/InStock',
    },
  });
}

/* Breadcrumb */
export function breadcrumbSchema(items: { name: string; url: string }[]) {
  return JSON.stringify({
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, i) => ({
      '@type': 'ListItem',
      position: i + 1,
      name: item.name,
      item: item.url,
    })),
  });
}
