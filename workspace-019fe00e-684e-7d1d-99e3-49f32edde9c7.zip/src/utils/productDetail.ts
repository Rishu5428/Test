import type { ProductData } from '@/components/ui/ProductCard';

/* ── Full Product Detail ──────────────────────────────────────
   Extends ProductData with everything needed for the PDP.
*/

export interface Variant {
  id: string;
  label: string;
  value: string;
}

export interface ProductDetail extends ProductData {
  description: string;
  gallery: string[];       // placeholder IDs — we render abstract art for each
  variants: Variant[][];   // e.g. [[size options], [color options]]
  care: string[];
  shipping: string;
  returns: string;
  materialDetails: string;
  fit: string;
  sku: string;
}

/* ── Product Detail Generator ──────────────────────────────── */

const descriptions = [
  'Meticulously crafted over a period of eight weeks by our master artisans in Milan. Every seam, every stitch, every detail has been considered — from the hand-set horn buttons to the cupro lining sourced from a family-run mill in Como.',
  'A contemporary interpretation of a classic silhouette. Cut from double-faced Italian wool with a relaxed, slightly oversized fit. The raw edges are finished by hand using a technique passed down through three generations of our Neapolitan tailoring partners.',
  'Light as air, yet impeccably structured. This piece is constructed from Japanese technical silk that took our mill partners two years to develop — it breathes like linen, drapes like crepe, and resists wrinkles for up to 18 hours of wear.',
  'An exercise in restraint. The silhouette is deliberately minimal — no visible hardware, no logos, no unnecessary embellishments. What remains is pure form: an impeccably cut garment that lets the quality of the materials speak for itself.',
];

const careInstructions = [
  'Dry clean only by a specialist leather cleaner',
  'Store on a padded hanger in a breathable garment bag',
  'Avoid prolonged exposure to direct sunlight',
  'Iron on low heat with a pressing cloth — never directly on the fabric',
  'Steam to refresh between wears',
  'Brush regularly with a soft-bristle garment brush',
];

const shippingText =
  'Complimentary express shipping worldwide. Delivery within 3–5 business days for all major cities. Each order is packaged in our signature gift box with a hand-written note. Track your order at any time through your account.';

const returnsText =
  'Complimentary returns and exchanges within 30 days of delivery. Items must be unworn with all tags attached. We offer a home pickup service — our courier will collect from your preferred address at your convenience. Refunds are processed within 3 business days.';

const sizeVariants: Variant[] = [
  { id: 'xs', label: 'XS', value: 'Extra Small' },
  { id: 's', label: 'S', value: 'Small' },
  { id: 'm', label: 'M', value: 'Medium' },
  { id: 'l', label: 'L', value: 'Large' },
  { id: 'xl', label: 'XL', value: 'Extra Large' },
];

const colorVariants: Variant[] = [
  { id: 'black', label: 'Noir', value: 'Black' },
  { id: 'ivory', label: 'Ivory', value: 'Ivory' },
  { id: 'navy', label: 'Marine', value: 'Navy' },
  { id: 'taupe', label: 'Taupe', value: 'Taupe' },
];

const materialDetails = [
  '100% Loro Piana virgin wool, milled in Biella, Italy',
  'Cupro lining — Bemberg™, sourced from Asahi Kasei, Japan',
  'Genuine horn buttons — hand-polished in the Cotswolds, UK',
  '60% silk, 40% linen blend — exclusively developed for Édition',
];

const fits = [
  'Regular fit — true to size. Model wears size M (height: 188cm / 6\'2", chest: 97cm).',
  'Relaxed, slightly oversized fit. Model wears size S (height: 178cm / 5\'10").',
  'Slim fit through the shoulders and chest. We recommend sizing up if between sizes.',
];

export function generateProductDetail(id: string): ProductDetail {
  const idx = parseInt(id.replace(/\D/g, ''), 10) || 0;
  const base = generateProduct(idx); // from utils/products

  return {
    ...base,
    description: descriptions[idx % descriptions.length],
    gallery: Array.from({ length: 5 }, (_, i) => `gallery-${id}-${i}`),
    variants: [sizeVariants, colorVariants],
    care: careInstructions,
    shipping: shippingText,
    returns: returnsText,
    materialDetails: materialDetails[idx % materialDetails.length],
    fit: fits[idx % fits.length],
    sku: `EDT-${String(idx + 1).padStart(4, '0')}-S26`,
  };
}

/* Reuse from products util */
import { generateProduct } from '@/utils/products';
