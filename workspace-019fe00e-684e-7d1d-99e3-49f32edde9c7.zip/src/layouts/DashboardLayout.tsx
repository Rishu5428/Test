import { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Sidebar } from '@/components/dashboard/Sidebar';
import { Topbar } from '@/components/dashboard/Topbar';

/* ── DashboardLayout ──────────────────────────────────────────
   Admin shell — sidebar on left, topbar + content on right.
   No storefront nav/footer. Sidebar collapses to icon-only.
*/

const SIDEBAR_WIDTH = 256;
const SIDEBAR_COLLAPSED = 72;

export function DashboardLayout() {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-ivory text-charcoal font-body antialiased flex overflow-x-hidden">
      {/* ── Sidebar ────────────────────────────────────────── */}
      <Sidebar collapsed={collapsed} onToggle={() => setCollapsed((v) => !v)} />

      {/* ── Main Area ──────────────────────────────────────── */}
      <motion.div
        animate={{ marginLeft: collapsed ? SIDEBAR_COLLAPSED : SIDEBAR_WIDTH }}
        transition={{ duration: 0.25, ease: [0.19, 1, 0.22, 1] }}
        className="flex-1 flex flex-col min-w-0"
      >
        <Topbar />

        {/* Content */}
        <main className="flex-1 p-xl lg:p-2xl">
          <Outlet />
        </main>
      </motion.div>
    </div>
  );
}
