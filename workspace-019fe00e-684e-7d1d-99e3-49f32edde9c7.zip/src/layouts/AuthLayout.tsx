import { Outlet } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { fadeIn } from '@/utils/animation';

/* ── AuthLayout ───────────────────────────────────────────────
   Minimal layout for login / signup / reset-password pages.
   No nav, no footer — just the auth form centered on screen.
*/

export function AuthLayout() {
  return (
    <div className="min-h-screen bg-ivory flex flex-col">
      {/* Decorative top rule */}
      <div className="h-[3px] bg-gradient-to-r from-charcoal via-gold to-charcoal" />

      <div className="flex-1 flex items-center justify-center px-md py-3xl">
        <motion.div
          variants={fadeIn}
          initial="hidden"
          animate="visible"
          className="w-full max-w-md"
        >
          {/* Logo */}
          <Link to="/" className="flex justify-center mb-2xl">
            <span className="font-heading text-2xl tracking-tight font-bold text-charcoal">
              ÉDITION
            </span>
          </Link>

          <div className="bg-ivory rounded-lg border border-charcoal/10 shadow-subtle p-2xl">
            <Outlet />
          </div>

          <p className="text-center text-xs text-charcoal/25 mt-lg">
            Secure access &middot; Supabase Auth
          </p>
        </motion.div>
      </div>
    </div>
  );
}
