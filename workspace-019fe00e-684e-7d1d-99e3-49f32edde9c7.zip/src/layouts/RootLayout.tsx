import { Outlet } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet-async';
import { fadeIn } from '@/utils/animation';
import { Navbar } from '@/components/navigation/Navbar';
import { Footer } from '@/components/navigation/Footer';
import { SearchOverlay } from '@/components/search/SearchOverlay';
import { CartDrawer } from '@/components/cart/CartDrawer';
import { organizationSchema } from '@/utils/seo';

export function RootLayout() {
  const location = useLocation();

  return (
    <div className="min-h-screen bg-ivory text-charcoal font-body antialiased transition-colors duration-300 overflow-x-hidden">
      {/* Structured Data */}
      <Helmet>
        <script type="application/ld+json">{organizationSchema()}</script>
      </Helmet>

      <SearchOverlay />
      <CartDrawer />
      <Navbar />

      {/* Main content */}
      <main id="main-content" className="max-w-7xl mx-auto px-md" role="main" aria-label="Main content">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            variants={fadeIn}
            initial="hidden"
            animate="visible"
            exit="hidden"
          >
            <Outlet />
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
}
