import fs from 'fs';
import path from 'path';

/* Sitemap Generator — run after build: node scripts/generate-sitemap.mjs */

const BASE_URL = 'https://edition.com';

const STATIC_ROUTES = [
  { path: '/', priority: '1.0', changefreq: 'weekly' },
  { path: '/collections', priority: '0.9', changefreq: 'daily' },
  { path: '/wishlist', priority: '0.3', changefreq: 'weekly' },
];

const PRODUCT_IDS = Array.from({ length: 64 }, (_, i) => `prod-${i}`);

function generateSitemap() {
  const today = new Date().toISOString().split('T')[0];

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

  for (const route of STATIC_ROUTES) {
    xml += '  <url>\n';
    xml += `    <loc>${BASE_URL}${route.path}</loc>\n`;
    xml += `    <lastmod>${today}</lastmod>\n`;
    xml += `    <changefreq>${route.changefreq}</changefreq>\n`;
    xml += `    <priority>${route.priority}</priority>\n`;
    xml += '  </url>\n';
  }

  for (const id of PRODUCT_IDS) {
    xml += '  <url>\n';
    xml += `    <loc>${BASE_URL}/products/${id}</loc>\n`;
    xml += `    <lastmod>${today}</lastmod>\n`;
    xml += '    <changefreq>weekly</changefreq>\n';
    xml += '    <priority>0.7</priority>\n';
    xml += '  </url>\n';
  }

  xml += '</urlset>\n';
  return xml;
}

const distDir = path.resolve(process.cwd(), 'dist');
const sitemap = generateSitemap();
fs.mkdirSync(distDir, { recursive: true });
fs.writeFileSync(path.join(distDir, 'sitemap.xml'), sitemap);
fs.writeFileSync(path.join(distDir, 'robots.txt'), fs.readFileSync(path.resolve(process.cwd(), 'public/robots.txt')));

const urls = sitemap.match(/<loc>/g)?.length ?? 0;
console.log(`sitemap.xml — ${urls} URLs`);
console.log('robots.txt — copied');
